library(tidyverse)
library(ggrepel)
library(ggimage)
library(nflfastR)
library(modelr)
library(broom)
library(caret)

# Retreives the play-by-play data set from the web
seasons <- 2020:2020
pbp20 <- map_df(seasons, function(x) {
  readRDS(
    url(
      paste0("https://raw.githubusercontent.com/guga31bb/nflfastR-data/master/data/play_by_play_",x,".rds")
    )
  )
})


# Creates data frame from the data set that includes only passing and running plays (excludes kickoffs, punts, etc.)
# Cleans the data to include only the columns that are needed
pbp_rp20 <- pbp20 %>%
  filter(rush == 1 | pass == 1, play_type != "no_play", !is.na(epa)) %>% select(play_type, epa, down, ydstogo, rush, pass, air_yards, first_down, complete_pass)


# Creates data frame that includes only second down plays (for second down models)
second <- pbp_rp20 %>%
  filter(rush == 1 | pass == 1, play_type != "no_play", !is.na(epa), down == 2) 


# Creates data frame that includes only third down plays (for third down models)
third <- pbp_rp20 %>%
  filter(rush == 1 | pass == 1, play_type != "no_play", !is.na(epa), down == 3) 


# Creates data frame that includes only pass plays -- plays where there is a value for air yards (for air yard model)
air <- pbp_rp20  %>%
  filter(!is.na(air_yards)) 


# Splits data into training and testing set (done for each model depending on what data frame is being used)
sample <- sample(c(TRUE, FALSE), nrow(pbp_rp20), replace = T, prob = c(0.6,0.4))
train <- pbp_rp20[sample, ]
test <- pbp_rp20[!sample, ]

sample <- sample(c(TRUE, FALSE), nrow(third), replace = T, prob = c(0.6,0.4))
train <- third[sample, ]
test <- third[!sample, ]


# Creates the logistic model from the training set (done for each model)
model1 <- glm(complete_pass ~ air_yards, family = "binomial", data = train)
summary(model1)
tidy(model1)


# Calculate Rsquared, RMSE, and MAe using different methods(done for each model)
predictions <- model1 %>% predict(test)
data.frame( R2 = R2(predictions, test$complete_pass),
            RMSE = RMSE(predictions, test$complete_pass),
            MAE = MAE(predictions, test$complete_pass))

train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3)

train.control <- trainControl(method = "cv", number = 10)

train.control <- trainControl(method = "LOOCV")

model <- train(complete_pass ~ air_yards, data = pbp_rp20, method = "glm",
               trControl = train.control)
print(model)


# Creates logistic regression graph (done for each model)
pbp_rp20 %>% ggplot(aes(ydstogo, rush)) +
  geom_point(alpha = .05) + 
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Pass distance model") +
  xlab("Air yards")+
  ylab("Probability of completing pass")


# Used to make model predictions (done for each model -- used in 2nd submission)
predict(model1, data.frame(air_yards = seq(1, 30, 5)), type = "response")