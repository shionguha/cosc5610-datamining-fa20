write.csv(x=k, file = "~/DataMining/combinedFacilityNurseData.csv")
k<-read.csv("~/DataMining/combinedFacilityNurseData.csv")
library(InformationValue)
library(pscl)
library(tidyverse)
library(modelr)
library(broom)
library(caret)
library(boot)
library(growthrates)

train_index <- sample(1:nrow(k), 0.8 * nrow(k))
test_index <- setdiff(1:nrow(k), train_index)

X_train <- k[train_index, c(2,6,7)]
y_train <- k[train_index, "nurseLogicInteger"]

X_test <- k[test_index, c(2,6,7)]
y_test <- k[test_index, "nurseLogicInteger"]

#X_train<- X_train[,'FacilityScore']
#X_test<- X_test[,'FacilityScore']
trainingData<-as.data.frame(X_train)
trainingData$nurselogicInteger<-y_train
testData<-as.data.frame(X_test)
testData$nurselogicInteger<-y_test

#testData<-testData-trainingData


logitMod1 <- glm(nurselogicInteger~FacilityScore,family = "binomial", data=trainingData)
logitMod2 <- glm(nurselogicInteger~numNurses,family = "binomial", data=trainingData)
logitMod3 <- glm(nurselogicInteger~FacilityScore + numNurses,family = "binomial", data=trainingData)

pscl::pR2(logitMod1)
pscl::pR2(logitMod2)
pscl::pR2(logitMod3)

trainingFacility<-as.data.frame(trainingData$FacilityScore)
predicted1 <- predict(logitMod1, trainingData)
predicted1<-as.data.frame(predicted1)

predicted2 <- predict(logitMod2, trainingData)
predicted2<-as.data.frame(predicted2)

predicted3 <- predict(logitMod3, trainingData)
predicted3<-as.data.frame(predicted3)


predictTest1<-predict(logitMod1, testData)
predictTest1<-as.data.frame(predictTest1)

predictTest2<-predict(logitMod2, testData)
predictTest2<-as.data.frame(predictTest2)

predictTest3<-predict(logitMod3, testData)
predictTest3<-as.data.frame(predictTest3)


optCutOff <- optimalCutoff(trainingData$nurselogicInteger, predicted1)[1] 

tidy(logitMod1)

exp(coef(logitMod1))

confint(logitMod1)


optCutOff1 <- optimalCutoff(testData$nurselogicInteger, predictTest1)[1] 


pred1<-predictTest1
for (i in 1:2407) {
  if(pred1$predictTest1[i]>.180386332424726){
    pred1$predictTest1[i]<-1
  }else{
    pred1$predictTest1[i]<-0
  }
  
}


confusionMatrix(factor(pred1$predictTest1[1:2407]), factor(testData$nurselogicInteger[1:2407]))


optCutOff1 <- optimalCutoff(trainingData$nurselogicInteger, predicted1)[1] 
pred1<-predicted1
for (i in 1:9624) {
  if(pred1$predicted1[i]>.230386332424726){
    pred1$predicted1[i]<-1
  }else{
    pred1$predicted1[i]<-0
  }
  
}

confusionMatrix(factor(pred1$predicted1[1:9624]), factor(trainingData$nurselogicInteger[1:9624]))





optCutOff2 <- optimalCutoff(testData$nurselogicInteger, predictTest2$predictTest2)[1] 


pred2<-predictTest2
for (i in 1:2407) {
  if(pred2$predictTest2[i]>optCutOff2){
    pred2$predictTest2[i]<-1
  }else{
    pred2$predictTest2[i]<-0
  }
  
}


confusionMatrix(factor(pred2$predictTest2[1:2407]), factor(testData$nurselogicInteger[1:2407]))


optCutOff2 <- optimalCutoff(trainingData$nurselogicInteger, predicted2)[1] 
pred2<-predicted2
for (i in 1:9624) {
  if(pred2$predicted2[i]>optCutOff2){
    pred2$predicted2[i]<-1
  }else{
    pred2$predicted2[i]<-0
  }
  
}

confusionMatrix(factor(pred2$predicted2[1:9624]), factor(trainingData$nurselogicInteger[1:9624]))









optCutOff3 <- optimalCutoff(testData$nurselogicInteger, predictTest3$predictTest3)[1] 


pred3<-predictTest3
for (i in 1:2407) {
  if(pred3$predictTest3[i]>optCutOff3){
    pred3$predictTest3[i]<-1
  }else{
    pred3$predictTest3[i]<-0
  }
  
}


confusionMatrix(factor(pred3$predictTest3[1:2407]), factor(testData$nurselogicInteger[1:2407]))


optCutOff3 <- optimalCutoff(trainingData$nurselogicInteger, predicted3)[1] 
pred3<-predicted3
for (i in 1:9624) {
  if(pred3$predicted3[i]>optCutOff3){
    pred3$predicted3[i]<-1
  }else{
    pred3$predicted3[i]<-0
  }
  
}

confusionMatrix(factor(pred3$predicted3[1:9624]), factor(trainingData$nurselogicInteger[1:9624]))










train_control <- trainControl(method = "cv", number = 10)
model1 <- train(averageNurseScore ~ FacilityScore,
               data = trainingData,
               trControl = train_control,
               method = "glm")


model1$results
summary(model1)

plot(trainingData$FacilityScore, trainingData$averageNurseScore)
#abline(model1, col='blue')
model1

#train_control <- trainControl(method = "cv", number = 10)
model2 <- train(averageNurseScore ~ numNurses,
                data = trainingData,
                trControl = train_control,
                method = "glm")


model2$results
summary(model2)
model2


model3 <- train(averageNurseScore ~ numNurses+FacilityScore,
                data = trainingData,
                trControl = train_control,
                method = "glm")


model3$results
summary(model3)
model3

pscl::pR2()


