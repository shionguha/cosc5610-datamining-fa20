#####################################
## Final Project - COSC 5610       ##
## Recidivism    - Brian Schippers ##
#####################################

# Load required libraries
library(dplyr)
library(plyr)
library(MASS)
library(dataPreparation)
library(data.table)
library(stringr)
library(pscl)
library(car)
library(ROCR)


data <- read.csv("3-Year_Recidivism_for_Offenders_Released_from_Prison_in_Iowa.csv")
data <- data.frame(sapply(data, trimws), stringsAsFactors = TRUE)

### Inital Preprocessing from Data Exploration

# Convert Days from Factor to integer
data$Days.to.Return <- as.integer(data$Days.to.Return)

# Order bins for ordinal age data
data$Age.At.Release <- relevel(data$Age.At.Release, ref = 'Under 25')
data$Age.At.Release <- relevel(data$Age.At.Release, ref = '')
data$Age.At.Release <- revalue(data$Age.At.Release, c('55 and Older'='55+'))

# Separate out Hispanic tag
data$Hispanic <- !grepl('Non-Hispanic',data$Race...Ethnicity)
data$Race...Ethnicity <- gsub(' -.*','',data$Race...Ethnicity)
data$Race...Ethnicity <- factor(data$Race...Ethnicity)

# Simplify Release categories
data$Release.Simple <- 'Unspecified'
data$Release.Simple[grepl('Discharged',data$Release.Type)] <- 'Discharged'
data$Release.Simple[grepl('Parole',data$Release.Type)] <- 'Parole'
data$Release.Simple[grepl('Special Sentence',data$Release.Type)] <- 'Special Sentence'
data$Release.Simple <- factor(data$Release.Simple)
data$Release.Simple <- relevel(data$Release.Simple,'Discharged')

# Remove incomplete records (age/sex modeling was disproportionately affected)
data <- data[data$Age.At.Release != '',] # 3 records total

### Clean Data ###
reject <- c()
reject <- c(reject, whichAreConstant(data))
reject <- c(reject, whichAreInDouble(data))
reject <- c(reject, whichAreBijection(data))
data <- subset(data,select = -reject)

dt <- as.data.table(data)

# Encode categorical variables as binaries
colnames(dt)
encoding <- build_encoding(dt,cols = colnames(dt)[-c(1,5,11)])
dt <- one_hot_encoder(dt, encoding = encoding, drop = TRUE, verbose = TRUE)

# Check for new bijections post-encoding
bijections <- whichAreBijection(dt)
colnames(dt)[bijections]
bijections

# Remove bijections, left in summary vs. specific bijections
colnames(dt)[c(36,84,87,142)]
dt <- dt[,-c(36,84,87,142)]

reject <- c()
reject <- c(reject, whichAreInDouble(dt))
reject <- c()
reject <- c(reject, whichAreConstant(dt))
dt <- subset(dt,select = -reject)

# Replace whitespace and special characters
colnames(dt) <- gsub(' ','.',colnames(dt))
colnames(dt) <- gsub('�???"','at',colnames(dt))

# Define subsets for training, testing, and validation
define <- sample(c(T,F),nrow(dt), replace = T,prob = c(0.6,0.4))
train.dt <- dt[define]
subdefine <- sample(c(T,F),nrow(dt)-nrow(train.dt), replace = T,prob = c(0.5,0.5))
val.dt <- dt[!define][subdefine]
test.dt <- dt[!define][!subdefine]

# use quick modeling to identify multicollinearity and relevant variables
for (n in colnames(data)) {
  fx <- paste("Return.to.Prison.Yes",paste(colnames(train.dt)[grepl(paste('^',n,sep = ''), colnames(train.dt))], collapse = " + "),sep = " ~ ")
  print("*********************************************************")
  print(n)
  print(fx)
  print(summary(glm(fx,train.dt,family = 'binomial')))
}

# Remove variables that imply recidivism
recidivism.var <- colnames(dt)
recidivism.var <- recidivism.var[!grepl("New.Offense",recidivism.var)]
recidivism.var <- recidivism.var[!grepl("Recidivism.Type",recidivism.var)]
recidivism.var <- recidivism.var[!grepl("Days.to.Return",recidivism.var)]
recidivism.var <- recidivism.var[!grepl("Return.to.Prison.Yes",recidivism.var)]

# Remove summary variables
recidivism.var <- recidivism.var[!grepl('^Offense.Type',recidivism.var)]
recidivism.var <- recidivism.var[!grepl('^Release.Simple',recidivism.var)]

for (n in colnames(data)) {
  if (any(grepl(paste('^',n,sep = ''), recidivism.var))) {
    fx <- paste("Return.to.Prison.Yes",paste(recidivism.var[grepl(paste('^',n,sep = ''), recidivism.var)], collapse = " + "),sep = " ~ ")
    print("*********************************************************")
    print(n)
    print(fx)
    mdl <- glm(fx,train.dt,family = 'binomial')
    print(summary(mdl))
  }
}


### Construct Recidivism Models ###

# rec = recidivism

# Model 1: incorporates all available predictors
rec.formula <- as.formula(paste('Return.to.Prison.Yes',paste(recidivism.var, collapse = ' + '),sep = ' ~ '))
rec.mdl1 <- glm(rec.formula,train.dt,family = 'binomial')
summary(rec.mdl1)

# Model 2: Remove Predictors unavailable at sentencing
rec.var <- recidivism.var
rec.var <- rec.var[!grepl('^Fiscal.Year',rec.var)]
rec.var <- rec.var[!grepl('^Target.Population',rec.var)]
rec.var <- rec.var[!grepl('^Main.Supervising',rec.var)]
rec.var <- rec.var[!grepl('^Release',rec.var)]
rec.formula <- as.formula(paste('Return.to.Prison.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
rec.mdl2 <- glm(rec.formula,train.dt,family = 'binomial')
summary(rec.mdl2)

# Model 3: Remove Racial Variables 
rec.var <- rec.var[!grepl('^Hispanic',rec.var)]
rec.var <- rec.var[!grepl('^Race',rec.var)]
rec.formula <- as.formula(paste('Return.to.Prison.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
rec.mdl3 <- glm(rec.formula,train.dt,family = 'binomial')
summary(rec.mdl3)

# Model 4: Brute Force

# Functions for testing possible simple arrangements of terms
func <- function(outcome,top.var,variable.set) {
  df <- data.frame(Fx = "0",Log.Likelihood = 0,R2 = 0,AIC = 0)
  fx <- paste(outcome," ~ ",sep = '')
  df <- subfunc(0,fx,fx,df,top.var,variable.set,outcome)
  df <- df[-1,]
  rownames(df) <- NULL
  df$terms <- sapply(df$Fx,function(x) (str_count(x,'\\+')+1))
  return(df)
}

subfunc <- function(n,fx1,fx2,df,top.var,variable.set,outcome) {
  for (i in (n+1):length(top.var)) {
    if (any(grepl(paste('^',top.var[i],sep = ''), variable.set))) {
      i.var <- grep(paste('^',top.var[i],sep = ''), variable.set)
      if (n == 0){
        fxn <- paste(fx1,paste(variable.set[i.var], collapse = " + "), sep = "")
        mfx <- paste(fx2,top.var[i], sep = "")
      } else {
        fxn <- paste(fx1,paste(variable.set[i.var], collapse = " + "), sep = " + ")
        mfx <- paste(fx2,top.var[i], sep = " + ")
      }
      if (i != length(top.var)) {
        df <- subfunc(i,fxn,mfx,df,top.var,variable.set,outcome)
        mdl <- glm(fxn,train.dt,family = 'binomial')
        pseudo <- pR2(mdl)
        df <- rbind(df,data.frame( Fx = mfx,
                                   Log.Likelihood = pseudo['llh'],
                                   R2 = pseudo["McFadden"],
                                   AIC = mdl$aic))
      }
    }
  }
  return(df)
}

# Generate comparison table

# Remove Predictors unavailable at sentencing
rec.var <- recidivism.var
rec.var <- rec.var[!grepl('^Fiscal.Year',rec.var)]
rec.var <- rec.var[!grepl('^Target.Population',rec.var)]
rec.var <- rec.var[!grepl('^Main.Supervising',rec.var)]
rec.var <- rec.var[!grepl('^Release',rec.var)]
rec.df <- func("Return.to.Prison.Yes",colnames(data),rec.var)

rec.var <- unlist(str_split(rec.df$Fx[46]," . "))[-1]
rec.var <- unlist(sapply(rec.var, function(x) recidivism.var[grep(paste('^',x,sep=''),recidivism.var)]))
rec.formula <- as.formula(paste('Return.to.Prison.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
rec.mdl4 <- glm(rec.formula,train.dt,family = 'binomial')

t(data.frame(model1 = pR2(rec.mdl1)["McFadden"],
             model2 = pR2(rec.mdl2)["McFadden"],
             model3 = pR2(rec.mdl3)["McFadden"],
             model4 = pR2(rec.mdl4)["McFadden"]))


### Construct 'Target Population' Models ###

# Model 1: Remove Predictors unavailable at sentencing
rec.var <- recidivism.var
rec.var <- rec.var[!grepl('^Fiscal.Year',rec.var)]
rec.var <- rec.var[!grepl('^Target.Population',rec.var)]
rec.var <- rec.var[!grepl('^Main.Supervising',rec.var)]
rec.var <- rec.var[!grepl('^Release',rec.var)]
tp.formula <- as.formula(paste('Target.Population.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
tp.mdl1 <- glm(tp.formula,train.dt,family = 'binomial')
summary(tp.mdl1)

# Model 2: Remove Racial Variables 
rec.var <- rec.var[!grepl('^Hispanic',rec.var)]
rec.var <- rec.var[!grepl('^Race',rec.var)]
tp.formula <- as.formula(paste('Target.Population.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
tp.mdl2 <- glm(tp.formula,train.dt,family = 'binomial')
summary(rec.mdl2)

# Model 3: Focus only on Race
rec.var <- recidivism.var
rec.var <- rec.var[!grepl('^Fiscal.Year',rec.var)]
rec.var <- rec.var[!grepl('^Main.Supervising',rec.var)]
rec.var <- rec.var[!grepl('^Target.Population',rec.var)]
rec.var <- rec.var[!grepl('^Offense',rec.var)]
rec.var <- rec.var[!grepl('^Sex',rec.var)]
rec.var <- rec.var[!grepl('^Age',rec.var)]
rec.var <- rec.var[!grepl('^Release',rec.var)]
tp.formula <- as.formula(paste('Target.Population.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
tp.mdl3 <- glm(tp.formula,train.dt,family = 'binomial')
summary(tp.mdl3)

# Model 4: Brute Force
rec.var <- recidivism.var
rec.var <- rec.var[!grepl('^Fiscal.Year',rec.var)]
rec.var <- rec.var[!grepl('^Target.Population',rec.var)]
tp.df <- func("Target.Population.Yes",colnames(data),rec.var)

# Supervising District and Release appear to be similarly contributing to models

# A large number of individuals excluded from the target population have no district specified
mosaicplot(~ Main.Supervising.District+Target.Population,data = data)

# Within that population 
data$Release.Simple <- factor(data$Release.Simple, ordered = FALSE)
data$Release.Simple <- relevel(data$Release.Simple, ref = 'Unspecified')
data$Release.Simple <- relevel(data$Release.Simple, ref = 'Discharged')
mosaicplot(~ Release.Simple+Target.Population,data[data$Main.Supervising.District == ''])

# Testing again in the absence of Supervising District
rec.var <- rec.var[!grepl('^Main.Supervising',rec.var)]
tp.df <- func("Target.Population.Yes",colnames(data),rec.var)


### Course Correction ###

# Release.type is an integral part of target population selection. Add to models 2 and 3.

# Model 2: All Variables available to corrections staff
tp.formula <- as.formula(paste('Target.Population.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
tp.mdl2 <- glm(tp.formula,train.dt,family = 'binomial')
summary(rec.mdl2)

# Model 3: Remove Racial Variables 
rec.var <- rec.var[!grepl('^Hispanic',rec.var)]
rec.var <- rec.var[!grepl('^Race',rec.var)]
tp.formula <- as.formula(paste('Target.Population.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
tp.mdl3 <- glm(tp.formula,train.dt,family = 'binomial')
summary(tp.mdl3)


# Assign same variables as Rec Model 4 + Release.type
rec.var <- unlist(str_split(rec.df$Fx[46]," . "))[-1]
rec.var[3] <- "Release.Type"
rec.var <- unlist(sapply(rec.var, function(x) recidivism.var[grep(paste('^',x,sep=''),recidivism.var)]))
rec.formula <- as.formula(paste('Target.Population.Yes',paste(rec.var, collapse = ' + '),sep = ' ~ '))
tp.mdl4 <- glm(rec.formula,train.dt,family = 'binomial')
summary(tp.mdl4)


t(data.frame(model1 = pR2(tp.mdl1)["McFadden"],
             model2 = pR2(tp.mdl2)["McFadden"],
             model3 = pR2(tp.mdl3)["McFadden"],
             model4 = pR2(tp.mdl4)["McFadden"]))

### Error Checking/Validation/Tuning ###

# function uses validation data to print confusion matrix and ROCR plot, 
# also shows odds ratios
eval.val <- function(mdl,dt) {
  pred <- mdl %>% predict(dt)
  pred <- ifelse(pred > .5,1,0)
  truth <- dt$Return.to.Prison.Yes
  
  xtab <- table(pred,truth)
  
  tryCatch({print(confusionMatrix(xtab,positive = '1'))},
      error = function(cond) {print(xtab)})
  
  prediction(pred,truth,label.ordering = c(negative = '0',positive = '1')) %>%
    performance(measure = "tpr", x.measure = "fpr") %>%
    plot()
  
  print(round(exp(cbind("Odds ratio" = coef(mdl), confint.default(mdl, level = 0.95))),4))
}

# builds error and correlation table using validation data
error.table <- function(mdl,dt) {
  outcome <- as.character(mdl$formula)[2]
  predictions <- mdl %>% predict(dt)
  df <- data.frame(R2 = R2(predictions, dt[[outcome]]),
                   RMSE = RMSE(predictions, dt[[outcome]]),
                   MAE = MAE(predictions, dt[[outcome]]))
  return(df)
}

# Recidivism Models
eval.val(rec.mdl1,val.dt)
eval.val(rec.mdl2,val.dt)
eval.val(rec.mdl3,val.dt)
eval.val(rec.mdl4,val.dt)

do.call(rbind,list(model1 = error.table(rec.mdl1,val.dt),  # All Variables
                   model2 = error.table(rec.mdl2,val.dt),  # Only Available at Sentencing
                   model3 = error.table(rec.mdl3,val.dt),  # Less Race/Ethnicity
                   model4 = error.table(rec.mdl4,val.dt))) # Brute Force, simplified model

# Target Population Models
eval.val(tp.mdl1,val.dt)
eval.val(tp.mdl2,val.dt)
eval.val(tp.mdl3,val.dt)
eval.val(tp.mdl4,val.dt)

do.call(rbind,list(model1 = error.table(tp.mdl1,val.dt),  # Only Available at Sentencing
                   model2 = error.table(tp.mdl2,val.dt),  # Only Available at Program Selection
                   model3 = error.table(tp.mdl3,val.dt),  # Less Race/Ethnicity
                   model4 = error.table(tp.mdl4,val.dt))) # Same as Rec #4 + Release.Type

# Proceed with models 2 & 4 for Rec, and 1 & 4 for Target Pop

# Relabel to A (all sentencing/selection information) & B (simplified model)
rec.a <- rec.mdl2
rec.b <- rec.mdl4
tp.a <- tp.mdl1
tp.b <- tp.mdl4


### Crossvalidation ###

# combine validation into training set
cv.dt <- rbind(train.dt,val.dt)

crossval <- function(model,name) {
  # Define training control (K-Fold)
  train.control <- trainControl(method = "cv", number = 20)
  # Train the model
  mdl <- train(model$formula, data = cv.dt, method = "glm",
                 trControl = train.control)
  # Summarize the results
  df1 <- cbind(data.frame(model = name,
                          method = mdl$control$method,
                          number = mdl$control$number,
                          repeats = mdl$control$repeats
                          ),
               mdl$results[2:4])

  # Define training control (repeated K-Fold)
  train.control <- trainControl(method = "repeatedcv", 
                                number = 10, repeats = 3)
  # Train the model
  mdl <- train(model$formula, data = cv.dt, method = "glm",
                 trControl = train.control)
  # Summarize the results
  df2 <- cbind(data.frame(model = name,
                          method = mdl$control$method,
                          number = mdl$control$number,
                          repeats = mdl$control$repeats
                          ),
               mdl$results[2:4])
  return(list(mdl,rbind(df1,df2)))
}

# Table of cross validation models with adjusted errors
cv.table <- list(r.a <- crossval(rec.a,"Recidivism - Sentencing Info."),
                 r.b <- crossval(rec.b,"Recidivism - Simplified"),
                 t.a <- crossval(tp.a,"Target Pop. - Selection Info."),
                 t.b <- crossval(tp.b,"Target Pop. - Simplified"))
rec.a <- r.a[[1]]
rec.b <- r.b[[1]]
tp.a <- t.a[[1]]
tp.b <- t.b[[1]]

cv.table <- rbind(r.a[[2]],r.b[[2]],t.a[[2]],t.b[[2]])

cv.table


### Testing ###

eval.test <- function(mdl,dt) {
  pred <- mdl %>% predict(dt)
  pred <- ifelse(pred > .5,1,0)
  truth <- dt$Return.to.Prison.Yes
  
  xtab <- table(pred,truth)
  
  tryCatch({print(confusionMatrix(xtab,positive = '1'))},
           error = function(cond) {print(xtab)})
  
  prediction(pred,truth,label.ordering = c(negative = '0',positive = '1')) %>%
    performance(measure = "tpr", x.measure = "fpr") %>%
    plot()
  
  print(round(exp(cbind("Odds ratio" = coef(mdl$finalModel), confint.default(mdl$finalModel, level = 0.95))),4))
}

eval.test(rec.a,test.dt)
eval.test(rec.b,test.dt)
eval.test(tp.a,test.dt)
eval.test(tp.b,test.dt)

# Results on test data limited to violent reoffenders and non-recidivate population
violent.test.dt <- test.dt[test.dt$New.Offense.Type.Violent == 1 | 
                             test.dt$New.Offense.Type.Sex == 1| 
                             test.dt$New.Offense.Type.Assault == 1|
                             test.dt$Return.to.Prison.Yes == 0]

eval.test(rec.a,violent.test.dt)
eval.test(rec.b,violent.test.dt)
