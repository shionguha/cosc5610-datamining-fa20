#Clear workspace
rm(list = ls(all.names = TRUE))

#Load Libraries
library(modelr)
library(vcd)
library(readxl)
library(tidyverse)
library(ggplot2)
library(Rmisc)
library(broom)
library(dplyr) # for data manipulation
library(caret) # for model-building
library(DMwR) # for smote implementation
library(purrr) # for functional programming (map)
library(pROC) # for AUC calculations
library(ROCR)

#choose excel to import data
red_blue_data <- read_excel(file.choose())

#Convert PartyID - 1 corresponds to republican & 2 to democrat
for (i in seq_along(red_blue_data$PartyID)){
  if(red_blue_data$PartyID[i] == 1){
    red_blue_data$affiliation[i] <- "Rep"
  }else if(red_blue_data$PartyID[i] == 2){
    red_blue_data$affiliation[i] <- "Dem"
  }else{
    red_blue_data$affiliation[i] <- "ERROR"
  }
}
red_blue_data$affiliation <-factor(red_blue_data$affiliation)

#Convert Ideology - 1 corresponds to liberal & 2 to conservative
for (i in seq_along(red_blue_data$Ideology)){
  if(red_blue_data$Ideology[i] == 1){
    red_blue_data$ideology[i] <- "Lib"
  }else if(red_blue_data$Ideology[i] == 2){
    red_blue_data$ideology[i] <- "Con"
  }else{
    red_blue_data$ideology[i] <- "ERROR"
  }
}
red_blue_data$ideology <-factor(red_blue_data$ideology)

#Data that could be included in model building. For voting record, 
#9 --> subject always votes Democrat, -9 --> always Republican.
#For DemBlue & RepRed, scale from 1 - 9 where 9 is strong pref for color.
#Trying to predict party affiliation (first column).
paired_down_data <- data.frame("affiliation" = red_blue_data$affiliation, 
          "political philosophy" = red_blue_data$ideology,
          "voting record" = red_blue_data$VoteDiff,
          "age" = red_blue_data$Age,
          "preference for blue" = red_blue_data$DemBlue,
          "preference for red" = red_blue_data$RepRed,
          "blue Flanker Effect"= red_blue_data$FEBlue,
          "red Flanker Effect" = red_blue_data$FERed,
          "Election Day" = red_blue_data$ED)

#Order data by affiliation
#paired_down_data <- paired_down_data[order(paired_down_data$affiliation),]

#Split into training and test set. 1st-->80-20 split, 2nd-->70-30, 3rd-->60-40
set.seed(123)
splitter <- sample(c(TRUE,FALSE), nrow(paired_down_data), replace = T, prob = c(0.8,0.2))
#splitter <- sample(c(TRUE,FALSE), nrow(paired_down_data), replace = T, prob = c(0.7, 0.3))
#splitter <- sample(c(TRUE,FALSE), nrow(paired_down_data), replace = T, prob = c(0.6, 0.4))

#Set up training control to handle class imbalance & cross validation
#ctrl <- trainControl(method = "repeatedcv",
#                     number = 10,
#                     repeats = 5,
#                     summaryFunction = twoClassSummary,
#                     classProbs = TRUE)

train <- paired_down_data[splitter,]
test <- paired_down_data[!splitter,]

#logit1 <- glm(party~Age + ideology + VoteClass + DemBlue + FEBlue, 
#              data = red_blue_data, family = "binomial")
#summary(logit1)

#Model1 - age as a predictor of affiliation
model1 <- glm(affiliation~age, data = train, family = "binomial")

paired_down_data %>%
  mutate(prob = ifelse(affiliation == "Rep", 1, 0)) %>%
  ggplot(aes(age, prob)) +
  geom_point(alpha = .15) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Logistic regression model fit") +
  xlab("Age") +
  ylab("Probability of Republican")

summary(model1)
tidy(model1)
exp(coef(model1))
confint(model1)


#Model2 - political philosophy as a predictor of affiliation. No plot because 
#political philosophy is a categorical predictor with just 2 levels
model2 <- glm(affiliation~ political.philosophy, data = train, family = "binomial")

summary(model2)
tidy(model2)
exp(coef(model2))
confint(model2)

#Model3 - voting record as a predictor of affiliation
model3 <- glm(affiliation~ voting.record, data = train, family = "binomial")

paired_down_data %>%
  mutate(prob = ifelse(affiliation == "Rep", 1, 0)) %>%
  ggplot(aes(voting.record, prob)) +
  geom_point(alpha = .15) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Logistic regression model fit") +
  xlab("Voting Record") +
  ylab("Probability of Republican")

summary(model3)
tidy(model3)
exp(coef(model3))
confint(model3)

#Model4 - rating of "Democrat Blue as a predictor of affiliation
model4 <- glm(affiliation~ preference.for.blue, data = train, family = "binomial")

paired_down_data %>%
  mutate(prob = ifelse(affiliation == "Rep", 1, 0)) %>%
  ggplot(aes(preference.for.blue, prob)) +
  geom_point(alpha = .15) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Logistic regression model fit") +
  xlab('Rating of "Democrat Blue"') +
  ylab("Probability of Republican")

summary(model4)
tidy(model4)
exp(coef(model4))
confint(model4)

#Model5 - Rating of "Republican Red" as a predictor of affiliation
model5 <- glm(affiliation~ preference.for.red, data = train, family = "binomial")

paired_down_data %>%
  mutate(prob = ifelse(affiliation == "Rep", 1, 0)) %>%
  ggplot(aes(preference.for.red, prob)) +
  geom_point(alpha = .15) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Logistic regression model fit") +
  xlab('Rating of "Republican Red"') +
  ylab("Probability of Republican")

summary(model5)
tidy(model5)
exp(coef(model5))
confint(model5)

#Model6 - Blue Flanker Effect as a predictor of affiliation
model6 <- glm(affiliation~ blue.Flanker.Effect, data = train, family = "binomial")

paired_down_data %>%
  mutate(prob = ifelse(affiliation == "Rep", 1, 0)) %>%
  ggplot(aes(blue.Flanker.Effect, prob)) +
  geom_point(alpha = .15) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Logistic regression model fit") +
  xlab("Blue Flanker Effect") +
  ylab("Probability of Republican")

summary(model6)
tidy(model6)
exp(coef(model6))
confint(model6)

#Model7 - Red Flanker Effect as a predictor of affiliation
model7 <- glm(affiliation~ red.Flanker.Effect, data = train, family = "binomial")

paired_down_data %>%
  mutate(prob = ifelse(affiliation == "Rep", 1, 0)) %>%
  ggplot(aes(red.Flanker.Effect, prob)) +
  geom_point(alpha = .15) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Logistic regression model fit") +
  xlab("Red Flanker Effect") +
  ylab("Probability of Republican")

summary(model7)
tidy(model7)
exp(coef(model7))
confint(model7)


#Model8 - Whether or not subjects participated in the study on election day
#as a predictor of affiliation. No graph because categorical predictor with just
#2 levels
model8 <- glm(affiliation~ Election.Day, data = train, family = "binomial")

summary(model8)
tidy(model8)
exp(coef(model8))
confint(model8)

#Model9 - Age, political philosophy, voting record, rating of "Dem Blue," rating
#of "Rep Red," and blue Flanker Effect as predictors of affiliation
model9 <- glm(affiliation~ blue.Flanker.Effect + voting.record +
                political.philosophy + preference.for.red + preference.for.blue +
                age, data = train, family = "binomial")

summary(model9)
tidy(model9)
exp(coef(model9))
confint(model9)

#Model10 - Model with "classic" predictors (age, political philosophy, voting 
#record)
model10 <- glm(affiliation~ voting.record + political.philosophy + age, 
               data = train, family = "binomial")

summary(model10)
tidy(model10)
exp(coef(model10))
confint(model10)

#Model11 - Model with "color" predictors (blue Flanker Effect, "Rep Red" rating,
#and "Dem Blue" rating).
model11 <- glm(affiliation~ blue.Flanker.Effect + preference.for.red + 
                preference.for.blue, data = train, family = "binomial")

summary(model11)
tidy(model11)
exp(coef(model11))
confint(model11)


#Evaluate models
#Predictions for model 1 on test set --> age
prob1 <- predict(model1, test, type = "response")
pred1 <- vector(mode="numeric", length=length(prob1))
for (i in seq_along(prob1)){
  if(prob1[i] >= .5){
    pred1[i] <- "Rep"
  }else{
    pred1[i] <- "Dem"
  }
}
pred1 <- factor(pred1)
confusionMatrix(pred1, test$affiliation)


#Predictions for model 2 on test set --> political philosophy
prob2 <- predict(model2, test, type = "response")
pred2 <- vector(mode="numeric", length=length(prob2))
for (i in seq_along(prob2)){
  if(prob2[i] >= .5){
    pred2[i] <- "Rep"
  }else{
    pred2[i] <- "Dem"
  }
}
pred2 <- factor(pred2)
confusionMatrix(pred2, test$affiliation)


#Predictions for model 3 on test set --> voting record
prob3 <- predict(model3, test, type = "response")
pred3 <- vector(mode="numeric", length=length(prob3))
for (i in seq_along(prob3)){
  if(prob3[i] >= .5){
    pred3[i] <- "Rep"
  }else{
    pred3[i] <- "Dem"
  }
}
pred3 <- factor(pred3)
confusionMatrix(pred3, test$affiliation)


#Predictions for model 4 on test set --> "Dem Blue" Rating
prob4 <- predict(model4, test, type = "response")
pred4 <- vector(mode="numeric", length=length(prob4))
for (i in seq_along(pred4)){
  if(prob4[i] >= .5){
    pred4[i] <- "Rep"
  }else{
    pred4[i] <- "Dem"
  }
}
pred4 <- factor(pred4)
confusionMatrix(pred4, test$affiliation)


#Predictions for model 5 on test set --> "Rep Red" Rating
prob5 <- predict(model5, test, type = "response")
pred5 <- vector(mode="numeric", length=length(prob5))
for (i in seq_along(pred5)){
  if(prob5[i] >= .5){
    pred5[i] <- "Rep"
  }else{
    pred5[i] <- "Dem"
  }
}
pred5 <- factor(pred5)
confusionMatrix(pred5, test$affiliation)


#Predictions for model 6 on test set --> Blue Flanker Effect
prob6 <- predict(model6, test, type = "response")
pred6 <- vector(mode="numeric", length=length(prob6))
for (i in seq_along(pred6)){
  if(prob6[i] >= .5){
    pred6[i] <- "Rep"
  }else{
    pred6[i] <- "Dem"
  }
}
pred6 <- factor(pred6)
confusionMatrix(pred6, test$affiliation)


#Predictions for model 7 on test set --> Red Flanker Effect
prob7 <- predict(model7, test, type = "response")
pred7 <- vector(mode="numeric", length=length(prob7))
for (i in seq_along(pred7)){
  if(prob7[i] >= .5){
    pred7[i] <- "Rep"
  }else{
    pred7[i] <- "Dem"
  }
}
pred7 <- factor(pred7)
confusionMatrix(pred7, test$affiliation)


#Predictions for model 8 on test set --> Election Day
prob8 <- predict(model8, test, type = "response")
pred8 <- vector(mode="numeric", length=length(prob8))
for (i in seq_along(pred8)){
  if(prob8[i] >= .5){
    pred8[i] <- "Rep"
  }else{
    pred8[i] <- "Dem"
  }
}
pred8 <- factor(pred8)
confusionMatrix(pred8, test$affiliation)


#Predictions for model 9 on test set --> First 6 predictors
prob9 <- predict(model9, test, type = "response")
pred9 <- vector(mode="numeric", length=length(prob9))
for (i in seq_along(pred9)){
  if(prob9[i] >= .5){
    pred9[i] <- "Rep"
  }else{
    pred9[i] <- "Dem"
  }
}
pred9 <- factor(pred9)
confusionMatrix(pred9, test$affiliation)


#Predictions for model 10 on test set --> Classic predictors
prob10 <- predict(model10, test, type = "response")
pred10 <- vector(mode="numeric", length=length(prob10))
for (i in seq_along(pred10)){
  if(prob10[i] >= .5){
    pred10[i] <- "Rep"
  }else{
    pred10[i] <- "Dem"
  }
}
pred10 <- factor(pred10)
confusionMatrix(pred10, test$affiliation)


#Predictions for model 11 on test set --> Color predictors
prob11 <- predict(model11, test, type = "response")
pred11 <- vector(mode="numeric", length=length(prob11))
for (i in seq_along(pred11)){
  if(prob11[i] >= .5){
    pred11[i] <- "Rep"
  }else{
    pred11[i] <- "Dem"
  }
}
pred11 <- factor(pred11)
confusionMatrix(pred11, test$affiliation)

error_frame <- data.frame( model = c("M9 Error", "M10 Error", "M11 Error"), 
            R2 = c(R2(as.numeric(pred9), as.numeric(test$affiliation)), 
                   R2(as.numeric(pred10), as.numeric(test$affiliation)),
                   R2(as.numeric(pred11), as.numeric(test$affiliation))),
            RMSE = c(RMSE(as.numeric(pred9), as.numeric(test$affiliation)), 
                     RMSE(as.numeric(pred10), as.numeric(test$affiliation)),
                     RMSE(as.numeric(pred11), as.numeric(test$affiliation))),
            MAE = c(MAE(as.numeric(pred9), as.numeric(test$affiliation)), 
                    MAE(as.numeric(pred10), as.numeric(test$affiliation)),
                    MAE(as.numeric(pred11), as.numeric(test$affiliation))))

#ROC curves for models 9, 10, and 11
predPerf9 <- prediction(as.numeric(pred9), as.numeric(test$affiliation))
perf9 <- performance(predPerf9, "tpr", "fpr")
plot(perf9)

predPerf10 <- prediction(as.numeric(pred10), as.numeric(test$affiliation))
perf10 <- performance(predPerf10, "tpr", "fpr")
plot(perf10)

predPerf11 <- prediction(as.numeric(pred11), as.numeric(test$affiliation))
perf11 <- performance(predPerf11, "tpr", "fpr")
plot(perf11)

#AUC calculations for models 9, 10, and 11
auc9 <- performance(predPerf9, measure = "auc")
auc9@y.values

auc10 <-  performance(predPerf10, measure = "auc")
auc10@y.values

auc11 <- performance(predPerf11, measure = "auc")
auc11@y.values

#Clear workspace to rebuild models 9-11 implementing cross validation and SMOTE
rm(list = ls(all.names = TRUE))

#choose excel to import data
red_blue_data <- read_excel(file.choose())

#Convert PartyID - 1 corresponds to republican & 2 to democrat
for (i in seq_along(red_blue_data$PartyID)){
  if(red_blue_data$PartyID[i] == 1){
    red_blue_data$affiliation[i] <- "Rep"
  }else if(red_blue_data$PartyID[i] == 2){
    red_blue_data$affiliation[i] <- "Dem"
  }else{
    red_blue_data$affiliation[i] <- "ERROR"
  }
}
red_blue_data$affiliation <-factor(red_blue_data$affiliation)

#Convert Ideology - 1 corresponds to liberal & 2 to conservative
for (i in seq_along(red_blue_data$Ideology)){
  if(red_blue_data$Ideology[i] == 1){
    red_blue_data$ideology[i] <- "Lib"
  }else if(red_blue_data$Ideology[i] == 2){
    red_blue_data$ideology[i] <- "Con"
  }else{
    red_blue_data$ideology[i] <- "ERROR"
  }
}
red_blue_data$ideology <-factor(red_blue_data$ideology)

#Data that could be included in model building. For voting record, 
#9 --> subject always votes Democrat, -9 --> always Republican.
#For DemBlue & RepRed, scale from 1 - 9 where 9 is strong pref for color.
#Trying to predict party affiliation (first column).
paired_down_data <- data.frame("affiliation" = red_blue_data$affiliation, 
                               "political philosophy" = red_blue_data$ideology,
                               "voting record" = red_blue_data$VoteDiff,
                               "age" = red_blue_data$Age,
                               "preference for blue" = red_blue_data$DemBlue,
                               "preference for red" = red_blue_data$RepRed,
                               "blue Flanker Effect"= red_blue_data$FEBlue,
                               "red Flanker Effect" = red_blue_data$FERed,
                               "Election Day" = red_blue_data$ED)

#Set up training controls to handle class imbalance & cross validation
set.seed(123)
#ctrl <- trainControl(method = "repeatedcv",
#                     number = 10,
#                     repeats = 5)
#ctrl <- trainControl(method = "LOOCV")
ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     sampling = "smote")

#Model9 - Age, political philosophy, voting record, rating of "Dem Blue," rating
#of "Rep Red," and blue Flanker Effect as predictors of affiliation
model9 <- train(affiliation~ blue.Flanker.Effect + voting.record +
                  political.philosophy + preference.for.red + preference.for.blue +
                  age, data = paired_down_data, method = "glm", trControl = ctrl)

summary(model9)
print(model9)

#Model10 - Model with "classic" predictors (age, political philosophy, voting 
#record)
model10 <- train(affiliation~ voting.record + political.philosophy + age, 
                 data = paired_down_data, method = "glm", trControl = ctrl)

summary(model10)
print(model10)


#Model11 - Model with "color" predictors (blue Flanker Effect, "Rep Red" rating,
#and "Dem Blue" rating).
model11 <- train(affiliation~ blue.Flanker.Effect + preference.for.red + 
                   preference.for.blue, data = paired_down_data, 
                 method = "glm", trControl = ctrl)

summary(model11)
print(model11)


#Evaluate Models

#Confusion matrices for 9, 10, and 11
confusionMatrix(model9)
confusionMatrix(model10)
confusionMatrix(model11)

#Accuracy (avg and stdev)
a9 <- model9[["results"]][["Accuracy"]]
sd9 <- model9[["results"]][["AccuracySD"]]
a10 <- model10[["results"]][["Accuracy"]]
sd10 <- model10[["results"]][["AccuracySD"]]
a11 <- model11[["results"]][["Accuracy"]]
sd11 <- model11[["results"]][["AccuracySD"]]