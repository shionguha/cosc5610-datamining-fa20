library(tm)
library(wordcloud)
library(caret)
library(gains)
library(pROC)
library(dplyr)
library(purrr)
library(DMwR)

rm(list=ls())

setwd("~/MU/Courses/DataMining/homework/Final/")
data <- read.csv("Review.csv")
subset <- data[, c(7,9)]

#write.table(subset, "Geng-006193090.csv", row.names=FALSE,col.names=TRUE, sep=",")

#barplot
mytable <- with(subset, table(Score))
df <- as.data.frame(mytable)
mean(subset$Score)
ggplot(data=df, mapping=aes(x=Score,y=Freq)) + 
  geom_bar(stat="identity", color = "red", fill = "steelblue") + 
  geom_text(aes(label=Freq), vjust=1.6, color="white", size=3.5)
subset$Score <- ifelse(subset$Score > 3 , "Pos", "Neg")
mytable <- with(subset, table(Score))
df <- as.data.frame(mytable)
ggplot(data=df, mapping=aes(x=Score,y=Freq)) + 
  geom_bar(stat="identity", color = "red", fill = "steelblue") + 
  geom_text(aes(label=Freq), vjust=1.6, color="white", size=3.5)

#Filter data
subset_corpus <- Corpus(VectorSource(subset$Summary))
subset_corpus <- tm_map(subset_corpus, content_transformer(tolower))
subset_corpus = tm_map(subset_corpus, removeNumbers)
subset_corpus = tm_map(subset_corpus, removePunctuation)
subset_corpus = tm_map(subset_corpus, removeWords, c("the", "and", stopwords("english")))
subset_corpus =  tm_map(subset_corpus, stripWhitespace)

subset_pos <-filter(subset, Score == "Pos")
subset_corpus_pos <- Corpus(VectorSource(subset_pos$Summary))
subset_corpus_pos <- tm_map(subset_corpus_pos, content_transformer(tolower))
subset_corpus_pos = tm_map(subset_corpus_pos, removeNumbers)
subset_corpus_pos = tm_map(subset_corpus_pos, removePunctuation)
subset_corpus_pos = tm_map(subset_corpus_pos, removeWords, c("the", "and", stopwords("english")))
subset_corpus_pos =  tm_map(subset_corpus_pos, stripWhitespace)

subset_neg <-filter(subset, Score == "Neg")
subset_corpus_neg <- Corpus(VectorSource(subset_neg$Summary))
subset_corpus_neg <- tm_map(subset_corpus_neg, content_transformer(tolower))
subset_corpus_neg = tm_map(subset_corpus_neg, removeNumbers)
subset_corpus_neg = tm_map(subset_corpus_neg, removePunctuation)
subset_corpus_neg = tm_map(subset_corpus_neg, removeWords, c("the", "and", stopwords("english")))
subset_corpus_neg =  tm_map(subset_corpus_neg, stripWhitespace)

#Word cloud
subset_dtm_tfidf <- DocumentTermMatrix(subset_corpus)
subset_dtm_tfidf = removeSparseTerms(subset_dtm_tfidf, 0.999)
freq = data.frame(sort(colSums(as.matrix(subset_dtm_tfidf)), decreasing=TRUE))
wordcloud(rownames(freq), freq[,1], max.words=50, colors=brewer.pal(1, "Dark2"))

subset_dtm_tfidf_pos <- DocumentTermMatrix(subset_corpus_pos)
subset_dtm_tfidf_pos = removeSparseTerms(subset_dtm_tfidf_pos, 0.999)
freq = data.frame(sort(colSums(as.matrix(subset_dtm_tfidf_pos)), decreasing=TRUE))
wordcloud(rownames(freq), freq[,1], max.words=40, colors=brewer.pal(1, "Dark2"))

subset_dtm_tfidf_neg <- DocumentTermMatrix(subset_corpus_neg)
subset_dtm_tfidf_neg = removeSparseTerms(subset_dtm_tfidf_neg, 0.999)
freq = data.frame(sort(colSums(as.matrix(subset_dtm_tfidf_neg)), decreasing=TRUE))
wordcloud(rownames(freq), freq[,1], max.words=40, colors=brewer.pal(1, "Dark2"))

#PCA
subset <- cbind(subset, as.matrix(subset_dtm_tfidf))
subset$Score = as.factor(subset$Score)
subset2 <- subset[,c(-1,-2)]
PCA <- prcomp(subset2, scale=TRUE)
summary(PCA)
screeplot(PCA, npcs = 450, type = "lines")
subset3 <- data.frame(PCA$x[,(1:20)], subset$Score)
colnames(subset3)[21] <- 'Score'

#partition
set.seed(1)
myIndex<- createDataPartition(subset3$Score, p=0.7, list=FALSE)
trainSet <- subset3[myIndex,]
TestSet <- subset3[-myIndex,]

#Initial results
myCtrl <- trainControl(method="cv", number=10, classProbs = TRUE)
set.seed(1)
glm_fit <- train(Score ~., data = trainSet, method = "glm", trControl = myCtrl)
glm_class <- predict(glm_fit, newdata = TestSet)
confusionMatrix(glm_class, TestSet$Score, positive = 'Pos')

#model_weights <- ifelse(subset3$Score == "Neg", (1/table(subset3$Score)[1]) * 0.5, (1/table(subset3$Score)[2]) * 0.5)
#set.seed(1)
#glm_weighted_fit <- train(Score ~., data = trainSet, method = "glm", weights = model_weights, trControl = myCtrl)

#Handling class imbalance with sampling methods
set.seed(1)
#myCtrl$sampling <- "smote"
#glm_smote_fit <- train(Score ~ ., data = trainSet, method = "glm", trControl = myCtrl)
#glm_smote_class <- predict(glm_smote_fit, newdata = TestSet)
#confusionMatrix(glm_smote_class, TestSet$Score, positive = 'Pos')

myCtrl$sampling <- "down"

#Logistic Regression
glm_down_fit <- train(Score ~ ., data = trainSet, method = "glm", trControl = myCtrl)
glm_down_class <- predict(glm_down_fit, newdata = TestSet)
confusionMatrix(glm_down_class, TestSet$Score, positive = 'Pos')
glm_down_class_prob <- predict(glm_down_fit, newdata = TestSet, type = 'prob')
TestSet$Score <- as.numeric(TestSet$Score)
gains_table <- gains(TestSet$Score, glm_down_class_prob[,2])
gains_table
plot(c(0, gains_table$cume.pct.of.total*sum(TestSet$Score)) ~ c(0, gains_table$cume.obs), xlab = '# of cases', ylab = "Cumulative", type = "l")
lines(c(0, sum(TestSet$Score))~c(0, dim(TestSet)[1]), col="red", lty=2)
barplot(gains_table$mean.resp/mean(TestSet$Score), names.arg=gains_table$depth, xlab="Percentile", ylab="Lift", ylim=c(0,1.5), main="Decile-Wise Lift Chart")
roc_object <- roc(TestSet$Score, glm_class_prob[,2])
plot.roc(roc_object)
auc(roc_object)

#NaiveBayes
set.seed(1)
nb_down_fit <- train(Score ~ ., data = trainSet, method = "nb", trControl = myCtrl)
nb_down_class <- predict(nb_down_fit, newdata = TestSet)
confusionMatrix(nb_down_class, TestSet$Score, positive = 'Pos')
nb_down_class_prob <- predict(nb_down_fit, newdata = TestSet, type = 'prob')
TestSet$Score <- as.numeric(TestSet$Score)
gains_table <- gains(TestSet$Score, nb_down_class_prob[,2])
gains_table
plot(c(0, gains_table$cume.pct.of.total*sum(TestSet$Score)) ~ c(0, gains_table$cume.obs), xlab = '# of cases', ylab = "Cumulative", type = "l")
lines(c(0, sum(TestSet$Score))~c(0, dim(TestSet)[1]), col="red", lty=2)
barplot(gains_table$mean.resp/mean(TestSet$Score), names.arg=gains_table$depth, xlab="Percentile", ylab="Lift", ylim=c(0,1.5), main="Decile-Wise Lift Chart")
roc_object <- roc(TestSet$Score, nb_down_class_prob[,2])
plot.roc(roc_object)
auc(roc_object)