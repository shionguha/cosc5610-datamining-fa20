library(readxl)
library(tidyverse)
library(plyr)
#install.packages("ggmosaic")
library(ggmosaic)
#install.packages("caTools")
library(caTools)
library(dataPreparation)
library(leaps)
library(ROCR)
library(caret) # for model-building
library(DMwR) # for smote implementation
library(purrr) # for functional programming (map)
library(pROC) # for AUC calculations
library(PRROC) # for Precision-Recall curve calculations
library(sjmisc)

hl = read_excel("/Users/rjbrennan/Desktop/College/Data Mining - COSC 4610/Hazardous Liquid Research/PHMSA_Pipeline_Safety_Flagged_Incidents/hl2010toPresent.xlsx", sheet = 2)
hl = as.data.frame(lapply(hl, type.convert))

########################
##### DATA CLEANUP #####
########################
##### Removes any categorical data with no variable having a frequency of more than 1 #####
#print(sprintf("length: %d", length(hl)))
for(i in 1:length(hl))
{
  if(i<=length(hl))
  {
    if(count(hl[i])[1,2]<=1 && !is.numeric(count(hl[i])[1,1]))
    {
      hl = hl[-i]
      i = i-1
    }
  }
}

#attach(hl)
##### Manual Removal of Identification Fields #####
hl = select(hl, -c(DATAFILE_AS_OF,
                   REPORT_NUMBER,
                   SUPPLEMENTAL_NUMBER,
                   REPORT_TYPE,
                   OPERATOR_ID,
                   OPERATOR_STREET_ADDRESS,
                   OPERATOR_CITY_NAME,
                   OPERATOR_STATE_ABBREVIATION,
                   ONSHORE_STATE_ABBREVIATION,
                   ONSHORE_CITY_NAME,
                   ONSHORE_COUNTY_NAME,
                   OFFSHORE_STATE_ABBREVIATION,
                   PIPE_FAC_NAME,
                   OPERATOR_TYPE,
                   PREPARER_NAME,
                   PREPARER_EMAIL,
                   PREPARER_FAX,
                   AUTHORIZER_NAME,
                   AUTHORIZER_TELEPHONE,
                   AUTHORIZER_EMAIL,
                   ))

##### Manual Removal of Fields Related to Response Variables#####
hl = select(hl, -c(SIGNIFICANT,
                   IPE,
                   IA_IPE,
                   OM_IPE,
                   EST_COST_OPER_PAID,
                   EST_COST_OPER_PAID_CURRENT,
                   EST_COST_GAS_RELEASED,
                   EST_COST_GAS_RELEASED_CURRENT,
                   EST_COST_PROP_DAMAGE,
                   EST_COST_PROP_DAMAGE_CURRENT,
                   EST_COST_EMERGENCY,
                   EST_COST_EMERGENCY_CURRENT,
                   EST_COST_ENVIRONMENTAL,
                   EST_COST_OTHER,
                   EST_COST_OTHER_CURRENT,
                   TOTAL_COST,
                   TOTAL_COST_IN84,
                   TOTAL_COST_CURRENT
                   ))
#detach(hl)

##### Removal of Categories With Most Predominent Response: N/A #####
hl = hl[, which(colMeans(!is.na(hl)) == 1)]

##### Removal of Unnecessary Columns #####
#hl = select(hl, -c(SHUTDOWN_DATETIME,
#                   ACCIDENT_PSIG,
#                   MOP_PSIG))

##### Converting Dates to POSIXlt Objects #####
hl$LOCAL_DATETIME = as.POSIXlt(hl$LOCAL_DATETIME)
#hl$ON_SITE_DATETIME = as.POSIXlt(hl$ON_SITE_DATETIME)

##### Converting Net Loss to Categorical #####
#hl = hl %>% mutate(NET_LOSS_IND = factor(ifelse(NET_LOSS_BBLS != 0, "LOSS", "NO LOSS")))
#hl = select(hl, -c(NET_LOSS_BBLS,
#                   UNINTENTIONAL_RELEASE_BBLS,
#                   RECOVERED_BBLS
#                   ))

##### Expoloration of Environmental Cost or Lack Thereof #####
boxplot(hl$EST_COST_ENVIRONMENTAL_CURRENT[-175])
envizerofreq = count(hl$EST_COST_ENVIRONMENTAL_CURRENT)
envizerofreq = envizerofreq[order(envizerofreq$freq, decreasing = TRUE),]
head(envizerofreq)

##### Conversion of Environmental Cost to Categorical Variable #####
hl = hl %>% mutate(ENVIRONMENTAL_COST_IND = factor(ifelse(EST_COST_ENVIRONMENTAL_CURRENT != 0, "YES", "NO")))
hl = select(hl, -EST_COST_ENVIRONMENTAL_CURRENT)

##### Creating Data Set One for EnviCost #####
hl.envicost = hl


##############################################
##### DATA EXPLORATION AND VISUALIZATION #####
##############################################

countec = count(hl.envicost$ENVIRONMENTAL_COST_IND)
pie(countec$freq, labels = countec$x, main = "Environmental Impact")

hl.envicost.cat = c(2,3,4,5,7,8,9)

hl.envicost.cat = hl.envicost[-hl.envicost.cat]

hl.envicost.attributes = data.frame()
i=0
for(row in hl.envicost.cat)
{
  i = i+1
  myframe = data.frame(table(row, hl.envicost.cat$ENVIRONMENTAL_COST_IND))
  myframe2 = myframe
  for(j in 1:nrow(myframe))
  {
    myframe.sum = 0
    for(k in 1:nrow(myframe))
    {
      if(myframe[j,1] == myframe[k,1])
      {
        myframe.sum = myframe.sum + myframe[k,3]
      }
    }
    myframe2[j,3] = myframe[j,3]/myframe.sum
  }
  hl.envicost.attributes = rbind(hl.envicost.attributes, 
                                myframe2 %>% 
                                  mutate(attribute = names(hl.envicost.cat)[i]))
}
names(hl.envicost.attributes) = c("Type", "Environmental.Indicator", "Count", "Variable")
hl.envicost.attributes = hl.envicost.attributes[-(463:466),]

hl.envicost.attributes %>% ggplot(aes(x=Type, y=Count, fill=Environmental.Indicator )) +
  geom_bar(stat="identity") +
  facet_wrap(. ~ Variable, ncol = 6, scales = "free_x") +
  theme(axis.ticks.x = element_blank(), axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        plot.title = element_text(face = "bold", hjust=0.5),
        strip.text = element_text(face = "bold", size = 40),
        legend.position = c(0.83,0.05),
        legend.title = element_blank(),
        legend.text = element_text(face="bold",size=40),
        legend.key.size = unit(7, "line"),
        legend.background = element_rect(fill = "#e6e6e6")) +
  labs(Title = "Environmental Cost Indication by Hazardous Liquid Accident Variable") +
  scale_fill_discrete(breaks=c("YES", "NO"), labels = c("Environmental Impact", "No Environmental Impact"))

promising.attributes = c("COMMODITY_RELEASED_TYPE",
                         "FATALITY_IND",
                         "IGNITE_IND",
                         "ON_OFF_SHORE",
                         "WATER_CONTAM_IND")

hl.envicost.attributes.promising = hl.envicost.attributes %>% filter(Variable %in% promising.attributes)
hl.envicost.attributes.promising$Type = as.character(hl.envicost.attributes.promising$Type)
hl.envicost.attributes.promising$Type[1:10] = c("1","2","3","4","5","1","2","3","4","5")

hl.envicost.attributes.promising %>%
  ggplot(aes(x=Type, y=Count, fill=Environmental.Indicator)) +
  geom_bar(stat="identity") +
  facet_wrap(. ~ Variable, ncol = 3, scales = "free_x") +
  theme(axis.text.y = element_text(angle=05, size = 30),
        axis.text.x = element_text(size = 30),
        plot.title = element_text(face = "bold", hjust=0.5),
        strip.text = element_text(face = "bold", size = 40),
        legend.position = "bottom",
        legend.title = element_blank(),
        legend.text = element_text(face="bold", size = 40),
        legend.key.size = unit(7, "line"),
        legend.background = element_rect(fill = "#e6e6e6")) +
  labs(Title = "Environmental Cost Indication by Hazardous Liquid Accident Variable") +
  scale_fill_discrete(breaks=c("YES", "NO"), labels = c("Environmental Impact", "No Environmental Impact"))




##########################
##### MODEL BUILDING #####
##########################
hl = hl.envicost
hl = select(hl, -c(LOCAL_DATETIME,CAUSE_DETAILS, MAP_SUBCAUSE))
baseline = countec$freq[2]/sum(countec$freq)

##### Splitting data into training and testing #####
set.seed(45)
split = sample.split(hl$ENVIRONMENTAL_COST_IND, SplitRatio = 0.75)

hl.train = subset(hl, split == T)
hl.test = subset(hl, split == F)

##### Scaling Quantitative Data #####
scales.cols = c("LOCATION_LONGITUDE", "LOCATION_LATITUDE", "UNINTENTIONAL_RELEASE_BBLS",
                "RECOVERED_BBLS", "NET_LOSS_BBLS")
scales = build_scales(dataSet = hl, cols = scales.cols, verbose = F)

hl.train = fastScale(dataSet = hl.train, scales = scales, verbose = F)
hl.test = fastScale(dataSet = hl.test, scales = scales, verbose = F)

hl.scales = select(hl, all_of(scales.cols))
#Boxplot of unscaled quantitative variables with outliers
boxplot(hl.scales, names = c("Longitude", "Latitude", "Released", "Recovered", "Net Loss"))
#Boxplot of unscaled quantitative variables without outliers
boxplot(hl.scales, names = c("Longitude", "Latitude", "Released", "Recovered", "Net Loss"), outline = F)

hl.scales = select(hl.train, all_of(scales.cols))
#Boxplot of scaled quantitative variables with outliers
boxplot(hl.scales, names = c("Longitude", "Latitude", "Released", "Recovered", "Net Loss"))
#Boxplot of scaled quantitative variables without outliers
boxplot(hl.scales, names = c("Longitude", "Latitude", "Released", "Recovered", "Net Loss"), outline = F)

##### Encoding Categorical Data #####

hl.cat = names(hl)[!(names(hl) %in% c("IYEAR", "LOCATION_LONGITUDE", "LOCATION_LATITUDE", "UNINTENTIONAL_RELEASE_BBLS",
                                      "RECOVERED_BBLS", "NET_LOSS_BBLS", "ENVIRONMENTAL_COST_IND"))]

encoding = build_encoding(dataSet = hl, cols = hl.cat, verbose = F)
hl.train = one_hot_encoder(dataSet = hl.train, encoding = encoding, drop = TRUE, verbose = F)
hl.test = one_hot_encoder(dataSet = hl.test, encoding = encoding, drop = TRUE, verbose = F)

bijections <- whichAreBijection(dataSet = hl.train, verbose = F)
delete = names(hl.train)[bijections]

hl.train = select(hl.train, -all_of(delete))
hl.test = select(hl.test, -all_of(delete))

##### Class Imbalance #####
#Classes are already balanced, 46% No, 54% Yes
prop.table(table(hl.train$ENVIRONMENTAL_COST_IND))

##### Baseline Model #####
train.control = trainControl(method = "none")
hl.log0 = train(ENVIRONMENTAL_COST_IND ~ ., data = hl.train, method = "glm",
                trControl = train.control)
hl.predict.test0 = round(predict(hl.log0, newdata = hl.test, type = "prob"),4)[,2]
confusionMatrix(factor(ifelse(hl.predict.test0>0.5,"YES","NO")),
                hl.test$ENVIRONMENTAL_COST_IND)

ROCRpred = prediction(hl.predict.test0, hl.test$ENVIRONMENTAL_COST_IND)

ROCRperf = performance(ROCRpred, "tpr", "fpr")
AUC = as.numeric(performance(ROCRpred, "auc")@y.values)

plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))
text(x=0.7, y=0.2, labels=sprintf("AUC: %.4f", AUC))

#Accuracy: 67.11%
#Sensitivity: 54.07%
#Specificity: 78.45%
#AUC: 0.7395

##### Variable Selection #####
hl.train.bare = hl.train
names(hl.train.bare) = as.character(1:ncol(hl.train))
names(hl.train.bare)[7] = "ENVIRONMENTAL_COST_IND"

fwd = regsubsets(ENVIRONMENTAL_COST_IND ~ ., data = hl.train.bare, 
                 nvmax = 20, method = "forward", really.big = TRUE)
bwd = regsubsets(ENVIRONMENTAL_COST_IND ~ ., data = hl.train.bare, 
                 nvmax = 20, method = "backward", really.big = TRUE)
exh = regsubsets(ENVIRONMENTAL_COST_IND ~ ., data = hl.train.bare, 
                 nvmax = 20, method = "seqrep", really.big = TRUE)

fwd.sum = summary(fwd)
bwd.sum = summary(bwd)
exh.sum = summary(exh)

#Plots of variable selction methods by sumarry variable
plot(summary(fwd)$adjr2, col = "blue", type = "p", xlab = "Model size", 
     ylab = "adjr2")
points(summary(bwd)$adjr2, col = "red")
points(summary(exh)$adjr2, col = "orange")
legend("topleft", c("Forward","Backward", "Stepwise"), 
       pch=1, col = c("blue","red", "orange"))

plot(summary(fwd)$bic, col = "blue", type = "p", xlab = "Model size", 
     ylab = "bic")
points(summary(bwd)$bic, col = "red")
points(summary(exh)$bic, col = "orange")

plot(summary(fwd)$cp, col = "blue", type = "p", xlab = "Model size", 
     ylab = "Cp")
points(summary(bwd)$cp, col = "red")
points(summary(exh)$cp, col = "orange")

plot(summary(fwd)$rss, col = "blue", type = "p", xlab = "Model size", 
     ylab = "rss")
points(summary(bwd)$rss, col = "red")
points(summary(exh)$rss, col = "orange")


hl.step = regsubsets(ENVIRONMENTAL_COST_IND ~ ., data = hl.train.bare, nbest = 1, nvmax = 30, 
                     method = "seqrep", really.big = TRUE)
hl.step2 = regsubsets(ENVIRONMENTAL_COST_IND ~ ., data = hl.train.bare, nbest = 10, nvmax = 30, 
                     method = "seqrep", really.big = TRUE)
adjr2 = summary(hl.step)$adjr2
adjr2.2 = summary(hl.step2)$adjr2
rss = summary(hl.step)$rss
rss.2 = summary(hl.step2)$rss
cp = summary(hl.step)$cp
cp.2 = summary(hl.step2)$cp
bic = summary(hl.step)$bic
bic.2 = summary(hl.step2)$bic
p = rowSums(summary(hl.step)$which)
p.2 = rowSums(summary(hl.step2)$which)

#Plots of stepwise variable selection by summary variable
plot(adjr2.2 ~ p.2, xlab = "# of Variables", ylab = "Adjusted r2")
points(adjr2 ~ p, col = "orange", pch = 16)
plot(rss.2 ~ p.2, xlab = "# of Variables", ylab = "Residual Sum of Squares")
points(rss ~ p, col = "orange", pch = 16)
plot(cp.2 ~ p.2, xlab = "# of Variables", ylab = "Mallow's Cp")
points(cp ~ p, col = "orange", pch = 16)
plot(bic.2 ~ p.2, xlab = "# of Variables", ylab = "BIC")
points(bic ~ p, col = "orange", pch = 16)


hl.step = regsubsets(ENVIRONMENTAL_COST_IND ~ ., data = hl.train.bare, nbest = 10, nvmax = 20, 
                     method = "seqrep", really.big = TRUE)
hl.step.sum = summary(hl.step)

bad.vars = c()
for(i in 1:ncol(hl.train.bare))
{
  if(all(!hl.step.sum$which[,i]))
    bad.vars = append(bad.vars, colnames(hl.step.sum$which)[i])
}
bad.vars = substring(bad.vars, 2, nchar(bad.vars)-1)
bad.vars = as.numeric(bad.vars)
bad.vars = names(hl.train.bare)[bad.vars]

hl.train.bare = select(hl.train.bare, -all_of(bad.vars))

hl.step = regsubsets(ENVIRONMENTAL_COST_IND ~ ., data = hl.train.bare, nbest = 1, nvmax = 20, 
                     method = "seqrep", really.big = TRUE)
hl.step.sum = summary(hl.step)

#Table of Variables in each model as r squared increases
plot(hl.step, scale = "adjr2", main = "Variables Included vs. r^2")

good.vars = c(1,2,4,10,12,16,18,24,26,38,41,46,49,50,53,56,59,61,63,68)
good.vars = names(hl.train)[good.vars]
hl.train.good = select(hl.train, all_of(good.vars))
hl.train.good = hl.train.good %>% mutate(ENVIRONMENTAL_COST_IND = hl.train$ENVIRONMENTAL_COST_IND)
good.vars = paste("`", good.vars, sep = "")
good.vars = paste(good.vars, "`", sep = "")


##### Logit Model #####

hl.formula = as.formula(paste("ENVIRONMENTAL_COST_IND ~", paste(good.vars, collapse="+")))

hl.log = train(hl.formula, data = hl.train, method = "glm",
               trControl = train.control)

hl.predict.test = round(predict(hl.log, newdata = hl.test, type = "prob"),4)[,2]

ROCRpred = prediction(hl.predict.train, hl.train$ENVIRONMENTAL_COST_IND)

ROCRperf = performance(ROCRpred, "tpr", "fpr")
AUC = as.numeric(performance(ROCRpred, "auc")@y.values)

plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))
text(x=0.7, y=0.2, labels=sprintf("AUC: %.4f", AUC))

ROCRperf = performance(ROCRpred, "acc")

plot(ROCRperf)
abline(v=0.493, col="red")
abline(v=0.513, col="red")
abline(h=0.703, col="red")


confusionMatrix(factor(ifelse(hl.predict.test>0.5,"YES","NO")),
                hl.test$ENVIRONMENTAL_COST_IND)

#Accuracy: 67.30%
#Sensitivity: 54.07%
#Specificity: 78.80%
#AUC: 0.7671








##### Cross-Validation #####

hl = fastScale(dataSet = hl, scales = scales, verbose = F)
hl = one_hot_encoder(dataSet = hl, encoding = encoding, drop = TRUE, verbose = F)

train.control = trainControl(method = "repeatedcv", number = 10, repeats = 5)
hl.log2 = train(hl.formula, data = hl, method = "glm",
                trControl = train.control)
hl.predict.test2 = round(predict(hl.log2, newdata = hl.test, type = "prob"),4)[,2]
confusionMatrix(factor(ifelse(hl.predict.test2>0.5,"YES","NO")),
                hl.test$ENVIRONMENTAL_COST_IND)

ROCRpred = prediction(hl.predict.test2, hl.test$ENVIRONMENTAL_COST_IND)

ROCRperf = performance(ROCRpred, "tpr", "fpr")
AUC = as.numeric(performance(ROCRpred, "auc")@y.values)

plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))
text(x=0.7, y=0.2, labels=sprintf("AUC: %.4f", AUC))

ROCRperf = performance(ROCRpred, "acc")

plot(ROCRperf)

#Accuracy: 67.58%
#Sensitivity: 54.88%
#Specificity: 78.62%
#AUC: 0.7435


