# Load Libraries
library(dataPreparation)
library(dplyr)
library(forcats)
library(ggplot2)
library(DMwR)
library(tidyverse)
library(caret)
library(broom)
library(pscl)
library(modelr)
library(ggpubr)

# Load Data
orig_ds <- read.csv("Beilke-005810314.csv", header = TRUE)
str(orig_ds)

############################################################
#######             Data Preparation                 #######
############################################################

# Used tutorial - https://cran.r-project.org/web/packages/dataPreparation/vignettes/train_test_prep.html 

# Create binary variable for case disposition
orig_ds$substantiated <- orig_ds$board_disposition

count(orig_ds, orig_ds$board_disposition)

# Convert Disposition into Binary Variable
orig_ds$substantiated[orig_ds$substantiated == "Unsubstantiated"]<-"0"
orig_ds$substantiated[orig_ds$substantiated == "Exonerated"] <- "0"

orig_ds$substantiated[orig_ds$substantiated == "Substantiated (Charges)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated (Command Discipline A)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated (Command Discipline B)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated (Command Discipline)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated (Command Lvl Instructions)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated (Formalized Training)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated (Instructions)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated (No Recommendations)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated (MOS Unidentified)"]<-"Substantiated"
orig_ds$substantiated[orig_ds$substantiated == "Substantiated"]<-"1"

# Convert New "Substantiated Variable to Factor
orig_ds$substantiated <- as.factor(orig_ds$substantiated)

# Drop Categorical Board Disposition and Other Useless variables
cleaned_ds <- select(orig_ds, -c(unique_mos_id, first_name, last_name, complaint_id))
cleaned_ds <- select(cleaned_ds, -c(command_now, shield_no, month_received, month_closed, year_closed))
cleaned_ds <- select(cleaned_ds, -c(command_at_incident, rank_now, rank_incident, rank_abbrev_now))
cleaned_ds <- select(cleaned_ds, -c(precinct, allegation, contact_reason, outcome_description, board_disposition))

# Drop Null Age/Gender/Ethnicity 
#compl_eth <- count(cleaned_ds, cleaned_ds$complainant_ethnicity)
#print(compl_eth)

cleaned_ds = cleaned_ds[!cleaned_ds$complainant_ethnicity == "Unknown",]
cleaned_ds = cleaned_ds[!cleaned_ds$complainant_ethnicity == "",]

cleaned_ds = cleaned_ds[!cleaned_ds$complainant_gender == "Not described",]
cleaned_ds = cleaned_ds[!cleaned_ds$complainant_gender == "",]


compl_age <- count(cleaned_ds, cleaned_ds$complainant_age_incident)
print(compl_age)

cleaned_ds = cleaned_ds[!cleaned_ds$complainant_age_incident == "-1",]
cleaned_ds = cleaned_ds[!is.na(cleaned_ds$complainant_age_incident),]
compl_age <- count(cleaned_ds, cleaned_ds$complainant_age_incident)
print(compl_age)

glimpse(cleaned_ds)


# Discretize MOS and Complainant Age
mos_bins <- build_bins(data=cleaned_ds,cols="mos_age_incident",n_bins=5,type="equal_freq")
print(mos_bins)

cleaned_ds <- fastDiscretization(data = cleaned_ds, bins = list(mos_age_incident = c(0,27,30,33,37,+Inf)))
print(table(cleaned_ds$mos_age_incident))

compl_bins <- build_bins(data=cleaned_ds,cols="complainant_age_incident",n_bins=5,type="equal_freq")
print(compl_bins)

cleaned_ds <- fastDiscretization(data = cleaned_ds, bins = list(complainant_age_incident = c(0,22,27,34,43,+Inf)))
print(table(cleaned_ds$complainant_age_incident))

# Discretize Year Received Variable
year_bins <- build_bins(data=cleaned_ds,cols="year_received",n_bins=5,type="equal_width")
print(year_bins)

cleaned_ds <- fastDiscretization(data = cleaned_ds, bins = list(year_received = c(-Inf,1998,2002,2007,2011,2015,2020)))
print(table(cleaned_ds$year_received))

# convert all to factors for encoding
cleaned_ds$mos_ethnicity <- as.factor(as.character(cleaned_ds$mos_ethnicity))
cleaned_ds$mos_gender <- as.factor(as.character(cleaned_ds$mos_gender))
cleaned_ds$mos_age_incident <- as.factor(as.character(cleaned_ds$mos_age_incident))
cleaned_ds$complainant_ethnicity <- as.factor(as.character(cleaned_ds$complainant_ethnicity))
cleaned_ds$complainant_gender <- as.factor(as.character(cleaned_ds$complainant_gender))
cleaned_ds$complainant_age_incident <- as.factor(as.character(cleaned_ds$complainant_age_incident))
cleaned_ds$fado_type <- as.factor(as.character(cleaned_ds$fado_type))
cleaned_ds$rank_abbrev_incident <- as.factor(as.character(cleaned_ds$rank_abbrev_incident))

# Remove Useless Variables 
constant_cols <- whichAreConstant(cleaned_ds)
double_cols <- whichAreInDouble(cleaned_ds)
bijection_cols <- whichAreBijection(cleaned_ds)
print(names(cleaned_ds)[bijection_cols])

#cleaned_ds <- select(cleaned_ds, -c(bijection_cols))

str(cleaned_ds)


############################################################
#######          Create Train/Test Sets              #######
############################################################

set.seed(123)
train_samples <- cleaned_ds$substantiated %>% createDataPartition(p=.8,list=FALSE)

train_data <- cleaned_ds[train_samples,]
test_data <- cleaned_ds[-train_samples,]


############################################################
#######               Build Models                   #######
############################################################

# Null Model
model_null <- glm(substantiated ~ 1, data = train_data, family = "binomial")

# Original unbalanced model using MOS/Complainant Gender and Ethnicity
model1 <- glm(substantiated ~ mos_gender+complainant_gender+mos_ethnicity+complainant_ethnicity, data = train_data, family='binomial')
anova(model1, test = "LR")
summary(model1)

anova(model1, test = "Chisq")

varImp(model1)

# Model 2 - Remove MOS Ethnicity
model2 <- glm(substantiated ~ mos_gender+complainant_gender+complainant_ethnicity, data = train_data, family='binomial')
anova(model2, test = "LR")
summary(model2)

anova(model1, model2, test="LR")

# Model 3 - Include MOS ethnicity and year received
formula3 <- substantiated ~ mos_gender+mos_ethnicity+complainant_gender+complainant_ethnicity+year_received
model3 <- glm(formula3, data = train_data, family='binomial')
summary(model3)
anova(model3, test = "LR")
anova(model1,model3, test= "Chisq")

str(test_data)

# Model 4 - Include MOS and Complainant Age
model4 <- glm(substantiated ~ mos_gender+mos_ethnicity+complainant_gender+complainant_ethnicity+year_received+mos_age_incident+complainant_age_incident, data = train_data, family='binomial')
summary(model4)
anova(model4, test = "LR")
anova(model3,model4, test= "Chisq")

# Model 5 - Include Type of Complaint
formula5 <- substantiated ~ mos_gender+mos_ethnicity+complainant_gender+complainant_ethnicity+year_received+fado_type
model5 <- glm(formula5, data = train_data, family='binomial')
summary(model5)
anova(model5, test = "LR")
anova(model3,model5, test= "Chisq")

# Model 6 - Include Officer Rank
model6 <- glm(substantiated ~ mos_gender+mos_ethnicity+complainant_gender+complainant_ethnicity+year_received+fado_type+rank_abbrev_incident, data = train_data, family='binomial')
summary(model6)
anova(model6, test = "LR")
anova(model5,model6, test= "Chisq")

count(cleaned_ds, cleaned_ds$rank_abbrev_incident)


############################################################
#######              Compare Models                  #######
############################################################

# Comparison of Models 1,3 and 5 using McFadden Test (Psuedo R2 Test)
list(model1 = pscl::pR2(model1)["McFadden"],
     model3 = pscl::pR2(model3)["McFadden"],
     model5 = pscl::pR2(model5)["McFadden"])


# Plotting residuals of Null Model
null_model_data <- augment(model_null) %>% mutate(index = 1:n())
ggplot(null_model_data, aes(index, .std.resid, color=substantiated)) + geom_point(alpha=.2) + geom_ref_line(h=0) + ggtitle("Null Model Residuals")

# Plotting residuals of Model 1
model1_data <- augment(model1) %>% mutate(index = 1:n())
m1_resid <- ggplot(model1_data, aes(index, .std.resid, color=substantiated)) + geom_point(alpha=.2) + geom_ref_line(h=0) + ggtitle("Model 1 Residuals") 

# Plotting residuals of Model 3 
model3_data <- augment(model3) %>% mutate(index = 1:n())
m3_resid <- ggplot(model3_data, aes(index, .std.resid, color=substantiated)) + geom_point(alpha=.2) + geom_ref_line(h=0) + ggtitle("Model 3 Residuals")


# Plotting residuals of Model 5 
model5_data <- augment(model5) %>% mutate(index = 1:n()) 
# Remove one outlier that is fucking up the plot
which(model5_data$.std.resid > 1000)
model5_data <- model5_data[-20555,]
m5_resid <- ggplot(model5_data, aes(index, .std.resid, color=substantiated)) + geom_point(alpha=.2) + geom_ref_line(h=0) + ggtitle("Model 5 Residuals")

figure <- ggarrange(m1_resid, m3_resid, m5_resid,
                    ncol = 2, nrow = 2)
figure

# MAE
train_data.numeric <- train_data
train_data.numeric$substantiated <- as.numeric(as.character(train_data.numeric$substantiated))
glimpse(train_data.numeric)

mae(model1, data = train_data.numeric)
mae(model3, data = train_data.numeric)
mae(model5, data = train_data.numeric)


############################################################
#######          Address Class Imbalance            #######
############################################################

# SMOTE 
smote_train <- train_data

# Pre-SMOTE Class Distribution:
subst_ct <- count(smote_train, smote_train$substantiated)
print(subst_ct)

smote_train <- SMOTE(substantiated ~ ., data = smote_train, perc.over = 100)

# Post-SMOTE Class Distribution
subst_ct <- count(smote_train, smote_train$substantiated)
print(subst_ct)

# SMOTE model using same variables as model 5
smote_model <- glm(formula5, data = smote_train, family="binomial")
summary(smote_model)
smote_data <- augment(smote_model) %>% mutate(index = 1:n())
smote_resid <- ggplot(smote_data, aes(index, .std.resid, color=substantiated)) + geom_point(alpha=.2) + geom_ref_line(h=0) + ggtitle("SMOTE Model Residuals")

list(model5 = pscl::pR2(model5)["McFadden"],
     SMOTE_model = pscl::pR2(smote_model)["McFadden"])

figure2 <- ggarrange(m5_resid, smote_resid,
                    ncol = 2, nrow = 2)
figure2

############################################################
#######               Cross-Validation               #######
############################################################

# Leave One Out - Too resource consuming
#train_control <- trainControl(method = "LOOCV")
#loo_model <- train(substantiated ~ mos_gender+mos_ethnicity+complainant_gender+complainant_ethnicity+year_received+fado_type, 
#                   data = cleaned_ds, method = "glm", family="binomial" trControl = train_control)
#summary(loo_model)

# K-Fold 
train_control <- trainControl(method = "cv", number = 10)
kfold_model <- train(substantiated ~ mos_gender+mos_ethnicity+complainant_gender+complainant_ethnicity+year_received+fado_type, 
                     data = cleaned_ds, method = "glm", family="binomial" , trControl = train_control)

summary(kfold_model)

# Repeated K-Fold 
train_control <- trainControl(method = "repeatedcv", number = 10, repeats = 5)
rkf_model <- train(substantiated ~ mos_gender+mos_ethnicity+complainant_gender+complainant_ethnicity+year_received+fado_type, 
                   data = cleaned_ds, method = "glm", trControl = train_control)
summary(rkf_model$finalModel)


############################################################
#######          Apply Models to Test Data           #######
############################################################

# Model 1
predict.m1 <- predict(model1, test_data, type = "response")
predict.m1.train <- predict(model1, train_data, type = "response")
table(test_data$substantiated, predict.m1 > .5)
pred1 = prediction(predict.m1, test_data$substantiated)

# Model 3
predict.m3 <- predict(model3, test_data, type = "response")
predict.m3.train <- predict(model3, train_data, type = "response")
table(test_data$substantiated, predict.m3 > .5)
pred3 = prediction(predict.m3, test_data$substantiated)

# Model 5
predict.m5 <- predict(model5, test_data, type = "response")
predict.m5.train <- predict(model5, train_data, type = "response")
table(test_data$substantiated, predict.m5 > .5)
pred5 = prediction(predict.m5, test_data$substantiated)

# SMOTE Model
predict.smote <- predict.glm(smote_model, test_data, type = "response")
predict.smote.train <- predict.glm(smote_model, smote_data, type = "response")
table(test_data$substantiated, predict.smote > .5)
pred_smote = prediction(predict.smote, test_data$substantiated)


# K-Fold Model
predict.kf <- predict(kfold_model, test_data, type = "prob")
table(test_data$substantiated, predict.kf$'1' > 0.5)
pred_kf = prediction(predict.kf$'1', test_data$substantiated)

# Repeated K-Fold model
predict.rkf <- predict(rkf_model, test_data, type = "prob")
table(test_data$substantiated, predict.rkf$'1' > 0.5)
pred_rkf = prediction(predict.rkf$'1', test_data$substantiated)

############################################################
#######             Compare Results                  #######
############################################################

# Confusion Matrices
list(
  model1 = table(test_data$substantiated, predict.m1 > .5) %>% prop.table() %>% round(3),
  model3 = table(test_data$substantiated, predict.m3 > .5) %>% prop.table() %>% round(3),
  model5 = table(test_data$substantiated, predict.m5 > .5) %>% prop.table() %>% round(3),
  smote_model = table(test_data$substantiated, predict.smote > .5) %>% prop.table() %>% round(3),
  kfold_model = table(test_data$substantiated, predict.kf$'1' > .5) %>% prop.table() %>% round(3),
  rkfold_model = table(test_data$substantiated, predict.rkf$'1' > .5) %>% prop.table() %>% round(3)
)

list(
  model1 = table(test_data$substantiated, predict.m1 > .5) ,
  model3 = table(test_data$substantiated, predict.m3 > .5) ,
  model5 = table(test_data$substantiated, predict.m5 > .5),
  smote_model = table(test_data$substantiated, predict.smote > .5),
  kfold_model = table(test_data$substantiated, predict.kf$'1' > .5),
  rkfold_model = table(test_data$substantiated, predict.rkf$'1' > .5) 
)

# ROC Curves
roc1 = performance(pred1, "tpr", "fpr")
roc3 = performance(pred3, "tpr", "fpr")
roc5 = performance(pred5, "tpr", "fpr")
roc_smote = performance(pred_smote, "tpr", "fpr")
roc_kf = performance(pred_kf, "tpr", "fpr")
roc_rkf = performance(pred_rkf, "tpr", "fpr")

plot(roc1, lwd = 2, main = "ROC Curves", col = 1)
plot(roc3, add = T ,lwd = 2, col = 3)
plot(roc5, add = T , lwd = 2, col = 5)
plot(roc_smote, add = T , lwd = 2, col = 7)
plot(roc_kf, add = T , col = 4)
plot(roc_rkf, add = T, lwd = 2, col = 6)
abline(a = 0, b = 1) 
legend("bottomright", legend = c("Model 1","Model 3","Model 5", "SMOTE","K-Fold","Rep. K-Fold"), col = c(1,3,5,7,4,6), pch = 19, bty = "n")

# AUC
auc1 = performance(pred1, "auc")
auc3 = performance(pred3, "auc")
auc5 = performance(pred5, "auc")
auc_smote = performance(pred_smote, "auc")
auc_kf = performance(pred_kf, "auc")
auc_rkf = performance(pred_rkf, "auc")

list(Model1 = auc1@y.values,
     Model3 = auc3@y.values,
     Model5 = auc5@y.values,
     Model_smote = auc_smote@y.values,
     Model_kf = auc_kf@y.values,
     Model_rkf = auc_rkf@y.values
)

# Create Copy of Results with Numeric Outcomes (Not Factors)
test_data.numeric <- test_data
test_data.numeric$substantiated <- as.numeric(as.character(test_data.numeric$substantiated))

smote_data.numeric <- smote_data
smote_data.numeric$substantiated <- as.numeric(as.character(smote_data.numeric$substantiated))


# RMSE 
rmse <- function(x1,x2) {sqrt(mean((x1-x2)^2))}

list(
  Model1.RMSE = rmse(predict.m1, test_data.numeric$substantiated),
  Model3.RMSE = rmse(predict.m3, test_data.numeric$substantiated),
  Model5.RMSE = rmse(predict.m5, test_data.numeric$substantiated),
  Model_SMOTE.RMSE = rmse(predict.smote , test_data.numeric$substantiated),
  Model_KFold.RMSE = rmse(predict.kf$'1', test_data.numeric$substantiated),
  Model_RepKFold.RMSE = rmse(predict.rkf$'1', test_data.numeric$substantiated)
)

# RMSE on train
list(
  Model1.RMSE = rmse(predict.m1.train, train_data.numeric$substantiated),
  Model3.RMSE = rmse(predict.m3.train, train_data.numeric$substantiated),
  Model5.RMSE = rmse(predict.m5.train, train_data.numeric$substantiated),
  Model_SMOTE.RMSE = rmse(predict.smote.train , smote_data.numeric$substantiated)
)


# MAE
mae_cust <- function(x1,x2) { ((sum(abs(x2$substantiated-x1))) / nrow(x2))}

list(
  Model1.MAE = mae_cust(predict.m1, test_data.numeric),
  Model3.MAE = mae_cust(predict.m3, test_data.numeric),
  Model5.MAE = mae_cust(predict.m5, test_data.numeric),
  Model_SMOTE.MAE = mae_cust(predict.smote , test_data.numeric),
  Model_KFold.MAE = mae_cust(predict.kf$'1', test_data.numeric),
  Model_RepKFold.MAE = mae_cust(predict.rkf$'1', test_data.numeric)
)

# MAE on train
list(
  Model1.MAE = mae_cust(predict.m1.train, train_data.numeric),
  Model3.MAE = mae_cust(predict.m3.train, train_data.numeric),
  Model5.MAE = mae_cust(predict.m5.train, train_data.numeric),
  ModelSMOTE.MAE = mae_cust(predict.smote.train, smote_data.numeric)
)

# R2
nullmod_train <- glm(substantiated~1, data=train_data,family="binomial")
nullmod_full <- glm(substantiated~1, data=cleaned_ds,family="binomial")
nullmod_smote <- glm(substantiated~1, data=smote_train,family="binomial")

# Use McFadden's R2 - Wrote own since CV models are 'train' objects and do not seem to play well with pR2() 
# Taking null model for the data set that each model was trained on (i.e. CV data sets were trained on cleaned_data, while madel 1/3/5 were trained on train_data)
r2_cust <- function(x1,x2) {
  1 - (logLik(x1)/logLik(x2))
} 

list(
  Model1.R2 = r2_cust(model1, nullmod_train),
  Model3.R2 = r2_cust(model3, nullmod_train),
  Model5.R2 = r2_cust(model5, nullmod_train),
  Model_SMOTE.R2 = r2_cust(smote_model, nullmod_smote),
  Model_KFold.R2 = r2_cust(kfold_model$finalModel, nullmod_full),
  Model_RepKFold.R2 = r2_cust(rkf_model$finalModel, nullmod_full)
)

# Outputs match pR2 McFadden output for model 1/3/5 and SMOTE model
list(
  model1 = pscl::pR2(model1)["McFadden"],
  model3 = pscl::pR2(model3)["McFadden"],
  model5 = pscl::pR2(model5)["McFadden"],
  SMOTE_model = pscl::pR2(smote_model)["McFadden"])


