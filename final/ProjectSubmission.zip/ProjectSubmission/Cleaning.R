## ------------------------------------------------------------------------------------------------------------------------
getwd()
load("D:/Kimberly/Documents/Fall2020/Datamining/DataminingR/Project/BoardGames.rda")
head(BoardGames)
bg.df<-as.data.frame(BoardGames)
head(bg.df)

## ------------------------------------------------------------------------------------------------------------------------
library(dplyr)
library(tidyr)
library(tidyverse)
library(lubridate)
library(gdata)
library(janitor)
library(dummies)
library(splitstackshape)



## ------------------------------------------------------------------------------------------------------------------------
library(dataPreparation)


## ------------------------------------------------------------------------------------------------------------------------
#names(bg.df)
#Remove columns that are clearly not useful for dataset:
# details.description, details.image, attributes.total, stats.bayesaverage, stats.family.abstracts.bayesaverage, stats.family.abstracts.pos, stats.family.cgs.bayesaverage, stats.gamily.cgs.pos, stats.family.childrensgames.bayesaverage, stats.family.childrensgames.pos, stats.family.familygames.pos, stats.family.partygames.bayesaverage, stats.family.partygames.pos, stats.family.strategygames.bayesaverage, stats.family.strategygames.pos, stats.family.thematic.bayesaverage, stats.family.thematic.pos, stats.family.wargames.bayesaverage,  stats.family.wargames.pos, stats.median, stats.subtype.boardgame.bayesaverage, stats.subtype.boardgame.pos, stats.numweights, polls.suggested_numplayers.1, polls.suggested_numplayers.2, polls.suggested_numplayers.3, polls.suggested_numplayers.4, polls.suggested_numplayers.5, polls.suggested_numplayers.6, polls.suggested_numplayers.7, polls.suggested_numplayers.8, polls.suggested_numplayers.9, polls.suggested_numplayers.Over, polls.suggested_playerage, attributes.t.links.concat.2...., stats.family.amiga.bayesaverage, stats.family.amiga.pos, stats.family.arcade.bayesaverage, stats.family.arcade.pos, stats.family.atarist.bayesaverage, stats.family.atarist.pos, stats.family.commodore64.basyesaverage, stats.family.commodore64.pos, stats.subtype.rpgitem.bayesaverage, stats.subtype.rpgitem.pos, stats.subtype.videogame.bayesaverage, stats.subtype.videogame.pos
bg.df.initalremoval <- bg.df %>% subset(select = -c(details.description, details.image, attributes.total, stats.bayesaverage, stats.family.abstracts.bayesaverage, stats.family.abstracts.pos, stats.family.cgs.bayesaverage, stats.family.cgs.pos, stats.family.childrensgames.bayesaverage, stats.family.childrensgames.pos, stats.family.familygames.pos, stats.family.partygames.bayesaverage, stats.family.partygames.pos, stats.family.strategygames.bayesaverage, stats.family.strategygames.pos, stats.family.thematic.bayesaverage, stats.family.thematic.pos, stats.family.wargames.bayesaverage,  stats.family.wargames.pos, stats.median, stats.subtype.boardgame.bayesaverage, stats.subtype.boardgame.pos, stats.numweights, polls.suggested_numplayers.1, polls.suggested_numplayers.2, polls.suggested_numplayers.3, polls.suggested_numplayers.4, polls.suggested_numplayers.5, polls.suggested_numplayers.6, polls.suggested_numplayers.7, polls.suggested_numplayers.8, polls.suggested_numplayers.9, polls.suggested_numplayers.10, polls.suggested_numplayers.Over, polls.suggested_playerage, attributes.t.links.concat.2...., stats.family.amiga.bayesaverage, stats.family.amiga.pos, stats.family.arcade.bayesaverage, stats.family.arcade.pos, stats.family.atarist.bayesaverage, stats.family.atarist.pos, stats.family.commodore64.bayesaverage, stats.family.commodore64.pos, stats.subtype.rpgitem.bayesaverage, stats.subtype.rpgitem.pos, stats.subtype.videogame.bayesaverage, stats.subtype.videogame.pos, details.thumbnail,stats.family.familygames.bayesaverage,game.id,stats.stddev))

constant_cols<- whichAreConstant(bg.df.initalremoval)
double_cols<- whichAreInDouble(bg.df.initalremoval)
bijections_cols <- whichAreBijection(bg.df.initalremoval)
bg.df.initalremoval$details.playingtime=NULL

#Look at columns again
names(bg.df.initalremoval)
#View(head(bg.df.initalremoval))

#Examine, but likely remove
#attributes.boardgameartist, attributes.boardgamecompilation, attributes.boardgameexpansion, attributes.boardgamefamily, attributes.boardgameimplementation, attributes.boardgameintegration, attributes.boardgamepublisher, stats.numcomments, stats.owned, stats.stddev


length(unique(bg.df.initalremoval$attributes.boardgameartist))
#There are 14086 different artists, way to many to make a reasonable category for but check to see if any stand out
#View(bg.df.initalremoval %>% group_by(attributes.boardgameartist) %>%
#  summarise(n()))
#Most common is unaccredited, but not any values that are super prominent, remove
bg.df.initalremoval$attributes.boardgameartist=NULL

sum(is.na(bg.df.initalremoval$attributes.boardgamecompilation))
nrow(bg.df.initalremoval)
#88105 out of 90400 are NA
#View(bg.df.initalremoval %>% group_by(attributes.boardgamecompilation) %>%
#  summarise(n()))
#None with super interesting distributions (most is 30 out of 90000, so remove)
bg.df.initalremoval$attributes.boardgamecompilation=NULL

sum(is.na(bg.df.initalremoval$attributes.boardgameexpansion))
#72613 are null, remove
#View(bg.df.initalremoval %>% group_by(attributes.boardgameexpansion) %>%
#  summarise(n()))
#no values of particular interest
bg.df.initalremoval$attributes.boardgameexpansion=NULL

sum(is.na(bg.df.initalremoval$attributes.boardgamefamily))
length(unique(bg.df.initalremoval$attributes.boardgamefamily))
#View(bg.df.initalremoval %>% group_by(attributes.boardgamefamily) %>%
#  summarise(n()))
#40,000 are null and 11,490 unique entries, however kickstarter info is in the column. Keep but clean.


sum(is.na(bg.df.initalremoval$attributes.boardgameimplementation))
length(unique(bg.df.initalremoval$attributes.boardgameimplementation))
head(bg.df.initalremoval$attributes.boardgameimplementation)
#Almost all are null and isn't needed for research questions
bg.df.initalremoval$attributes.boardgameimplementation=NULL


sum(is.na(bg.df.initalremoval$attributes.boardgameintegration))
length(unique(bg.df.initalremoval$attributes.boardgameintegration))
head(bg.df.initalremoval$attributes.boardgameintegration)
#89116 are null, not needed
bg.df.initalremoval$attributes.boardgameintegration=NULL


length(unique(bg.df.initalremoval$attributes.boardgamepublisher))

#View(bg.df.initalremoval %>% group_by(attributes.boardgamepublisher) %>%
#  summarise(n()))
#I notice a lot of games are self or web published. It might be interesting to see if these factors impact if a game is good or not, so I'll keep this column for now, it just will require some cleaning


length(unique(bg.df.initalremoval$attributes.boardgamedesigner))

#View(bg.df.initalremoval %>% group_by(attributes.boardgamedesigner) %>%
#  summarise(n()))
#Nothing super interesting here for my questions/goals, remove
bg.df.initalremoval$attributes.boardgamedesigner=NULL

names(bg.df.initalremoval)



## ------------------------------------------------------------------------------------------------------------------------
bg.df.secondremoval<-bg.df.initalremoval
#First, lets go ahead and filter out the rows that have less than 50 ratings and year is NA this line is from https://github.com/rfordatascience/tidytuesday/tree/master/data/2019/2019-03-12

bg.df.secondremoval <- bg.df.secondremoval %>% 
  janitor::clean_names() %>% 
  set_names(~str_replace(.x, "details_", "")) %>% 
  set_names(~str_replace(.x, "attributes_boardgame", "")) %>% 
  set_names(~str_replace(.x, "stats_", "")) %>% 
  filter(!is.na(yearpublished)) %>% 
  filter(usersrated >= 50)

#View(bg.df.secondremoval)




## ------------------------------------------------------------------------------------------------------------------------
#Turn board game/expansion into dummy variable 
bg.df.dummy<-dummy.data.frame(bg.df.secondremoval, names=c("game_type", sep="_"))
bg.df.dummy$game_typeboardgame=NULL
head(bg.df.dummy)
bg.df.dummy<-rename(bg.df.dummy, c("is_expansion"= "game_typeboardgameexpansion"))


## ------------------------------------------------------------------------------------------------------------------------
bg.df.levels<-bg.df.dummy
bg.df.levels$polls_language_dependence<-factor(bg.df.dummy$polls_language_dependence)
replace_na(bg.df.dummy$polls_language_dependence)
#levels(bg.df.dummy$polls_language_dependence)
#View(bg.df.levels)
sum(is.na(bg.df.initalremoval$polls.language_dependence))
#View(bg.df.dummy)
#looking closer, a majority of the entries are NA, so not sure this column can be used well given the NA could be any of the factors. For now, going to remove
bg.df.dummy$polls_language_dependence=NULL


## ------------------------------------------------------------------------------------------------------------------------
bg.df.familywork<-bg.df.dummy
#View(bg.df.familywork %>% group_by(family) %>%
# summarise(n()))
#From the view, crowdfunding is the only category that seems interesting to explore. Others like 3d games, solitare games, etc, have much less associated with them (only 40 or so entries)
#The plan here is to turn this category into crowdfunded or not crowdfunded. There are many cateories with crowdfunding but all of them include "Crowdfunding", so I will filter by this.

bg.df.familywork$family[grep("Crowdfunding",bg.df.familywork$family)] <- 1
#Making an assumption that NA games are not crowdfunded (is this a good assumption?)
bg.df.familywork$family[bg.df.familywork$family!=1 | is.na(bg.df.familywork$family)]<-0

table(bg.df.familywork$family)
bg.df.familywork<-rename(bg.df.familywork, c("is_crowdfunded"= "family"))

#did notice some really old games were listed as crowdfunded on kickstarter which seems odd



## ------------------------------------------------------------------------------------------------------------------------
bg.df.category<-bg.df.familywork
#View(bg.df.category)
#View(bg.df.category$category)
bg.df.category$category[is.na(bg.df.category$category)]<-"None"
sum(is.na(bg.df.category$category))
length(unique(bg.df.category$category))
#View(bg.df.category %>% group_by(category) %>% summarise(n()))
#From the view, it seems like Dice, Card game, and Party Game should also be included.
#Some other potentially interesting categories are  Abstract Strategy Economic, Fantasy, Dexterity, Science Fiction, Animals and Racing but these are less common. Maybe they can be created?

#use csplit library to break into columns
bg.df.category<-cSplit_e(bg.df.category, split.col = "category", fixed = TRUE, type = "character", drop = TRUE, fill = 0L)

names(bg.df.category)
#keep category columns of interest
bg.df.categoriestokeep<-bg.df.category %>% subset (select=c("category_Wargame", "category_Educational", "category_Card Game", "category_Party Game", "category_Abstract Strategy", "category_Economic","category_Dice", "category_Fantasy","category_Action / Dexterity","category_Science Fiction", "category_Animals", "category_Racing"))
bg.df.categoriestokeep <- bg.df.categoriestokeep %>% 
  janitor::clean_names() %>% 
  set_names(~str_replace(.x, "category_", "is_"))
#View(bg.df.categoriestokeep)

#Messier alternative
#create educational column
#bg.df.category$educational<- bg.df.category$category
#bg.df.category$educational[grep("Educational",bg.df.category$educational)] <- 1
#Making an assumption that NA games are not this category?
#bg.df.category$educational[bg.df.category$educational!=1 | is.na(bg.df.category$educational)]<-0
#table(bg.df.category$educational)

bg.df.cleancategories<-cbind(bg.df.familywork, bg.df.categoriestokeep)
bg.df.cleancategories$category=NULL
names(bg.df.cleancategories)



## ------------------------------------------------------------------------------------------------------------------------
bg.df.publish<-bg.df.cleancategories
sum(is.na(bg.df.publish$publisher))
#Only 3 are NA so I feel comfortable making this column unknown
bg.df.publish$publisher[is.na(bg.df.publish$publisher)]<-"Unknown"
sum(is.na(bg.df.publish$publisher))
bg.df.publishsplit<-cSplit_e(bg.df.publish, split.col = "publisher", fixed = TRUE, type = "character", drop = TRUE, fill = 0L)
#names(bg.df.publishsplit)
bg.df.publishsplit<-bg.df.publishsplit %>% subset (select=c("publisher_(Public Domain)", "publisher_(Self-Published)","publisher_(Web published)"))

bg.df.publishsplit<-rename(bg.df.publishsplit, c("is_public_domain"= "publisher_(Public Domain)", "is_self_published"="publisher_(Self-Published)", "is_web_published"="publisher_(Web published)"))

bg.df.publishclean<-cbind(bg.df.publish,bg.df.publishsplit)
bg.df.publishclean$publisher<-NULL
names(bg.df.publishclean)


## ------------------------------------------------------------------------------------------------------------------------
bg.df.mech<-bg.df.publishclean
#View(bg.df.mech %>% group_by(mechanic) %>% summarise(n()))
bg.df.mech$mechanic[grep("Luck",bg.df.mech$mechanic)] <- 1
bg.df.mech$mechanic[bg.df.mech$mechanic!=1 | is.na(bg.df.mech$mechanic)]<-0

table(bg.df.mech$mechanic)
bg.df.mech<-rename(bg.df.mech, c("is_press_your_luck"= "mechanic"))
#View(bg.df.mech)


## ------------------------------------------------------------------------------------------------------------------------
bg.df.playerrange<-bg.df.mech
bg.df.playerrange$player_range<-bg.df.playerrange$maxplayers-bg.df.playerrange$minplayers


## ------------------------------------------------------------------------------------------------------------------------
bg.data<-bg.df.playerrange
#hist(bg.df.playerrange$average)
bg.data$average<-ifelse(bg.data$average>7, "Yes", "No")
table(bg.data$average)
bg.data<-rename(bg.data, c("is_good"="average"))
#View(bg.data)


## Based on exploration, replacing bg.data with a value that has a similar proprotion of good and not good games.
#bg.data$averageweight[bg.data$averageweight==0]<- 3.5

## ------------------------------------------------------------------------------------------------------------------------
keep(bg.data, sure=TRUE)

