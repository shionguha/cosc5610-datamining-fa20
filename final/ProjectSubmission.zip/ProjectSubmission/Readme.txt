The original data was provided in an .rda file, rather than a csv file, so I am including that rather than exporting this file 
to a csv file. There are 3 scripts used, the cleaning script is called by both the exploration and modelingvalidation scripts 
to initalize them. 
The exploration script corresponds to the exploration paper submission, and modleingvalidation script correponds to the final submission
work. These are both rnotebook files and are best viewed in the html rnotebook view, but can be viewed fine in R studio as well.