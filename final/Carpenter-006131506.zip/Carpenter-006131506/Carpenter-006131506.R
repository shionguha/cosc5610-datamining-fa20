library(pacman)
library(tidyverse)
library(caret)
library(broom)
library(modelr)
library(ROCR)
library(caret)
library(ROSE)
pacman::p_load(pacman, dplyr, GGally, ggplot2, ggthemes, ggvis, httr, lubridate, plotly, rio, rmarkdown, shiny, stringr, tidyr, modelr, caret, tidyverse, broom, ROCR, ROSE)

#load in data from local directory
raw_data <- read.csv("C:/Users/James Carpenter/Documents/GitHub/compas-analysis/compas-scores-two-years.csv")

#see the number of rows and column names
nrow(raw_data)
colnames(raw_data)


#filters out data that should not be used
df <- dplyr::select(raw_data, age, c_charge_degree, race, age_cat, score_text, sex, priors_count, 
                    days_b_screening_arrest, decile_score, is_recid, two_year_recid) %>% 
  filter(days_b_screening_arrest <= 30) %>%
  filter(days_b_screening_arrest >= -30) %>%
  filter(is_recid != -1) %>%
  filter(c_charge_degree != "O") %>%
  filter(score_text != 'N/A')
nrow(df)

#convert some of the data to factors
df <- mutate(df, crime_factor = factor(c_charge_degree)) %>%
  mutate(age_factor = as.factor(age_cat)) %>%
  mutate(race_factor = as.factor(race)) %>%
  mutate(crime_factor = as.factor(crime_factor)) %>%
  mutate(gender_factor = as.factor(sex)) %>%  
  mutate(score_factor = factor(score_text != "Low", labels = c("LowScore","HighScore")))

#set seed for splitting training and testing data
set.seed(123)
trainIndex <- createDataPartition(df$two_year_recid, p = 0.8, list = FALSE)
train_data  <- df[trainIndex, ]
test_data <- df[-trainIndex, ]


#model with gender, age, race, priors count, crime factor (misdemeanor or felony), score factor from COMPASS 
model1 <- glm(two_year_recid ~ gender_factor + age_factor + race_factor + priors_count + crime_factor
              + score_factor, family="binomial", data=train_data)

summary(model1)

#model with gender, age, priors count, crime factor (misdemeanor or felony) and score factor from COMPASS
model2 <- glm(two_year_recid ~ gender_factor + age_factor + priors_count + crime_factor 
              + score_factor, family="binomial", data=train_data)

summary(model2)

#model with gender, age, priors count, crime facor ()
model3 <- glm(two_year_recid ~ gender_factor + age_factor + priors_count 
            + score_factor, family="binomial", data=train_data)
summary(model3)

#gets the probabilities of each prediction
test.predicted.m1 <- predict(model1, newdata = test_data,type = "response")
test.predicted.m2 <- predict(model2, newdata = test_data, type = "response")
test.predicted.m3 <- predict(model3, newdata = test_data, type = "response")


#models make predictions on test data
table(test.predicted.m1 > 0.5, test_data$two_year_recid)
table(test.predicted.m2 > 0.5, test_data$two_year_recid)
table(test.predicted.m3 > 0.5, test_data$two_year_recid)

#calculate AUC for each model (on the test data)
prediction(test.predicted.m1, test_data$two_year_recid) %>%
  performance(measure = "auc") %>%
  .@y.values

prediction(test.predicted.m2, test_data$two_year_recid) %>%
  performance(measure = "auc") %>%
  .@y.values

prediction(test.predicted.m3, test_data$two_year_recid) %>%
  performance(measure = "auc") %>%
  .@y.values

#plot ROC for model 2 (on test data)
ROCRpred = prediction(test.predicted.m2, test_data$two_year_recid)
ROCRperf = performance(ROCRpred, "tpr", "fpr")
plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))


#helps me see variable importance in the models
varImp(model1)
varImp(model2)
varImp(model3)

#calculate R2, RMSE, and MAE for model 2 (on test data)
predictions <- model2 %>% predict(test_data)
data.frame(
  R2 = R2(predictions, test_data$two_year_recid),
  RMSE = RMSE(predictions, test_data$two_year_recid),
  MAE = MAE(predictions, test_data$two_year_recid)
)

#cross validation techniques

#LOOCV
set.seed(123)
train.control <- trainControl(method = "LOOCV")

model_loocv <- train(two_year_recid ~ gender_factor + age_factor + race_factor + priors_count 
              + crime_factor + score_factor, data = df, method = "glm", trControl = train.control, family = "binomial")
print(model_loocv)

#CV
set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)

model_cv <- train(is_recid ~ gender_factor + age_factor + race_factor + priors_count
      + crime_factor + score_factor, data = df, method = "glm", trControl = train.control, family = "binomial")

print(model_cv)

#Repeated CV
set.seed(123) 
train.control <- trainControl(method = "repeatedcv", number = 10, repeats = 3)
model_rcv <-train(two_year_recid ~ gender_factor + age_factor + race_factor + priors_count
                 + crime_factor + score_factor, data = df, method = "glm", trControl = train.control, family = "binomial")
print(model_rcv)

#data balancing

#existing number of examples
table(train_data$two_year_recid)

#oversampling
data_balanced_over <- ovun.sample(two_year_recid ~ ., data = train_data, method = "over",N = 5360)$data
table(data_balanced_over$two_year_recid)

#undersampling
data_balanced_under <- ovun.sample(two_year_recid ~ ., data = train_data, method = "under", N = 4516, seed = 1)$data
table(data_balanced_under$two_year_recid)

#both over and under sampling
data_balanced_both <- ovun.sample(two_year_recid ~ ., data = train_data, method = "both", p=0.5, N=4938, seed = 1)$data
table(data_balanced_both$two_year_recid)

#model trained on over sampling data
model_over <- glm(two_year_recid ~ gender_factor + age_factor + priors_count + crime_factor 
              + score_factor, family="binomial", data=data_balanced_over)

#test model trained on oversampled data
test.predicted.over <- predict(model_over, newdata = test_data, type = "response")

prediction(test.predicted.over, test_data$two_year_recid) %>%
  performance(measure = "auc") %>%
  .@y.values

#test model trained on undersampled data
model_under <- glm(two_year_recid ~ gender_factor + age_factor + priors_count + crime_factor 
                  + score_factor, family="binomial", data=data_balanced_under)
test.predicted.under <- predict(model_under, newdata = test_data, type = "response")

prediction(test.predicted.under, test_data$two_year_recid) %>%
  performance(measure = "auc") %>%
  .@y.values

#test model on both oversampled and undersampled data
model_both <- glm(two_year_recid ~ gender_factor + age_factor + priors_count + crime_factor 
                   + score_factor, family="binomial", data=data_balanced_both)
test.predicted.both <- predict(model_both, newdata = test_data, type = "response")

prediction(test.predicted.both, test_data$two_year_recid) %>%
  performance(measure = "auc") %>%
  .@y.values


