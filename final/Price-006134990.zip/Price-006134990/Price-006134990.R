library(readr)
data <- read.csv("C://Users//Michael//Documents//Price-006134990//Price-006134990.csv",header=T)
summary(data)

model1 <- glm(factor(outcome_description)~factor(complainant_ethnicity),data=data,family=binomial)
summary(model1)
