data("beijingpm2.5")
pm2.5_no_na <- na.omit(beijingpm2.5)
## delete NA

data("pm2.5_no_na")
head(pm2.5_no_na)
colnames(pm2.5_no_na) <- c("No","year","month","day","hour","pm2.5","DEMP","TEMP","PRES","cbwd","Iws","Is","Ir")
## rename column

pm2.5_no_na$airquality <- as.character(pm2.5_no_na$pm2.5)
## create a new Column airquality

pm2.5_no_na <- pm2.5_no_na[-1,]
## delete first row

pm2.5_no_na$airquality[which(pm2.5_no_na$airquality < 35)] <- 1
pm2.5_no_na$airquality[which(pm2.5_no_na$airquality >= 35)] <- 0
## change air quality value to healthy and unhealthy

pm2.5_no_na$Ir[which(pm2.5_no_na$Ir > 0)] <- "Yes"
pm2.5_no_na$Ir[which(pm2.5_no_na$Ir == 0)] <- "No"

pm2.5_no_na$airquality<- as.numeric(pm2.5_no_na$airquality)
pm2.5_no_na$Iws<- as.numeric(pm2.5_no_na$Iws)
pm2.5_no_na$Is<- as.numeric(pm2.5_no_na$Is)
pm2.5_no_na$DEMP<- as.numeric(pm2.5_no_na$DEMP)
pm2.5_no_na$TEMP<- as.numeric(pm2.5_no_na$TEMP)
pm2.5_no_na$PRES<- as.numeric(pm2.5_no_na$PRES)
##change "character" into "double"

pm2.5_no_na$season <- as.character(pm2.5_no_na$month)
## create a new column season 

pm2.5_no_na$season[which(pm2.5_no_na$season == 3)] <- "spring"
pm2.5_no_na$season[which(pm2.5_no_na$season == 4)] <- "spring"
pm2.5_no_na$season[which(pm2.5_no_na$season == 5)] <- "spring"
pm2.5_no_na$season[which(pm2.5_no_na$season == 6)] <- "summer"
pm2.5_no_na$season[which(pm2.5_no_na$season == 7)] <- "summer"
pm2.5_no_na$season[which(pm2.5_no_na$season == 8)] <- "summer"
pm2.5_no_na$season[which(pm2.5_no_na$season == 9)] <- "fall"
pm2.5_no_na$season[which(pm2.5_no_na$season == 10)] <- "fall"
pm2.5_no_na$season[which(pm2.5_no_na$season == 11)] <- "fall"
pm2.5_no_na$season[which(pm2.5_no_na$season == 12)] <- "winter"
pm2.5_no_na$season[which(pm2.5_no_na$season == 1)] <- "winter"
pm2.5_no_na$season[which(pm2.5_no_na$season == 2)] <- "winter"
## change season value

pm2.5_no_na <- pm2.5_no_na[,-1]
pm2.5_no_na <- pm2.5_no_na[,-1]
pm2.5_no_na <- pm2.5_no_na[,-1]
pm2.5_no_na <- pm2.5_no_na[,-1]
pm2.5_no_na <- pm2.5_no_na[,-1]
pm2.5_no_na <- pm2.5_no_na[,-1]
##delete the column "No","year","month","day","hour","pm2.5"

pm2.5_spring<-pm2.5_no_na[pm2.5_no_na$season == "spring",]
pm2.5_summer<-pm2.5_no_na[pm2.5_no_na$season == "summer",]
pm2.5_fall<-pm2.5_no_na[pm2.5_no_na$season == "fall",]
pm2.5_winter<-pm2.5_no_na[pm2.5_no_na$season == "winter",]
##build tables for each season

set.seed(123)
sample <- sample(c(TRUE, FALSE), nrow(airquality), replace = T, prob = c(0.7,0.3))
train_spring <- pm2.5_spring[sample, ]
test_spring <- pm2.5_spring[!sample, ]

model1_spring <- glm(airquality ~ Iws, family = "binomial", data = train_spring)
##build model1_spring

library(tidyverse)  # data manipulation and visualization
library(broom)      # helps to tidy up model outputs
library(modelr)     # provides easy pipeline modeling functions

pm2.5_spring %>%
  mutate(prob = ifelse(airquality == "1", 1, 0)) %>%
  ggplot(aes(x= Iws , y= prob)) +
  geom_point(alpha = .15) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Logistic regression model fit for model1_spring") +
  xlab("Iws") +
  ylab("Probability of Airquality")

summary(model1_spring)
tidy(model1_spring)
exp(coef(model1_spring))
confint(model1_spring)

predict(model1_spring, data.frame(Iws = c(100, 200)), type = "response")
##predict if wind speed is between 100 and 200, what is the probability of the airquality

model2_spring <- glm(airquality ~ TEMP, family = "binomial", data = train_spring)
summary(model2_spring)

model3_spring <- glm(airquality ~ DEMP, family = "binomial", data = train_spring)
summary(model3_spring)

pm2.5_spring %>%
  mutate(prob = ifelse(airquality == "1", 1, 0)) %>%
  ggplot(aes(x= DEMP , y= prob)) +
  geom_point(alpha = .15) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  ggtitle("Logistic regression model fit for model3_spring") +
  xlab("DEMP") +
  ylab("Probability of Airquality")

tidy(model3_spring)
exp(coef(model3_spring))
confint(model3_spring)

model4_spring <- glm(airquality ~ PRES, family = "binomial", data = train_spring)
summary(model4_spring)

model5_spring <- glm(airquality ~ Ir, family = "binomial", data = train_spring)
summary(model5_spring)

model6_spring <- glm(airquality ~ cbwd, family = "binomial", data = train_spring)
summary(model6_spring)

model7_spring <- glm(airquality ~ DEMP + Iws, family = "binomial", data = train_spring)
summary(model7_spring)
##multiple logistic regression

tidy(model7_spring)

library(lattice)
library(purrr)
library(caret)

caret::varImp(model7_spring)

new.df <- tibble(Iws = 200, DEMP = 10)
predict(model7_spring, new.df, type = "response")

anova(model1_spring, model7_spring, test = "Chisq")

download.file("https://cran.r-project.org/src/contrib/pscl_1.5.5.tar.gz","pscl_1.5.5.tar.gz")
install.packages("pscl_1.5.5.tar.gz", repos = NULL)
install.packages("pscl")
library(pscl)

list(model1_spring = pscl::pR2(model1_spring)["McFadden"],
     model3_spring = pscl::pR2(model3_spring)["McFadden"],
     model7_spring = pscl::pR2(model7_spring)["McFadden"])

model1_springdata <- augment(model1_spring) %>% 
mutate(index = 1:n())

ggplot(model1_springdata, aes(index, .std.resid, color = airquality)) + 
geom_point(alpha = .5) +
geom_ref_line(h = 3)

plot(model1_spring, which = 4, id.n = 5)

model1_springdata %>% top_n(5, .cooksd)

test.predicted.m1 <- predict(model1_spring, newdata = test_spring, type = "response")
test.predicted.m3 <- predict(model3_spring, newdata = test_spring, type = "response")
test.predicted.m7 <- predict(model7_spring, newdata = test_spring, type = "response")
#model validation

list(
  model1_spring = table(test_spring$airquality, test.predicted.m1 > 0.5) %>% prop.table() %>% round(3),
  model3_spring = table(test_spring$airquality, test.predicted.m3 > 0.5) %>% prop.table() %>% round(3),
  model7_spring = table(test_spring$airquality, test.predicted.m7 > 0.5) %>% prop.table() %>% round(3)
)

test_spring %>%
  mutate(m1.pred = ifelse(test.predicted.m1 > 0.5, "1", "0"),
         m3.pred = ifelse(test.predicted.m3 > 0.5, "1", "0"),
         m7.pred = ifelse(test.predicted.m7 > 0.5, "1", "0")) %>%
  summarise(m1.error = mean(airquality != m1.pred),
            m3.error = mean(airquality != m3.pred),
            m7.error = mean(airquality != m7.pred))

table(test_spring$airquality, test.predicted.m1 > 0.5)

install.packages("ROCR")
library(ROCR)


par(mfrow=c(1, 2))

prediction(test.predicted.m1, test_spring$airquality) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()

prediction(test.predicted.m3, test_spring$airquality) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()

prediction(test.predicted.m1, test_spring$airquality) %>%
performance(measure = "auc") %>% .@y.values
## model1_spring AUC

prediction(test.predicted.m3, test_spring$airquality) %>%
performance(measure = "auc") %>% .@y.values
## model3_spring AUC


#crossvalidation 
library(tidyverse)
library(purrr)
library(caret)

spring <- pm2.5_spring[,-2]
spring<- spring[,-2]
spring<- spring[,-2]
spring<- spring[,-3]
spring<- spring[,-3]
spring<- spring[,-4]
## delete unrelated column

set.seed(123)
training.samples <- spring$Iws %>%
  createDataPartition(p = 0.8, list = FALSE)
train.data  <- spring[training.samples, ]
test.data <- spring[-training.samples, ]
## Split the data into training and test set

model <- lm(Iws ~., data = train.data)
## Build the model

predictions <- model %>% predict(test.data)
data.frame( R2 = R2(predictions, test.data$Iws),
            RMSE = RMSE(predictions, test.data$Iws),
            MAE = MAE(predictions, test.data$Iws))
## Make predictions and compute the R2, RMSE and MAE
RMSE(predictions, test.data$Iws)/mean(test.data$Iws)


train.control <- trainControl(method = "LOOCV")
## Define training control
model <- train(Iws ~., data = spring, method = "lm",
               trControl = train.control)
## Train the model
print(model)
## Summarize the results


set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)
## Define training control
model <- train(Iws ~., data = spring, method = "lm",
               trControl = train.control)
## Train the model
print(model)
## Summarize the results


set.seed(123)
train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3)
## Define training control
model <- train(Iws ~., data = spring, method = "lm",
               trControl = train.control)
## Train the model
print(model)
## Summarize the results


##  classbalance
library(dplyr) ## for data manipulation
library(caret) ## for model-building
library(DMwR) ## for smote implementation
library(purrr) ## for functional programming (map)
library(PROC) ## for AUC calculations
library(gbm)


set.seed(2969)

imbal_train <- twoClassSim(5000,
                           intercept = -25,
                           linearVars = 20,
                           noiseVars = 10)

imbal_test  <- twoClassSim(5000,
                           intercept = -25,
                           linearVars = 20,
                           noiseVars = 10)

prop.table(table(imbal_train$Class))



ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = twoClassSummary,
                     classProbs = TRUE)

# Build a standard classifier using a gradient boosted machine

set.seed(5627)

orig_fit <- train(Class ~ .,
                  data = imbal_train,
                  method = "gbm",
                  verbose = FALSE,
                  metric = "ROC",
                  trControl = ctrl)

# Build custom AUC function to extract AUC
# from the caret model object


test_roc <- function(model, data) {
  
  roc(data$Class,
      predict(model, data, type = "prob")[, "Class2"])
  
}

orig_fit %>%
  test_roc(data = imbal_test) %>%
  auc()

# Create model weights (they sum to one)

model_weights <- ifelse(imbal_train$Class == "Class1",
                        (1/table(imbal_train$Class)[1]) * 0.5,
                        (1/table(imbal_train$Class)[2]) * 0.5)

# Use the same seed to ensure same cross-validation splits

ctrl$seeds <- orig_fit$control$seeds


# Build weighted model

weighted_fit <- train(Class ~ .,
                      data = imbal_train,
                      method = "gbm",
                      verbose = FALSE,
                      weights = model_weights,
                      metric = "ROC",
                      trControl = ctrl)

# Build down-sampled model

ctrl$sampling <- "down"

down_fit <- train(Class ~ .,
                  data = imbal_train,
                  method = "gbm",
                  verbose = FALSE,
                  metric = "ROC",
                  trControl = ctrl)

# Build up-sampled model

ctrl$sampling <- "up"

up_fit <- train(Class ~ .,
                data = imbal_train,
                method = "gbm",
                verbose = FALSE,
                metric = "ROC",
                trControl = ctrl)


# Build smote model

ctrl$sampling <- "smote"

smote_fit <- train(Class ~ .,
                   data = imbal_train,
                   method = "gbm",
                   verbose = FALSE,
                   metric = "ROC",
                   trControl = ctrl)

# Examine results for test set

model_list <- list(original = orig_fit,
                   weighted = weighted_fit,
                   down = down_fit,
                   up = up_fit,
                   SMOTE = smote_fit)

model_list_roc <- model_list %>%
  map(test_roc, data = imbal_test)

model_list_roc %>%
  map(auc)

results_list_roc <- list(NA)
num_mod <- 1

for(the_roc in model_list_roc){
  
  results_list_roc[[num_mod]] <- 
    data_frame(tpr = the_roc$sensitivities,
               fpr = 1 - the_roc$specificities,
               model = names(model_list)[num_mod])
  
  num_mod <- num_mod + 1
  
}

results_df_roc <- bind_rows(results_list_roc)

# Plot ROC curve for all 5 models

custom_col <- c("#000000", "#009E73", "#0072B2", "#D55E00", "#CC79A7")

ggplot(aes(x = fpr,  y = tpr, group = model), data = results_df_roc) +
  geom_line(aes(color = model), size = 1) +
  scale_color_manual(values = custom_col) +
  geom_abline(intercept = 0, slope = 1, color = "gray", size = 1) +
  theme_bw(base_size = 18)