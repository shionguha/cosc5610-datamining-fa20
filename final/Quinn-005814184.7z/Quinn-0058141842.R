# ---
# title: "Data Mining Final Project: Forecasting Severe Pipeline Incidents"
# author: "Colin Quinn"
# date: "12/9/2020"
# MU_ID: 005814184
# ---

rm(list=ls())
#setwd("./Assignment 3")
#setwd("C:/Users/Colin/OneDrive - Marquette University/Grad-School-S5/Data Mining/Assignment 3")
#install.packages("dplyr")
library(dplyr)
#install.packages("caret")
library(caret)
#install.packages("ROCR")
library(ROCR)
#install.packages("pscl")
library(pscl)
#install.packages("smotefamily")
library(smotefamily)
#install.packages("pROC")
library(pROC) # for AUC calculations
#install.packages("purrr")
library(purrr)
library(ggplot2)
library(DescTools)

data <- read.csv("Quinn-005814184.csv", header = TRUE) # This data was already cleaned in my MATLAB script.
data <- subset (data, select = -LOCAL_DATETIME) #not needed
data <- subset (data, select = -OPERATOR_STATE_ABBREVIATION) #not needed

# Create Factors, binary in most cases
data$SEVERE <- as.factor(data$SEVERE)
data$FF <- as.factor(data$FF)
data$FATALITY_IND <- as.factor(data$FATALITY_IND)
data$SHUTDOWN_DUE_ACCIDENT_IND <- as.factor(data$SHUTDOWN_DUE_ACCIDENT_IND)
data$IGNITE_IND <- as.factor(data$IGNITE_IND)
data$EXPLODE_IND <- as.factor(data$EXPLODE_IND)
data$LOCATION_TYPE <- as.factor(data$LOCATION_TYPE)
data$INCIDENT_AREA_TYPE <- as.factor(data$INCIDENT_AREA_TYPE)
data$MATERIAL_INVOLVED <- as.factor(data$MATERIAL_INVOLVED)
data$RELEASE_TYPE <- as.factor(data$RELEASE_TYPE)
data$INCIDENT_AREA_TYPE <- as.factor(data$INCIDENT_AREA_TYPE)
data$INCIDENT_ID <- (data$PIPE_MANUFACTURE_YEAR-data$IYEAR)

# Standardize cont. vars
data <- data %>% mutate_if(is.numeric, funs(as.numeric(scale(.))))
glimpse(data)

#Check factor variables - This is based on code found here: https://www.guru99.com/r-generalized-linear-model.html
# Select categorical column
factor <- data.frame(select_if(data, is.factor))
ncol(factor)

# Create graph for each column
graph <- lapply(names(factor),
                function(x) 
                  ggplot(factor, aes(get(x))) +
                  geom_bar() +
                  theme(axis.text.x = element_text(angle = 90)))
graph



# SECTION 2 MODELS

# Plot SEVERE vs significant values in bar plot
fig2_1 = ggplot(data, aes(x = IGNITE_IND, fill = SEVERE)) +
  geom_bar(position = "fill") +
  theme_classic()
fig2_1 = fig2_1 + labs(x = "Gas Ignited", y = "% of Severe Incidents")
fig2_1

fig2_2 = ggplot(data, aes(x = EXPLODE_IND, fill = SEVERE)) +
  geom_bar(position = "fill") +
  theme_classic()
fig2_2 = fig2_2 + labs(x = "Explosion Reported", y = "% of Severe Incidents")
fig2_2

# Bar Plot Section 3 of Severe
fig3_1 = ggplot(data=data, aes(x=SEVERE)) +
  geom_bar(stat="count")
fig3_1 = fig3_1 + labs(x = "Explosion Reported", y = "% of Severe Incidents")
fig3_1

#Split data into training and testig
trainIndex <- createDataPartition(data$SEVERE, p=0.7, list=FALSE)
data_train <- data[trainIndex,]
data_test <- data[-trainIndex,]

#-----------------------------------------------------------------------------VV
# Build Model - Full 
logit_full <- glm(SEVERE ~ FF + GAS_RELEASED + PIPE_MANUFACTURE_YEAR + FATALITY_IND + MATERIAL_INVOLVED + IYEAR + INCIDENT_AREA_TYPE + LOCATION_LATITUDE + LOCATION_LONGITUDE +
                    IGNITE_IND + EXPLODE_IND + PIPE_DIAMETER + EST_COST_PROP_DAMAGE + IYEAR:PIPE_MANUFACTURE_YEAR, data = data, family = 'binomial')
summary(logit_full)
#-----------------------------------------------------------------------------^^


#-----------------------------------------------------------------------------VV
# Build Model - Full testing
ctrl <- trainControl(method = "none", savePredictions = T)
logit_full_testing <- train(SEVERE ~ FF + GAS_RELEASED + PIPE_MANUFACTURE_YEAR + FATALITY_IND + MATERIAL_INVOLVED + IYEAR + INCIDENT_AREA_TYPE + LOCATION_LATITUDE + LOCATION_LONGITUDE +
                    IGNITE_IND + EXPLODE_IND + PIPE_DIAMETER + EST_COST_PROP_DAMAGE, data = data_train, family = 'binomial',method = "glm", trControl = ctrl)
summary(logit_full_testing)
#-----------------------------------------------------------------------------^^


#-----------------------------------------------------------------------------VV
# Build Model - reduced version of full
logit_reduced <- glm(SEVERE ~  IYEAR+IGNITE_IND+EXPLODE_IND+EST_COST_PROP_DAMAGE, data = data, family = 'binomial')
summary(logit_reduced)
#-----------------------------------------------------------------------------^^

# Build Model - reduced with training data
#-----------------------------------------------------------------------------VV
ctrl <- trainControl(method = "none", savePredictions = T)
logit_reduced_testing <- train(SEVERE ~  IYEAR+IGNITE_IND+EXPLODE_IND+EST_COST_PROP_DAMAGE, data = data_train, family = 'binomial',method = "glm", trControl = ctrl)
summary(logit_reduced_testing)

prediction_results <- predict(logit_reduced_testing, data_test)

#Confusion Martix
confusionMatrix(prediction_results, data_test$SEVERE)

r_squared = PseudoR2(logit_reduced, which = "McFadden")

#-----------------------------------------------------------------------------^^

#-----------------------------------------------------------------------------VV
# Build Model - reduced + pipe SPECIAL VARS with training data
ctrl <- trainControl(method = "none", savePredictions = T)
logit_reduced_plus_exeg <- train(SEVERE ~  IYEAR+IGNITE_IND+EXPLODE_IND+EST_COST_PROP_DAMAGE + PIPE_MANUFACTURE_YEAR
                                 + PIPE_DIAMETER + PIPE_DIAMETER:EST_COST_PROP_DAMAGE + PIPE_MANUFACTURE_YEAR:IYEAR, data = data_train, family = 'binomial',method = "glm", trControl = ctrl)
summary(logit_reduced_plus_exeg)

prediction_results <- predict(logit_reduced_plus_exeg, data_test)

#Confusion Martix
confusionMatrix(prediction_results, data_test$SEVERE)

r_squared = PseudoR2(logit_reduced_plus_exeg, which = "McFadden")
#-----------------------------------------------------------------------------^^

#-----------------------------------------------------------------------------VV
# k-fold Cross validation
ctrl <- trainControl(method = "cv", number = 10, savePredictions = T)

#fit a regression model and use k-fold CV to evaluate performance
logit_reduced_testing_cv <- train(SEVERE ~  IYEAR+IGNITE_IND+EXPLODE_IND+EST_COST_PROP_DAMAGE, data = data, family = 'binomial', method = "glm", trControl = ctrl)
print(logit_reduced_testing_cv)
summary(logit_reduced_testing_cv)

caret::confusionMatrix(table((logit_reduced_testing_cv$pred)$pred,(logit_reduced_testing_cv$pred)$obs))
#-----------------------------------------------------------------------------^^

# Build Model - reduced 
logit_reduced_customized <- train(SEVERE ~  INCIDENT_ID +EST_COST_PROP_DAMAGE, data = data_train, family = 'binomial', method = "glm",trControl = ctrl)
print(logit_reduced_customized)
summary(logit_reduced_customized)


prediction_results <- predict(logit_reduced_customized, data_test)

#Confusion Martix
confusionMatrix(prediction_results, data_test$SEVERE)



#-----------------------------------------------------------------------------VV
#SMOTE algorithm

# Set up control function for training

ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = twoClassSummary,
                     classProbs = TRUE)

# Build a standard classifier using a gradient boosted machine



orig_fit <- train(SEVERE ~ .,
                  data = data_train,
                  method = "gbm",
                  verbose = FALSE,
                  metric = "ROC",
                  trControl = ctrl)

# Build custom AUC function to extract AUC
# from the caret model object

test_roc <- function(model, data) {
  roc(data$SEVERE,
      predict(model, data, type = "prob")[, "YES"])
}

prop.table(table(data_train$SEVERE))

orig_fit %>%
  test_roc(data = data_train) %>%
  auc()


#-----------------------------------------------------
# From second box

# Create model weights (they sum to one)

model_weights <- ifelse(data_train$SEVERE == "YES",
                        (1/table(data_train$SEVERE)[1]) * 0.5,
                        (1/table(data_train$SEVERE)[2]) * 0.5)

# Use the same seed to ensure same cross-validation splits

ctrl$seeds <- orig_fit$control$seeds

# Build weighted model

weighted_fit <- train(SEVERE ~ .,
                      data = data_train,
                      method = "gbm",
                      verbose = FALSE,
                      weights = model_weights,
                      metric = "ROC",
                      trControl = ctrl)

# Build down-sampled model

ctrl$sampling <- "down"

down_fit <- train(SEVERE ~ .,
                  data = data_train,
                  method = "gbm",
                  verbose = FALSE,
                  metric = "ROC",
                  trControl = ctrl)

# Build up-sampled model

ctrl$sampling <- "up"

up_fit <- train(SEVERE ~ .,
                data = data_train,
                method = "gbm",
                verbose = FALSE,
                metric = "ROC",
                trControl = ctrl)

# Build smote model

ctrl$sampling <- "smote"

smote_fit <- train(SEVERE ~ .,
                   data = data_train,
                   method = "gbm",
                   verbose = FALSE,
                   metric = "ROC",
                   trControl = ctrl)

#-----------------------------------------------------------------------------^^

model_list <- list(original = orig_fit,
                   weighted = weighted_fit,
                   down = down_fit,
                   up = up_fit,
                   SMOTE = smote_fit,
                   reduced = logit_reduced_testing)

model_list <- list(Full_Model_Eq_1 = logit_full_testing,
                   Reduced_Model_Eq_4 = logit_reduced_testing,
                   Reduced_Model_Eq_4_CV = logit_reduced_testing_cv,
                   SMOTE = smote_fit,
                   weighted = weighted_fit,
                   down = down_fit,
                   up = up_fit)

model_list_roc <- model_list %>%
  map(test_roc, data = data_test)

model_list_roc %>%
  map(auc)




#-------------------------------------------------------------------------------
results_list_roc <- list(NA)
num_mod <- 1

for(the_roc in model_list_roc){
  
  results_list_roc[[num_mod]] <- 
    data_frame(tpr = the_roc$sensitivities,
               fpr = 1 - the_roc$specificities,
               model = names(model_list)[num_mod])
  
  num_mod <- num_mod + 1
  
}

results_df_roc <- bind_rows(results_list_roc)

# Plot ROC curve for all 5 models

custom_col <- c("#000000", "#009E73", "#0072B2", "#D55E00", "#CC79A7","#CC72A7")
custom_col <- c("#000000", "#009E73","#0072B2","#D55E00","#CC79A7","#78FC0A", "#FC0AAF")

ggplot(aes(x = fpr,  y = tpr, group = model), data = results_df_roc) +
  geom_line(aes(color = model), size = 1) +
  scale_color_manual(values = custom_col) +
  geom_abline(intercept = 0, slope = 1, color = "gray", size = 1) +
  theme_bw(base_size = 18)


prediction_results <- predict(smote_fit, data_test)

#Confusion Martix
confusionMatrix(prediction_results, data_test$SEVERE)
