install.packages("ggplot2")
install.packages("GGally")
install.packages("DMwR")
install.packages("pROC")
install.packages("rfUtilities")
install.packages("caret")
install.packages("MLmetrics")
install.packages("oddsratio")
install.packages("epiDisplay")

library("MLmetrics")
library("ggplot2")
library("tidyr")
library("GGally")
library("DMwR")
library("pROC")
library("rfUtilities")
library("caret")
library("oddsratio")
library("epiDisplay")





data_path <- "C:/Users/0039malikm/Desktop/Malik-006190039.csv"
df <- read.csv(data_path)


df$education<- NULL #dropping education column 

names(df)[names(df) == "male"] <- "sex_male"

df <- df[complete.cases(df), ] # dropping rows contain missing values

#Plotting all histograms of the columns
ggplot(gather(df), aes(value)) + geom_histogram(bins = 20) + facet_wrap(~key, scales = 'free_x')

#plotting TenYearCHD bar plot to see data distribution
ggplot(data=df)+aes(x=TenYearCHD) + geom_bar()
#the plot shows that the data is highly imbalanced
#for this reason we will apply SMOTE technique to re-balance the data

#plotting columns pairs
ggpairs(df)


#fitting a logistic regression model to find the relevant variables
glm.fit <- glm(TenYearCHD ~ ., data = df, family = binomial)
#printing model summary
summary(glm.fit)
#according to p-values showed in the summary of the model 
#only variables sex_male,age,current_smoker,cigsperDay,totChol,sysBP and glucose
# are relevant to our problem for this reason we only keep them in our dataset

relevant_variables <- c("sex_male","age","cigsPerDay","totChol","sysBP","glucose")
# fitting logistic regression on relevant data
glm.fit <- glm(TenYearCHD ~ ., data = df[,c(relevant_variables,"TenYearCHD")], family = binomial)
#showing coefficients of the fitted model 

glm.fit$coefficients

anova(glm.fit, test="Chisq")
#ChiSquare Test showing similar relevant variables.

logistic.display(glm.fit)

# a function to apply cross validation of the data
Apply_cross_validation <- function(df,features,target,nrFolds=5,apply_smote=T,threshold=0.5){
 
   folds <- rep_len(1:nrFolds, nrow(df))
   
   folds <- sample(folds, nrow(df))
   data = df[,c(features,target)]

   valiation_results <- data.frame(AUC=double(),Accuracy =double(),Precision = double(),Recall =double(),Specificity=double())
   for(k in 1:nrFolds) {
     # actual split of the data
     fold <- which(folds == k)
     data.train <- data[-fold,]
     data.test <- data[fold,]
     
     
     if (apply_smote == T){
       data.train$TenYearCHD <- as.factor(data.train$TenYearCHD)
       data.train <- SMOTE(TenYearCHD ~ ., data=data.train, perc.over=100)
       data.train$TenYearCHD <- as.numeric(data.train$TenYearCHD)
       data.train$TenYearCHD = ifelse(data.train$TenYearCHD == 2, 1, 0)
       

     }
     glm.fit = glm(TenYearCHD ~ ., data = data.train, family = binomial)
     summary(glm.fit)
     
     test.probs <- predict(glm.fit, newdata = data.test,type=c("response"))
     test.predictions <- ifelse(test.probs > threshold, 1, 0)
     
     roc <- roc(as.numeric(data.test$TenYearCHD),test.probs)
     
     auc_value <-auc(roc)
     accuracy <- Accuracy(as.factor(test.predictions),as.factor(data.test$TenYearCHD))
     precision <- posPredValue(as.factor(test.predictions), as.factor(data.test$TenYearCHD), positive="1")
     recall <- sensitivity(as.factor(test.predictions), as.factor(data.test$TenYearCHD), positive="1")
     specificity <- specificity(as.factor(test.predictions), as.factor(data.test$TenYearCHD), positive="1")
     valiation_results[nrow(valiation_results) + 1,] = list(AUC=auc_value,Accuracy=accuracy, Precision=precision,Recall=recall,Specificity=specificity)
     
   }
   return(valiation_results)
}

val_data_without_smote <- Apply_cross_validation(df,relevant_variables,"TenYearCHD",nrFolds =5,apply_smote=F)
val_data_with_smote <- Apply_cross_validation(df,relevant_variables,"TenYearCHD",nrFolds =5,apply_smote=T)

cat("AUC without smote ",mean(val_data_without_smote$AUC))
cat("AUC with smote ",mean(val_data_with_smote$AUC))

cat("Accuracy without smote ",mean(val_data_without_smote$Accuracy))
cat("Accuracy with smote ",mean(val_data_with_smote$Accuracy))

# We see that we have the same AUC while accuracy drops down
# For this we conclude the need of more data
