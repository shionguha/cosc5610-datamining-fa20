library(tidyverse)
library(ggplot2)
library(gridExtra)
library(stringr)
library(forcats)
library(readxl)
library(vcd)
library(dataPreparation)


mecs<-read.csv("Schleif-006174811.csv")
#mecs_other<-read_excel("MECS_other-specify.xls",col_names=T)
#names<-read_excel("MECScolNames.xlsx",col_names=F)
#mars<-read.csv("MARS_Data.csv")
#summary(mecs)
colnames(mecs)<-c("case_id", "Date", "Bedrooms", "RentDueFrequency", "RentDueComment", "RentAmt", "RentAssistance",
                  "OtherAdults", "AdultsQty", "AdultGender", "AdultRelationship", "AdultRace", "AdultOnEviction", 
                  "AdultAge", "Adult2Gender", "Adult2Relationship", "Adult2Race", "Adult2OnEviction", "Adult2Age", 
                  "Adult3Gender", "Adult3Relationship", "Adult3Race", "Adult3OnEviction", "Adult3Age", "Adult4Gender", 
                  "Adult4Relationship", "Adult4Race", "Adult4OnEviction", "Adult4Age", "Adult5Gender", "Adult5Relationship", 
                  "Adult5Race", "Adult5OnEviction", "Adult5Age", "Children", "ChildrenQty", "AgeC1", "UnitsC1", "AgeC2", 
                  "UnitsC2", "AgeC3", "UnitsC3", "AgeC4", "UnitsC4", "AgeC5", "UnitsC5", "AgeC6", "UnitsC6", "AgeC7", 
                  "UnitsC7", "AgeC8", "UnitsC8", "AgeC9", "UnitsC9", "AgeC10", "UnitsC10", "AgeC11", "UnitsC11",
                  "DocumentScan", "DocumentLook", "Nonpayment", "NonpaymentAmt", "PropertyDamage", "UnauthorizedPersons", 
                  "CriminalActivity", "DrugHouse", "NuisanceProp", "NoCause28", "OtherCause", "NuisanceLetter", "NonpaymentR", 
                  "NonpaymentAmtR", "ViolateLeaseR", "NuisanceLetterR", "NoCause28R", "OtherCauseR", "Outcome", "Plans", "Age",
                  "Hispanic", "Race1", "Race2", "Race3", "Income", "Gender", "pink", "Default", "Owed", "Lease", "Nuisance", 
                  "Twentyeight", "Foreclosure", "Dispute", "Fourteenday")

#Data Preparation--------------------------------------------------------------------------------

#Factors & Numeric
mecs$case_id<-as.factor(mecs$case_id)
mecs$Income[is.na(mecs$Income)]<-0
mecs$Income<-as.numeric(as.character(mecs$Income))

mecs$Owed[is.na(mecs$Owed)]<-0
mecs$Owed<-as.numeric(as.character(mecs$Owed))

mecs$RentAssistance<-as.character(mecs$RentAssistance)
mecs$RentAssistance[mecs$RentAssistance=="blank"]<-"no"
mecs$RentAssistance<-as.factor(mecs$RentAssistance)

mecs$Children<-as.character(mecs$Children)
mecs$Children[mecs$Children=="blank"]<-"no"
mecs$Children[is.na(mecs$Children)]<-"no"
mecs$Children<-as.factor(mecs$Children)
summary(mecs$Children)


mecs$ChildrenQty<-
  case_when(mecs$Children=="no"~0,
            is.na(mecs$ChildrenQty)~0,
            TRUE~as.numeric(as.character(mecs$ChildrenQty)))
summary(mecs$ChildrenQty)

mecs[mecs$case_id==298,"OtherAdults"]<-"yes"
mecs$AdultsQty<-
  case_when(mecs$OtherAdults=="no"~0,
            is.na(mecs$AdultsQty)~0,
            TRUE~as.numeric(as.character(mecs$AdultsQty)))
summary(mecs$AdultsQty)

#Clean up Outcome text------------------------------------------------------------------------------
mecs$Outcome<-as.character(mecs$Outcome)
mecs$Outcome<-case_when(
  mecs$Outcome=="I WAS EVICTED AND TOLD TO VACATE THE PREMISES BY A CERTAIN D"
  ~"I WAS EVICTED AND TOLD TO VACATE THE PREMISES BY A CERTAIN DATE",
  mecs$Outcome=="MY LANDLORD AND I HAVE TO COME BACK AND SEE THE JUDGE ON A L"
  ~"MY LANDLORD AND I HAVE TO COME BACK AND SEE THE JUDGE ON A LATER DATE",
  mecs$Outcome=="MY LANDLORD AND I WORKED OUT A STIPULATION AGREEMENT THAT AL"
  ~"MY LANDLORD AND I WORKED OUT A STIPULATION AGREEMENT THAT ALLOWS ME TO STAY IN THE APARTMENT",
  TRUE~mecs$Outcome
)
mecs$Outcome<-as.factor(mecs$Outcome)

#Consistent Units-----------------------------------------------------------------------------
mecs$RentAmt<-case_when(
  mecs$RentDueFrequency=="ONCE A MONTH"~as.numeric(as.character(mecs$RentAmt)),
  mecs$RentDueFrequency=="ONCE A WEEK"~as.numeric(as.character(mecs$RentAmt))*52/12
)
summary(mecs$RentAmt)
#---------------------------------------------------------------------------------------------------
#Categorical Bins & Calculated Fields--------------------------------------------------------------
mecs<-mecs%>%
  mutate(Judgement=case_when(
    mecs$Outcome=="I WAS EVICTED AND TOLD TO VACATE THE PREMISES BY A CERTAIN DATE"~1,
    #mecs$Outcome=="MY LANDLORD AND I WORKED OUT A STIPULATION AGREEMENT THAT ALLOWS ME TO STAY IN THE APARTMENT"~0
    TRUE~0
  ))
mecs$Judgement<-as.factor(mecs$Judgement)

mecs$Residents<-1+as.numeric(mecs$AdultsQty)+as.numeric(mecs$ChildrenQty)

mecs$AgeBin<-case_when(
  mecs$Age<25~"<25",
  mecs$Age>=25 & mecs$Age<35~"<25-34",
  mecs$Age>=35 & mecs$Age<45~"<35-44",
  mecs$Age>=45 ~"<=45",
)
mecs$AgeBin<-factor(mecs$AgeBin,levels=c("<25","<25-34","<35-44","<=45"))
summary(mecs$AgeBin)


#Children's ages
summary(mecs$UnitsC1)
mecs$AgeC1<-case_when(mecs$UnitsC1=="Months"~mecs$AgeC1/12,TRUE~as.numeric(mecs$AgeC1))
mecs$AgeC2<-case_when(mecs$UnitsC2=="Months"~mecs$AgeC2/12)
mecs$AgeC3<-case_when(mecs$UnitsC3=="Months"~mecs$AgeC3/12)
mecs$AgeC4<-case_when(mecs$UnitsC4=="Months"~mecs$AgeC4/12)
mecs$AgeC5<-case_when(mecs$UnitsC5=="Months"~mecs$AgeC5/12)
mecs$AgeC6<-case_when(mecs$UnitsC6=="Months"~mecs$AgeC6/12)
mecs$AgeC7<-case_when(mecs$UnitsC7=="Months"~mecs$AgeC7/12)
mecs$AgeC8<-case_when(mecs$UnitsC8=="Months"~mecs$AgeC8/12)
mecs$AgeC9<-case_when(mecs$UnitsC9=="Months"~mecs$AgeC9/12)
mecs$AgeC10<-case_when(mecs$UnitsC10=="Months"~mecs$AgeC10/12)
mecs$AgeC11<-case_when(mecs$UnitsC11=="Months"~mecs$AgeC11/12)
summary(mecs$AgeC1)

mecs$`Child<5`<-as.factor(case_when(
  mecs$AgeC1<5|mecs$AgeC2<5|mecs$AgeC3<5|mecs$AgeC4<5|mecs$AgeC5<5|mecs$AgeC6<5|
    mecs$AgeC7<5|mecs$AgeC8<5|mecs$AgeC9<5|mecs$AgeC10<5|mecs$AgeC11<5
  ~1,
  TRUE~0
))
mecs$`Child5-13`<-as.factor(case_when(
  (mecs$AgeC1>=5 & mecs$AgeC1<14)|(mecs$AgeC2>=5 & mecs$AgeC2<14)|
    (mecs$AgeC3>=5 & mecs$AgeC3<14)|(mecs$AgeC4>=5 & mecs$AgeC4<14)|
    (mecs$AgeC5>=5 & mecs$AgeC5<14)|(mecs$AgeC6>=5 & mecs$AgeC6<14)|
    (mecs$AgeC7>=5 & mecs$AgeC7<14)|(mecs$AgeC8>=5 & mecs$AgeC8<14)|
    (mecs$AgeC9>=5 & mecs$AgeC9<14)|(mecs$AgeC10>=5 & mecs$AgeC10<14)|
    (mecs$AgeC11>=5 & mecs$AgeC11<14)
  ~1,
  TRUE~0
))
mecs$`Child14+`<-as.factor(case_when(
  mecs$AgeC1>=14|mecs$AgeC2>=14|mecs$AgeC3>=14|mecs$AgeC4>=14|mecs$AgeC5>=14|mecs$AgeC6>=14|
    mecs$AgeC7>=14|mecs$AgeC8>=14|mecs$AgeC9>=14|mecs$AgeC10>=14|mecs$AgeC11>=14
  ~1,
  TRUE~0
))
summary(mecs$`Child14+`)


#Rent Bin
summary(mecs$RentAmt)
mecs$RentBin<- cut(mecs$RentAmt,ordered_result = T, include.lowest = T,
                     breaks = c(0,200,300,400,500,600,700,Inf))
summary(mecs$RentBin)
mecs[is.na(mecs$RentBin),"Rent"]

#Income Bin
summary(mecs$Income)
mecs$IncomeBin<- cut(mecs$Income,ordered_result = T, include.lowest = T,
                     breaks = c(0,1,500,750,1000,1500,2000,Inf))
mecs$IncomeBin<-case_when(
  is.na(mecs$Income)~"Not Given",
  TRUE~as.character(mecs$IncomeBin)
)
mecs$IncomeBin<-as.factor(mecs$IncomeBin)

summary(mecs$IncomeBin)

#Amount Owed Bin
summary(mecs$Owed)
mecs$OwedBin<- cut(mecs$Owed,ordered_result = T, include.lowest = T,
                     breaks = c(0,1,500,750,1000,1500,2000,Inf))
summary(mecs$OwedBin)
mecs$OwedBin[is.na(mecs$OwedBin)]<-"[0,500]"

#Months Behind
mecs<-mutate(mecs,MonthsBehind=Owed/RentAmt)

#Make bins for Owed/Income, Rent/Income, Income/Residents
mecs$OwedPerIncomeBin<-as.factor(case_when(
  mecs$Owed/mecs$Income==0 ~"0",
  mecs$Owed/mecs$Income>0 & mecs$Owed/mecs$Income<0.5~"0-.5",
  mecs$Owed/mecs$Income>=.5 & mecs$Owed/mecs$Income<1~"0.5-1",
  mecs$Owed/mecs$Income>=1 & mecs$Owed/mecs$Income<1.5~"1-1.5",
  mecs$Owed/mecs$Income>=1.5 & mecs$Owed/mecs$Income<2~"1.5-2",
  mecs$Owed/mecs$Income>=2~"2+"
)
)

mecs$RentPerIncomeBin<-as.factor(case_when(
  mecs$RentAmt/mecs$Income>0 & mecs$RentAmt/mecs$Income<0.25~"0-.25",
  mecs$RentAmt/mecs$Income>=.25 & mecs$RentAmt/mecs$Income<0.5~"0.25-0.5",
  mecs$RentAmt/mecs$Income>=.5 & mecs$RentAmt/mecs$Income<0.75~"0.5-0.75",
  mecs$RentAmt/mecs$Income>=.75 & mecs$RentAmt/mecs$Income<1~"0.75-1",
  mecs$RentAmt/mecs$Income>=1~"1+"
)
)

mecs$IncomePerResBin<-case_when(
  is.na(mecs$Income)|mecs$Income==0~"0",
  mecs$Income/mecs$Residents>0 & mecs$Income/mecs$Residents<200~"0-200",
  mecs$Income/mecs$Residents>=200 & mecs$Income/mecs$Residents<400~"200-400",
  mecs$Income/mecs$Residents>=400 & mecs$Income/mecs$Residents<600~"400-600",
  mecs$Income/mecs$Residents>=600 & mecs$Income/mecs$Residents<800~"600-800",
  mecs$Income/mecs$Residents>=800 & mecs$Income/mecs$Residents<1000~"800-1000",
  mecs$Income/mecs$Residents>=1000~"1000+"
)
mecs$IncomePerRes<-factor(mecs$IncomePerRes,
                          levels=c("0","0-200","200-400","400-600","600-800","800-1000","1000+"))


summary(mecs$Bedrooms)
mecs$Rooms<-case_when(
  mecs$Bedrooms=="STUDIO APARTMENT"~1,
  mecs$Bedrooms=="blank"~1,
  mecs$Bedrooms=="R IS RENTING A ROOM"~1,
  TRUE~1+as.numeric(as.character(mecs$Bedrooms))
)
summary(mecs$Rooms)

mecs$Bedrooms[mecs$case_id==218]

#Other adults living there
#other_spec<-filter(mecs_other, substr(ITEM,1,2)=="B5")
#other_spec$ITEM<-NULL
#other_spec$TEXT<-as.factor(case_when(
#  as.character(other_spec$TEXT) %in% c("fiance","Fiance","sign.other","baby's father'","baby's mom'",
#                         "boyfriend/ kid's father","child's father","Child's father",
#                         "lover'")~"Sig.Other",
#  as.character(other_spec$TEXT) %in% c("grandson","Gson")~"Other.Family",
#  TRUE~"Other"
#))
#summary(other_spec$TEXT)
#other_spec<-rename(other_spec,Relationship=TEXT)
#other_spec<-rename(other_spec,case_id=`CASE ID`)

#adults<-mecs%>%select(case_id,Judgement,AdultRelationship,Adult2Relationship,
#               Adult3Relationship,Adult4Relationship,Adult5Relationship)%>%
#  pivot_longer(c(AdultRelationship,Adult2Relationship,Adult3Relationship,
#               Adult4Relationship,Adult5Relationship),names_to="Adult",values_to="Relationship")
#adults$Adult<-NULL
#adults<-adults[!adults$Relationship=="",]
#adults$Relationship<-case_when(
#  adults$Relationship=="spouse"~"Spouse",
#  adults$Relationship=="BOYFRIEND OR GIRLFRIEND"~"Sig.Other",
#  adults$Relationship %in% c("AUNT OR UNCLE","child","NIECE OR NEPHEW","parent","sibling","cousin")~"Other.Family",
#  adults$Relationship=="friend"~"Friend",
#  TRUE~as.character(adults$Relationship)
#)
#adults<-adults[!adults$Relationship=="OTHER, SPECIFY",]
#adults<-merge(adults,other_spec,all=T)
#adults$Relationship<-as.factor(adults$Relationship)
#summary(as.factor(adults$Relationship))

mecs$AddlAdult<-as.factor(case_when(
  (mecs$AdultOnEviction=="yes"|mecs$Adult2OnEviction=="yes"|mecs$Adult3OnEviction=="yes"|
     mecs$Adult4OnEviction=="yes"|mecs$Adult5OnEviction=="yes")~"yes",
  TRUE~"no"
))

summary(mecs$AddlAdult)
summary(mecs$AdultRelationship)

#Number of adults on lease
mecs$Leaseholders<-1+as.numeric(mecs$AdultOnEviction=="yes")+as.numeric(mecs$Adult2OnEviction=="yes")+
  as.numeric(mecs$Adult3OnEviction=="yes")+as.numeric(mecs$Adult4OnEviction=="yes")+as.numeric(mecs$Adult5OnEviction=="yes")

#summary(as.factor(mecs$Leaseholders))
#mecs[mecs$Leaseholders>2,]


#Make Reasons into one Column
Reasons<-mecs%>%
  select(case_id,Default,Lease,Nuisance,Twentyeight,Foreclosure,Dispute,Fourteenday)%>%
  pivot_longer(c(Default,Lease,Nuisance,Twentyeight,Foreclosure,Dispute,Fourteenday),names_to = "Reasons")%>%
  filter(value!=0)%>%
  group_by(case_id)%>%
  mutate(Reason=(case_when(
    n()>1~"MULTIPLE",
    TRUE~as.character(Reasons)
  )))
Reasons$Reasons<-NULL
Reasons$value<-NULL
#There are three cases that don't have a reason listed
Reasons<-distinct(Reasons)
#Make Race into one Column
Race<-mecs%>%
  select(case_id,Race1,Race2)%>%
  mutate(Race=as.factor(case_when(
    (Race2!="")~"MIXED",
    TRUE~as.character(Race1))
  ))
Race$Race1<-NULL
Race$Race2<-NULL

mecs$MonthsBin<-as.factor(case_when(
  is.na(mecs$MonthsBehind)~"0",
  mecs$MonthsBehind==0~"0",
  mecs$MonthsBehind>0 & mecs$MonthsBehind<1~"0-1",
  mecs$MonthsBehind>=1 & mecs$MonthsBehind<2~"1-2",
  mecs$MonthsBehind>=2 & mecs$MonthsBehind<3~"2-3",
  mecs$MonthsBehind>=3 & mecs$MonthsBehind<4~"3-4",
  mecs$MonthsBehind>=4 & mecs$MonthsBehind<5~"4-5",
  mecs$MonthsBehind>=5 & mecs$MonthsBehind<6~"5-6",
  mecs$MonthsBehind>=6~"6+"
)
)
summary(mecs$MonthsBin)

mec<-select(mecs,case_id,Judgement,Rooms,RentAmt,RentBin,Income,IncomeBin,Owed,OwedBin,
            MonthsBehind,MonthsBin,OwedPerIncomeBin,RentPerIncomeBin,IncomePerResBin,Residents,
            Leaseholders,Children,Gender,Age,AgeBin,Hispanic,Race1,Race2,Race3)

mec$RaceHispanic<-as.factor(case_when(
  mec$Hispanic=="yes"~1,
  mec$Race1=="hispanic"~1,
  mec$Race2=="hispanic"~1,
  mec$Race3=="hispanic"~1,
  TRUE~0
))
mec$RaceBlack<-as.factor(case_when(
  mec$Race1=="BLACK OR AFRICAN AMERICAN"~1,
  mec$Race2=="BLACK OR AFRICAN AMERICAN"~1,
  mec$Race3=="BLACK OR AFRICAN AMERICAN"~1,
  TRUE~0  
))
mec$RaceWhite<-as.factor(case_when(
  mec$Race1=="white"~1,
  mec$Race2=="white"~1,
  mec$Race3=="white"~1,
  TRUE~0  
))
mec$RaceNative<-as.factor(case_when(
  mec$Race1=="AMERICAN INDIAN OR ALASKAN NATIVE"~1,
  mec$Race2=="AMERICAN INDIAN OR ALASKAN NATIVE"~1,
  mec$Race3=="AMERICAN INDIAN OR ALASKAN NATIVE"~1,
  TRUE~0  
))
mec$RaceIslander<-as.factor(case_when(
  mec$Race1=="NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER"~1,
  mec$Race2=="NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER"~1,
  mec$Race3=="NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER"~1,
  TRUE~0   
))
mec$Race1<-NULL
mec$Race2<-NULL
mec$Race3<-NULL
mec$Hispanic<-NULL

summary(mec)

mec$RentBin<-factor(mec$RentBin,ordered=F)
#mec$IncomeBin<-factor(mec$IncomeBin,ordered=F)
mec$OwedBin<-factor(mec$OwedBin,ordered=F)

encoding <- build_encoding(dataSet = mec, cols =c("RentBin","IncomeBin","OwedBin","MonthsBin","OwedPerIncome",
                                                  "RentPerIncome","IncomePerRes","Children","Gender","AgeBin"), verbose = TRUE)
mec <- one_hot_encoder(dataSet = mec, encoding = encoding, drop = FALSE, verbose = TRUE)
mec$Children.no<-NULL
mec$Gender.female<-NULL

mec$OwedPerIncome<-mec$Owed/mec$Income
mec$RentPerIncome<-mec$RentAmt/mec$Income
mec$IncomePerRes<-mec$Income/mec$Residents

summary(mec)
str(mec)
#constant_cols <- whichAreConstant(mec)
#double_cols <- whichAreInDouble(mec)
#bijections_cols <- whichAreBijection(mec)

#correlation plot for numeric variables------------------------------------------
library(corrplot)
mec_numeric<-select(mec,Rooms,Residents,RentAmt,Income,Owed,MonthsBehind,
                    Age,OwedPerIncome,RentPerIncome,IncomePerRes,Leaseholders,Judgement)
mec_numeric$Judgement<-as.numeric(mec_numeric$Judgement)
mec_numeric<-mec_numeric[is.finite(rowSums(mec_numeric)),]
cor_mec<-cor(mec_numeric)
#par(mfrow=c(1,2))
corrplot(corr=cor_mec, method = "ellipse", type="lower")
corrplot(corr=cor_mec, method = "number", type="lower",number.cex=1)

#-------------------------------------------

mec_ind<-tibble(Variable=colnames(mec)[2],p=signif(chisq.test(mec[[2]],mec[[2]])$p.value,4),Variable2="Judgement")


for (i in 3:ncol(mec)){
  mec_ind<-mec_ind%>%
    add_row(Variable=colnames(mec)[i],p=signif(chisq.test(mec[[i]],mec[[2]])$p.value,4),Variable2="Judgement")
}

ggplot(data=subset(mec_ind, p<0.3))+
  geom_tile(aes(x=Variable2,y=Variable,fill=p))+
  geom_text(aes(x=Variable2,y=Variable,label=p),size=3.25)+
  scale_fill_gradient(low = "white", high = "blue",limits=c(0,max(mec_ind$p)))+
  labs(title="Chi-Squared Test for Independence, p-values")

nrow(subset(mec_ind, p<0.3))
##Exploration--------------------------------------------------------------------------
p_outcomes<-ggplot(mecs)+
  geom_bar(aes(x=fct_rev(fct_infreq(Outcome)),fill=Judgement))+
  coord_flip()+
  scale_x_discrete(labels = function(x) str_wrap(x, width = 30))+
  theme(axis.title=element_blank())+
  labs(title="Eviction Court Outcomes")

#boxplot(mecs$MonthsBehind)


Explore1<-select(mecs,case_id,Judgement,Gender,AgeBin,Rooms,
                 OtherAdults,AdultsQty,Children,ChildrenQty,Residents,
                 MonthsBehind,MonthsBin,Owed,Income,RentAmt,RentAssistance)
Explore1<-merge(Explore1,Reasons,all.x = T)
Explore1<-merge(Explore1,Race,all.x=T)
Explore1$peoplePerRoom<-Explore1$Residents/Explore1$Rooms

mecs<-merge(mecs,Explore1)

Explore2<-mecs%>%
  select(case_id,Judgement,`Child<5`,`Child5-13`,`Child14+`)%>%
  pivot_longer(c(`Child<5`,`Child5-13`,`Child14+`),names_to = "Child_Age")%>%
  filter(value!=0)%>%
  group_by(case_id)
ct <- table(Explore2$Child_Age,Explore2$Judgement,dnn=c("Child_Age", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
ChildAgeTable<-merge(ct.df,pt.df)
p_childs_age<-ggplot(ChildAgeTable,aes(x=Child_Age,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(ChildAgeTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))

ct <- table(adults$Relationship,adults$Judgement,dnn=c("Relationship", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
RelationshipTable<-merge(ct.df,pt.df)
p_relationship<-ggplot(RelationshipTable,aes(x=Relationship,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(RelationshipTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))

chisq.test(adults$Relationship,adults$Judgement)
##Contingency Tables----------------------------------------------------------------------------------
##case_id: Reason, Sex, Age, Race, Children(Binary), Other Adults(Binary)
##More detail on:  Apt & Rent Info, Income Info, Household Info
#Two events, A and B, are independent if P(A|B)=P(A) and P(B|A)=P(B)

#A histogram/barplot for each variable versus Judgement

#Total
ct <- table(Explore1$Judgement,dnn=c("Judgement"))
pt<-prop.table(ct)
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
OutcomeTable<-merge(ct.df,pt.df)
p_total<-ggplot(OutcomeTable,aes(x="Eviction Court Outcomes",y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))+
  labs(title="Eviction Court Outcomes")



#Variable:Reason/Cause on Eviction Notice
ct <- table(Explore1$Reason,Explore1$Judgement,dnn=c("Reason", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
ReasonTable<-merge(ct.df,pt.df)
p_reason<-ggplot(ReasonTable,aes(x=Reason,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(ReasonTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))+
  coord_flip()+
  labs(title="Eviction Court Outcomes by Reason")
#mecs[mecs$Reason=="MULTIPLE",]
#Variable: Months Behind, Amount Owed, On Assisstance, Owed/Income
ct <- table(Explore1$MonthsBin,Explore1$Judgement,dnn=c("MonthsBin", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
BehindTable<-merge(ct.df,pt.df)
p_months<-ggplot(BehindTable,aes(x=MonthsBin,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(BehindTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))
#On Rent Assisstance
ct <- table(Explore1$RentAssistance,Explore1$Judgement,dnn=c("RentAssistance", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
AssistanceTable<-merge(ct.df,pt.df)
p_assistance<-ggplot(AssistanceTable,aes(x=RentAssistance,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(AssistanceTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))

#rent
ct <- table(mecs$RentBin,mecs$Judgement,dnn=c("Rent", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
RentTable<-merge(ct.df,pt.df)
p_rent<-ggplot(RentTable,aes(x=Rent,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(RentTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))


#Box Plot
p_rent_box<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=RentAmt))
p_owed<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=Owed))
p_income<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=Income))

#Months Behind, Owed/Income, Rent/Income, Income/Residents
p_months_box<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=MonthsBehind))
p_owedPerIncome<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=Owed/Income))
p_rentPerIncome<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=RentAmt/Income))
p_behindPerIncome<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=MonthsBehind/Income))
p_incomePerResident<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=Income/Residents))


grid.arrange(p_rent_box,p_owed,p_income,
             p_months_box,p_owedPerIncome,p_rentPerIncome,
             p_behindPerIncome,p_incomePerResident,nrow=1,
             top = textGrob('Eviction Judgement vs Financial Metrics, Continuous Variables', 
                            gp = gpar(fontsize = 15, font = 2)))

#Faceted by Children, Age, Gender:  Months Behind, Income/Residents?
p1<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=Owed/Income))+
  facet_wrap(~Children)+
  labs(title="Faceted by Children")
p2<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=Owed/Income))+
  facet_wrap(~AgeBin,nrow=1)+
  labs(title="Faceted by Age")
p3<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=Owed/Income))+
  facet_wrap(~Gender)+
  labs(title="Faceted by Gender")

grid.arrange(p1,p2,p3,nrow=1,
             top = textGrob('Judgement by Amount Owed/Income', 
                            gp = gpar(fontsize = 15, font = 2)))
#Categorical: Assistance, Months Bin

grid.arrange(p_rent,p_months,p_assistance,nrow=1,
             top = textGrob('Eviction Judgement vs Financial Metrics, Categorical Variabes', 
                            gp = gpar(fontsize = 15, font = 2)))
#Demographics/Household-------------------------------------------------------------------------------
#Variable:Age
ct <- table(Explore1$AgeBin,Explore1$Judgement,dnn=c("Age", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
AgeTable<-merge(ct.df,pt.df)
p_age<-ggplot(AgeTable,aes(x=Age,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))
ct
summary(ct)
mosaic(ct,shade=T)
#Variable:Race
ct <- table(Explore1$Race,Explore1$Judgement,dnn=c("Race", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
RaceTable<-merge(ct.df,pt.df)
p_race<-ggplot(RaceTable,aes(x=Race,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(RaceTable, Freq>5),
            aes(label=paste0(round(100*Prop,1),"%")),
            position = position_stack(vjust = .5))+
  coord_flip()
#Variable:Gender
ct <- table(Explore1$Gender,Explore1$Judgement,dnn=c("Gender", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
GenderTable<-merge(ct.df,pt.df)
p_gender<-ggplot(GenderTable,aes(x=Gender,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))
#Variable:Children
ct <- table(Explore1$Children,Explore1$Judgement,dnn=c("Children", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
ChildrenTable<-merge(ct.df,pt.df)
p_child<-ggplot(ChildrenTable,aes(x=Children,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(ChildrenTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))

#Variable:Number of Children
ct <- table(Explore1$ChildrenQty,Explore1$Judgement,dnn=c("Children", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
ChildrensTable<-merge(ct.df,pt.df)
p_children<-ggplot(ChildrensTable,aes(x=Children,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(ChildrensTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))
#Variable:Other Adults
ct <- table(Explore1$OtherAdults,Explore1$Judgement,dnn=c("OtherAdults", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
AdultsTable<-merge(ct.df,pt.df)
p_adults<-ggplot(AdultsTable,aes(x=OtherAdults,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(AdultsTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))
#Variable:Other Adults on Notice?
ct <- table(mecs$AddlAdult,mecs$Judgement,dnn=c("OtherAdult", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
AdultLeaseTable<-merge(ct.df,pt.df)
p_adults2<-ggplot(AdultLeaseTable,aes(x=OtherAdult,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(AdultLeaseTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))
#total people?
ct <- table(Explore1$Residents,Explore1$Judgement,dnn=c("Residents", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
ResidentsTable<-merge(ct.df,pt.df)
p_residents<-ggplot(ResidentsTable,aes(x=Residents,y=Freq,fill=Judgement))+
  geom_bar(stat="identity")+
  geom_text(data=subset(ResidentsTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))
#people/room?
ct <- table(Explore1$peoplePerRoom,Explore1$Judgement,dnn=c("PeoplePerRoom", "Judgement"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
PerRoomTable<-merge(ct.df,pt.df)
ggplot(PerRoomTable,aes(x=PeoplePerRoom,y=Freq,fill=Judgement))+
geom_bar(stat="identity")+
  geom_text(data=subset(PerRoomTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))

summary(ct)
#other adult(s) spouse vs another relationship?
#other_spec<-filter(mecs_other,ITEM %like% "B5")


#--------------------------------
p_total
p_reason
p_race
grid.arrange(p_assistance,p_months,p_rent,nrow=1)
grid.arrange(p_age,p_gender,p_child,p_children,p_adults,p_residents,
             nrow = 2)

grid.arrange(p_child,p_age,p_gender,nrow=1)
#What about covariance?-------------------------------------------------
p_child_gender<-ggplot(mecs)+
  geom_bar(aes(x=Children,fill=Gender),position="dodge")
p_child_age<-ggplot(mecs)+
  geom_bar(aes(x=Children,fill=AgeBin),position="dodge")
p_child_rent<-ggplot(mecs)+
  geom_bar(aes(x=Children,fill=RentBin),position="dodge")+ theme(axis.text.x = element_text(angle = 45))
p_child_behind<-ggplot(mecs)+
  geom_bar(aes(x=Children,fill=MonthsBin),position="dodge")

grid.arrange(p_child_gender,p_child_age,p_child_rent,p_child_behind,nrow=1,
             top = textGrob('Variables Relative to Living With Children',
                            gp = gpar(fontsize = 15, font = 2)))


p_child_opi<-ggplot(mecs)+
  geom_bar(aes(x=Children,fill=OwedPerIncome),position="dodge")
p_child_rpi<-ggplot(mecs)+
  geom_bar(aes(x=Children,fill=RentPerIncome),position="dodge")+ 
  theme(axis.text.x = element_text(angle = 45))
p_child_ipr<-ggplot(mecs)+
  geom_bar(aes(x=Children,fill=IncomePerRes),position="dodge")+ 
  theme(axis.text.x = element_text(angle = 45))

grid.arrange(p_child_opi,p_child_rpi,p_child_ipr,nrow=1,
             top = textGrob('Financial Variables Relative to Living With Children',
                            gp = gpar(fontsize = 15, font = 2)))

p_child_race<-ggplot(mecs)+
  geom_bar(aes(x=Children,fill=Race),position="dodge")
p_assistance_rent<-ggplot(mecs)+
  geom_bar(aes(x=RentBin,fill=RentAssistance),position="dodge")
#Women & Children
#(Children, Gender, Race) & Amount Due/Months Behind/Income
#

#Understanding this in Contingency Tables & Mosaic Plot--------------------------
ftable(xtabs(~Judgement+(Race)+Gender,data=mecs))
RaceGender<-xtabs(~Judgement+as.numeric(Race)+Gender,data=mecs)
mosaic(RaceGender,shade=T)

ggplot(mecs)+
  geom_bar(aes(x=Judgement,fill=Race))+
  facet_wrap(~Gender,nrow=2)
summary(RaceGender)
#From this plot, I think I see:
#There are more females in this data set than males, there are more Black/African American people than other races
#For females, the proportions of race with each judgement look like they could be close to equal
#For males, the proportions of colors between judgements make it look like less black males and more white males get 1
#(Is this actually a predictor or is it because of correlations with other variables (like how much is owed, etc.))

#What does the positive Pearson residuals for white and hispanic men and negative for black men mean?

#Test of independence of all factors:  p-value=4.7e-5
ftable(xtabs(~OwedBin+(Race)+Gender,data=mecs))
RaceGenderOwed<-xtabs(~OwedBin+as.numeric(Race)+Gender,data=mecs)
mosaic(RaceGenderOwed,shade=T)

ftable(xtabs(~Children+(Race)+Gender,data=mecs))
RaceGenderChild<-xtabs(~Children+as.numeric(Race)+Gender,data=mecs)
mosaic(RaceGenderChild,shade=T)


RaceGenderReason<-xtabs(~Reason+as.numeric(Race)+Gender,data=Explore1)
ftable(RaceGenderReason)
mosaic(RaceGenderReason)


ChildOPI<-xtabs(~Judgement+OwedPerIncome+Children,data=mecs)
ftable(ChildOPI)
mosaic(ChildOPI,shade=T)

ChildRPI<-xtabs(~Judgement+RentPerIncome+Children,data=mecs)
ftable(ChildRPI)
mosaic(ChildRPI,shade=T)

ChildIPR<-xtabs(~Judgement+IncomePerRes+Children,data=mecs)
ftable(ChildIPR)
mosaic(ChildIPR,shade=T)


ggplot(Explore1)+
  geom_bar(aes(x=Judgement,fill=Race))+
  facet_wrap(~Reason,nrow=2)

ggplot(Explore1)+
  geom_bar(aes(x=Judgement,fill=Children))+
  facet_wrap(~Reason,nrow=2)

Nuisance<-filter(mecs,Nuisance==1)


#Amount Owed & Income
p1<-ggplot(mecs)+
  geom_point(aes(x=Owed,y=Income,color=Judgement))

p3<-ggplot(mecs)+
  geom_boxplot(aes(x=Judgement,y=Owed/Income))+
  facet_wrap(~Children)+
  labs(title="Owed/Income by Children")

grid.arrange(p_owed,p_owedPerIncome,p3,p1,nrow=2)

#If the relationship between owed & income is significant, how would I treat that in the model?
#What if that relatoinship depends on children yes/no?
#Use Owed and Income as predictors? (Judgement~Owed+Income)
#Use the ratio? (Judgement~Owed/Income)
#Something like (Judgement~Owed*Income)


ggplot(mecs)+
  geom_histogram(aes(MonthsBehind,fill=Judgement))+
  facet_wrap(~Children)

#Household People
summary(mecs$ChildrenQty)
ggplot(mecs)+
  geom_histogram(aes(ChildrenQty,fill=Judgement))


grid.arrange(p_outcomes, p_total,nrow = 1)

#Tests for Independence--------------------------------------------------------
#Variables:
#Reason
#Financial:  Rooms, Rent, Owed, Income, Assistance, Months Behind (Owed/Rent), Income/Owed, Income/Months Behind
##Income/Resident, Owed/Resident?
#Household: Age, Race, Gender, Children, Children Qty, Adults, Adults Qty, Total Residents, Residents/Room
##Children Age, Adults Relationship, Another Adult on Lease

options(scipen = 1)
options(digits = 7)

#Still add bins for Owed/Income, Rent/Income, Income/Residents

ind_test<-tibble(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$Judgement)$p.value,4),Variable2="Judgement")

ind_test<-ind_test%>%
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBin,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Age",p=signif(chisq.test(mecs$AgeBin,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Gender",p=signif(chisq.test(mecs$Gender,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Children",p=signif(chisq.test(mecs$Children,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Children.Qty",p=signif(chisq.test(as.factor(mecs$ChildrenQty),mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Adults",p=signif(chisq.test(mecs$OtherAdults,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Adults.Qty",p=signif(chisq.test(as.factor(mecs$AdultsQty),mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="Total.Residents",p=signif(chisq.test(mecs$Residents,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="ResidentsPerRoom",p=signif(chisq.test(round(mecs$peoplePerRoom/.5)*.5,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="OwedPerIncome",p=signif(chisq.test(mecs$OwedPerIncomeBin,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="RentPerIncome",p=signif(chisq.test(mecs$RentPerIncomeBin,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  add_row(Variable="IncomePerResident",p=signif(chisq.test(mecs$IncomePerResBin,mecs$Judgement)$p.value,4),Variable2="Judgement")%>%
  
    
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$OwedBin)$p.value,4),Variable2="Owed")%>%  
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$IncomeBin)$p.value,4),Variable2="Income")%>%
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$RentBin)$p.value,4),Variable2="Rent")%>%  
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$Rooms)$p.value,4),Variable2="Rooms")%>% 
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$RentAssistance)$p.value,4),Variable2="Assistance")%>%  
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$MonthsBehind)$p.value,4),Variable2="Months.Behind")%>%  
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$Race)$p.value,4),Variable2="Race")%>%  
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$AgeBin)$p.value,4),Variable2="Age")%>% 
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Reason",p=signif(chisq.test(mecs$Reason,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$IncomeBin)$p.value,4),Variable2="Income")%>%
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$RentBin)$p.value,4),Variable2="Rent")%>%  
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$Rooms)$p.value,4),Variable2="Rooms")%>% 
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$RentAssistance)$p.value,4),Variable2="Assistance")%>%  
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$MonthsBehind)$p.value,4),Variable2="Months.Behind")%>%  
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$Race)$p.value,4),Variable2="Race")%>%  
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$AgeBin)$p.value,4),Variable2="Age")%>% 
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Owed",p=signif(chisq.test(mecs$OwedBin,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$RentBin)$p.value,4),Variable2="Rent")%>%  
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$Rooms)$p.value,4),Variable2="Rooms")%>% 
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$RentAssistance)$p.value,4),Variable2="Assistance")%>%  
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$MonthsBehind)$p.value,4),Variable2="Months.Behind")%>%  
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$Race)$p.value,4),Variable2="Race")%>%  
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$AgeBin)$p.value,4),Variable2="Age")%>% 
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Income",p=signif(chisq.test(mecs$IncomeBin,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%  
  
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$Rooms)$p.value,4),Variable2="Rooms")%>% 
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$RentAssistance)$p.value,4),Variable2="Assistance")%>%  
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$MonthsBehind)$p.value,4),Variable2="Months.Behind")%>%  
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$Race)$p.value,4),Variable2="Race")%>%  
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$AgeBin)$p.value,4),Variable2="Age")%>% 
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Rent",p=signif(chisq.test(mecs$RentBin,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$RentAssistance)$p.value,4),Variable2="Assistance")%>%  
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$MonthsBehind)$p.value,4),Variable2="Months.Behind")%>%  
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$Race)$p.value,4),Variable2="Race")%>%  
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$AgeBin)$p.value,4),Variable2="Age")%>% 
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Rooms",p=signif(chisq.test(mecs$Rooms,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$MonthsBehind)$p.value,4),Variable2="Months.Behind")%>%  
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$Race)$p.value,4),Variable2="Race")%>%  
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$AgeBin)$p.value,4),Variable2="Age")%>% 
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Assistance",p=signif(chisq.test(mecs$RentAssistance,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,mecs$Race)$p.value,4),Variable2="Race")%>%  
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,mecs$AgeBin)$p.value,4),Variable2="Age")%>% 
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Months.Behind",p=signif(chisq.test(mecs$MonthsBehind,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,mecs$AgeBin)$p.value,4),Variable2="Age")%>% 
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Race",p=signif(chisq.test(mecs$Race,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Age",p=signif(chisq.test(mecs$AgeBin,mecs$Gender)$p.value,4),Variable2="Gender")%>% 
  add_row(Variable="Age",p=signif(chisq.test(mecs$AgeBin,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Age",p=signif(chisq.test(mecs$AgeBin,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Age",p=signif(chisq.test(mecs$AgeBin,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Age",p=signif(chisq.test(mecs$AgeBin,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Age",p=signif(chisq.test(mecs$AgeBin,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Age",p=signif(chisq.test(mecs$AgeBin,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Gender",p=signif(chisq.test(mecs$Gender,mecs$Children)$p.value,4),Variable2="Children")%>%
  add_row(Variable="Gender",p=signif(chisq.test(mecs$Gender,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Gender",p=signif(chisq.test(mecs$Gender,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Gender",p=signif(chisq.test(mecs$Gender,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Gender",p=signif(chisq.test(mecs$Gender,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Gender",p=signif(chisq.test(mecs$Gender,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Children",p=signif(chisq.test(mecs$Children,mecs$ChildrenQty)$p.value,4),Variable2="Children.Qty")%>%
  add_row(Variable="Children",p=signif(chisq.test(mecs$Children,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Children",p=signif(chisq.test(mecs$Children,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Children",p=signif(chisq.test(mecs$Children,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Children",p=signif(chisq.test(mecs$Children,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Children.Qty",p=signif(chisq.test(mecs$ChildrenQty,mecs$OtherAdults)$p.value,4),Variable2="Adults")%>%
  add_row(Variable="Children.Qty",p=signif(chisq.test(mecs$ChildrenQty,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Children.Qty",p=signif(chisq.test(mecs$ChildrenQty,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Children.Qty",p=signif(chisq.test(mecs$ChildrenQty,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Adults",p=signif(chisq.test(mecs$OtherAdults,mecs$AdultsQty)$p.value,4),Variable2="Adults.Qty")%>%
  add_row(Variable="Adults",p=signif(chisq.test(mecs$OtherAdults,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Adults",p=signif(chisq.test(mecs$OtherAdults,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Adults.Qty",p=signif(chisq.test(mecs$AdultsQty,mecs$Residents)$p.value,4),Variable2="Total.Residents")%>%
  add_row(Variable="Adults.Qty",p=signif(chisq.test(mecs$AdultsQty,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom")%>%
  
  add_row(Variable="Total.Residents",p=signif(chisq.test(mecs$Residents,round(mecs$peoplePerRoom/.5)*.5)$p.value,4),Variable2="ResidentsPerRoom") 

ind_test$Variable<-factor(ind_test$Variable,levels= rev(c("Judgement","Reason","Owed","Income","Rent","Rooms","Assistance","Months.Behind",
                             "Race","Age","Gender","Children","Children.Qty","Adults","Adults.Qty","Total.Residents","ResidentsPerRoom",
                             "OwedPerIncome","RentPerIncome","IncomePerResident")))
ind_test$Variable2<-factor(ind_test$Variable2,levels= c("Judgement","Reason","Owed","Income","Rent","Rooms","Assistance","Months.Behind",
                                                      "Race","Age","Gender","Children","Children.Qty","Adults",
                                                      "Adults.Qty","Total.Residents","ResidentsPerRoom"))

#*Continuous variables converted to categorical bins for consistent analysis
#

ggplot(ind_test)+
  geom_tile(aes(x=Variable2,y=Variable,fill=p))+
  geom_text(aes(x=Variable2,y=Variable,label=p),size=3.25)+
  scale_fill_gradient(low = "white", high = "blue",limits=c(0,max(ind_test$p)))+
  labs(title="Chi-Squared Test for Independence, p-values",
       subtitle = "Note: Continuous Variables in Categorical Bins")

ggplot(mecs)+
  geom_jitter(aes(x=RentBin,y=round(mecs$peoplePerRoom/.5)*.5, color=Judgement))+
  geom_smooth(aes(x=as.numeric(RentBin),y=round(mecs$peoplePerRoom/.5)*.5))+
  labs(title="Statistically significant dependence between Rent and People Per Room?")

#tatistically significant dependence between Rent and People Per Room? no
ct <- table(mecs$RentBin,round(mecs$peoplePerRoom/.5)*.5,dnn=c("Rent", "PeoplePerRoom"))
pt<-prop.table(ct, margin=1) # Row Proportions
ct.df<-data.frame(ct)
pt.df<-data.frame(pt)
pt.df<-rename(pt.df,Prop=Freq)
perRoomTable<-merge(ct.df,pt.df)
ggplot(perRoomTable,aes(x=Rent,y=Freq,fill=PeoplePerRoom))+
  geom_bar(stat="identity")+
  geom_text(data=subset(perRoomTable, Freq>3),
            aes(label=paste0(round(100*Prop,1),"%")),position = position_stack(vjust = .5))
mosaic(ct,shade=T)  

ggplot(mecs)+
  geom_jitter(aes(x=Rooms,y=peoplePerRoom, color=Judgement))+
  geom_smooth(aes(x=Rooms,y=peoplePerRoom))


ct <- table(mecs$RentBin,mecs$Children,dnn=c("Rent", "Children"))
mosaic(ct,shade=T,labeling = vcd::labeling_border(rot_labels = c(0, 90, 0,0),
                                                  just_labels = "right",
                                                  pos_labels="right"))
       
ct <- table(mecs$MonthsBin,mecs$Children,dnn=c("Months Behind", "Children"))
mosaic(ct,shade=T,labeling = vcd::labeling_border(rot_labels = c(0, 90, 0,0),
                                                  just_labels = "right",
                                                  pos_labels="center"))



ct <- table(mecs$Gender,mecs$Children,dnn=c("Gender", "Children"))
mosaic(ct,shade=T)
a<-grid.grab()
ct <- table(mecs$AgeBin,mecs$Children,dnn=c("Age", "Children"))
mosaic(ct,shade=T,labeling = vcd::labeling_border(rot_labels = c(0, 90, 0,0),
                                                  just_labels = "right",
                                                  pos_labels="center"))
b<-grid.grab()
mosaic(ChildIPR,shade=T)
c<-grid.grab()

mecs$Children<-factor(mecs$Children,levels=c("no","yes"))

summary(mecs$Children)
ct <- table(mecs$RentBin,mecs$Children,dnn=c("Rent", "Children"))
mosaic(ct,shade=T,labeling = vcd::labeling_border(rot_labels = c(0, 90, 0,0),
                                                  just_labels = "right",
                                                  pos_labels="right"))
d<-grid.grabExpr(mosaic(ct,shade=T))

grid.arrange(a,b,c,nrow=2)


#mec independence tests
#-package citations----------------------------------------------------------------
citation(package="tidyverse")
citation(package="ggplot2")
citation("gridExtra")
citation("stringr")
citation("forcats")
citation("readxl")
citation("vcd")
citation("dataPreparation")

#Modeling-----------------------------------------------------------------------------------------------------
library(caret)
library(broom)
citation("caret")
citation("broom")
#str(mec)
#deal NA values in dataset?
mec[rowSums(is.na(mec)) > 0, ]
mec[is.na(mec$RentAmt),]

mec[mec$Income==0,]

mec[is.na(mec$Income),]

summary(mec$RentAmt)
summary(mec$Income)
summary(mec$IncomeBin)
#There are 2 records with NA for rent amount.
#There are 14 rows where income is not known or refused.
#For models that use Income as a predictor, exclude rows where income is don't know or refused (14 rows)
#Rent Amt is NA (1 row)
#income=0 (19 rows)

#mec[mec$Income!=0,]
#mec[!is.na(mec$Income),]
#mec[!is.na(mec$RentAmt),]
#mec[complete.cases(mec),]


#Partition----------------------------------------------------------------------------------------
set.seed(123)
#trainIndex <- createDataPartition(mec$Judgement, p = .6, list = FALSE,  times = 1)
#train<-mec[trainIndex,]

sample <- sample(c(TRUE, FALSE), nrow(mec), replace = T, prob = c(0.6,0.4))
train <- mec[sample, ]
eval_set <- mec[!sample, ]
sample2 <- sample(c(TRUE, FALSE), nrow(eval_set), replace = T, prob = c(0.5,0.5))
validation<-eval_set[!sample2,]
test<-eval_set[sample2,]

#Models------------------------------------------------------------------------------------------------
model1 <- glm(Judgement ~ Children.yes, family = "binomial", data = train)
summary(model1)
m1<-tidy(model1)
m1$Model<-"Model01"
models<-m1

model2 <- glm(Judgement ~ MonthsBehind, family = "binomial", data = train)
summary(model2)
m2<-tidy(model2)
m2$Model<-"Model02"
models<-rbind(models,m2)

model3 <- glm(Judgement ~ MonthsBin, family = "binomial", data = train)
#summary(model3)
m3<-tidy(model3)
m3$Model<-"Model03"
models<-rbind(models,m3)

model4 <- glm(Judgement ~ Children.yes+MonthsBehind, family = "binomial", data = train)
summary(model4)
m4<-tidy(model4)
m4$Model<-"Model04"
models<-rbind(models,m4)

model5 <- glm(Judgement ~ Children.yes*MonthsBin, family = "binomial", data = train)
#summary(model5)
m5<-tidy(model5)
m5$Model<-"Model05"
models<-rbind(models,m5)

model6<-glm(Judgement ~ MonthsBehind+Gender.male+AgeBin+RaceBlack+RaceWhite+RaceHispanic, 
            family = "binomial", data = train)
#summary(model6)
m6<-tidy(model6)
m6$Model<-"Model06"
models<-rbind(models,m6)


model7<-glm(Judgement ~  MonthsBehind+AgeBin+Gender.male*RaceBlack*RaceWhite*RaceHispanic, 
             family = "binomial", data = train)
#summary(model7)
m7<-tidy(model7)
m7$Model<-"Model07"
models<-rbind(models,m7)

model8<- glm(Judgement ~ Age+Gender.male+RaceHispanic+RaceWhite+RaceBlack+Children.yes,
              family = "binomial", data = train)
#summary(model8)
m8<-tidy(model8)
m8$Model<-"Model08"
models<-rbind(models,m8)

model9<- glm(Judgement ~ Age+Gender.male+Children.yes,family = "binomial", data = train)
#summary(model9)
m9<-tidy(model9)
m9$Model<-"Model09"
models<-rbind(models,m9)

model10<-glm(Judgement ~ RentAmt+Income+Owed, 
             family = "binomial", data = train[(!is.na(train$Income))])
#summary(model10)
m10<-tidy(model10)
m10$Model<-"Model10"
models<-rbind(models,m10)

model11<-glm(Judgement ~ RentBin+IncomeBin+OwedBin, 
             family = "binomial", data = train)
#summary(model11)
m11<-tidy(model11)
m11$Model<-"Model11"
models<-rbind(models,m11)

model12<-glm(Judgement ~ IncomeBin*OwedBin, 
             family = "binomial", data = train)
summary(model12)
m12<-tidy(model12)
m12$Model<-"Model12"
models<-rbind(models,m12)

model13 <- glm(Judgement ~ MonthsBehind+OwedPerIncome+IncomePerRes,
               family = "binomial", data = train[train$Income!=0])
summary(model13)
m13<-tidy(model13)
m13$Model<-"Model13"
models<-rbind(models,m13)

model14 <- glm(Judgement ~ Age+Gender.male+RaceHispanic+RaceWhite+RaceBlack+Children.yes+Leaseholders+ 
                Rooms+RentAmt+Income+Owed+
                MonthsBehind+OwedPerIncome+RentPerIncome+IncomePerRes, 
              family = "binomial", data = train[train$Income!=0])
#summary(model14)
m14<-tidy(model14)
m14$Model<-"Model14"
models<-rbind(models,m14)

#set15<-(select(mec,Age,Gender.male,RaceHispanic,RaceWhite,RaceBlack,Children.yes,OtherAdults,
#         Rooms,IncomePerRes,MonthsBehind))
#set15[!complete.cases(set15),]

model15 <- glm(Judgement ~ Age+Gender.male+RaceHispanic+RaceWhite+RaceBlack+Children.yes+Leaseholders+
                Rooms+IncomePerRes+MonthsBehind, 
              family = "binomial", data = train)

summary(model15)
m15<-tidy(model15)
m15$Model<-"Model15"
models<-rbind(models,m15)

model16 <- glm(Judgement ~ Age+Gender.male+RaceHispanic+RaceWhite+RaceBlack+Children.yes+Leaseholders+
                 Rooms+RentBin+IncomeBin+OwedBin+
                 MonthsBin+OwedPerIncomeBin+RentPerIncomeBin+IncomePerResBin, 
               family = "binomial", data = train[train$Income!=0])
summary(model16)
m16<-tidy(model16)
m16$Model<-"Model16"
models<-rbind(models,m16)

model17 <- glm(Judgement ~ Gender.male,family = "binomial", data = train)
m17<-tidy(model17)
m17$Model<-"Model17"
models<-rbind(models,m17)

model18 <- glm(Judgement ~ Gender.male+Rooms+OwedPerIncomeBin, 
               family = "binomial", data = train)
m18<-tidy(model18)
m18$Model<-"Model18"
models<-rbind(models,m18)

model19 <- glm(Judgement ~ Gender.male+Children.yes+OwedPerIncomeBin, 
               family = "binomial", data = train)
m19<-tidy(model19)
m19$Model<-"Model19"
models<-rbind(models,m19)

model20<-glm(Judgement ~ Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, 
             family = "binomial", data = train)
m20<-tidy(model20)
m20$Model<-"Model20"
models<-rbind(models,m20)

model21<-glm(Judgement ~ Gender.male+Rooms+IncomePerRes+MonthsBehind, 
             family = "binomial", data = train)
m21<-tidy(model21)
m21$Model<-"Model21"
models<-rbind(models,m21)

model22<-glm(Judgement ~ Children.yes+IncomePerRes+MonthsBehind, 
             family = "binomial", data = train)
m22<-tidy(model22)
m22$Model<-"Model22"
models<-rbind(models,m22)


model23 <- glm(Judgement ~ Gender.male+IncomePerRes+MonthsBehind, 
               family = "binomial", data = train)
m23<-tidy(model23)
m23$Model<-"Model23"
models<-rbind(models,m23)

model24 <- glm(Judgement ~ Age+Gender,family = "binomial", data = train)
m24<-tidy(model24)
m24$Model<-"Model24"
models<-rbind(models,m24)

model25 <- glm(Judgement ~ Age+Gender+Owed+Rooms+IncomeBin,family = "binomial", data = train)
m25<-tidy(model25)
m25$Model<-"Model25"
models<-rbind(models,m25)

model26 <- glm(Judgement ~ Children.yes+MonthsBehind+Leaseholders+RaceBlack+
                 Gender.male+Age+Income, "binomial", data = train)
summary(model26)
m26<-tidy(model26)
m26$Model<-"Model26"
models<-rbind(models,m26)

model27 <- glm(Judgement ~ Children.yes+MonthsBehind+Gender.male, "binomial", data = train)
summary(model27)
m27<-tidy(model27)
m27$Model<-"Model27"
models<-rbind(models,m27)

#exp(coef(model1))
#confint(model1)
#predict(model1, data.frame(MonthsBehind = c(0:15)), type = "response")
#predict(model1,type="response")
#predict(model1, data.frame(MonthsBehind =mec$MonthsBehind), type = "response")

#ggplot(mec) +
#  geom_point(aes(MonthsBehind, as.numeric(as.character(Judgement))),alpha = .15) +
  #geom_smooth(method = "glm", method.args = list(family = "binomial")) +
#  geom_line(aes(x=MonthsBehind,y=predict(model1, data.frame(MonthsBehind =mec$MonthsBehind), type = "response")))+
#  ggtitle("Logistic regression model fit") +
#  xlab("Months Behind") +
#  ylab("Probability of Eviction Judgement")

#Summary of model coefficients----------------------------------------------------------------------------------

library(matrixStats)
citation("matrixStats")

models<-filter(models,!(Model %in% c("Model12","Model16")))

model_coefs<-models%>%
  dplyr::select(term,estimate,Model)%>%
  pivot_wider(names_from=Model,values_from = c(estimate))

model_coefs<-mutate(model_coefs,mean=rowMeans(model_coefs[,2:24], na.rm=T),
         stdev=rowSds(as.matrix(model_coefs[,2:24]), na.rm=T))

model_p<-models%>%
  dplyr::select(term,p.value,Model)%>%
  pivot_wider(names_from=Model,values_from = c(p.value))

model_odds<-models%>%
  mutate(odds=exp(estimate))%>%
  dplyr::select(term,odds,Model)%>%
  pivot_wider(names_from=Model,values_from = c(odds))

ggplot(models)+
  geom_tile(aes(x=Model,y=term,fill=p.value))+
  geom_text(aes(x=Model,y=term,label=signif(estimate,3)),size=3.25)+
  scale_fill_gradient(low = "yellow", high = "grey",limits=c(0,1))+
  labs(title="Model Coefficients")

ggplot(subset(models,Model %in% c("Model04","Model07","Model11","Model13",
                                  "Model14","Model18","Model20",
                                  "Model26","Model26","Model27")))+
  geom_tile(aes(x=Model,y=term,fill=p.value))+
  geom_text(aes(x=Model,y=term,label=signif(estimate,3)),size=3.25)+
  scale_fill_gradient(low = "yellow", high = "grey",limits=c(0,1))+
  labs(title="Model Coefficients")
#anova tests---------------------------------------------------------------
#which models are significantly different from each other?
#anova(model2, model3, test = "LRT")
#anova(model1, model4, test = "Chisq")
anova(model2, model4, test = "Chisq")
anova(model4, model27, test = "Chisq")
#anova(model27, model26, test = "Chisq")
#anova(model14, model20, test = "Chisq")
#anova(model15, model14, test = "Chisq")
#anova(model7, model18, test = "Chisq")
anova(model4, model6, test = "Chisq")
#anova(model5, model6, test = "Chisq")
anova(model6, model7, test = "Chisq")

anova(model24, model25, test = "Chisq")
anova(model26, model27, test = "Chisq")
#anova(model2, model3, test = "Chisq")
#anova(model4, model5, test = "Chisq")
#anova(model10, model11, test = "Chisq")
#anova(model10, model13, test = "Chisq")
#anova(model11, model13, test = "Chisq")
#anova(model20, model26, test = "Chisq")
#anova(model18, model19, test = "Chisq")

caret::varImp(model16,scale=F)

#model fit and diagnostics:  Goodness of fit----------------------------------------------------------------

library(pscl)
citation("pscl")

#model fit statistics: llh, R^2, AIC, (Null Deviance,Residual Deviance compare -->Chi^2 likelihood ratio)
model_fit<-tibble(Model="Model01",Predictors=nrow(m1)-1,
                  McFadden=signif(pscl::pR2(model1)["McFadden"],3),
                  Deviance=signif(model1$deviance,3),AIC=signif(model1$aic,4))

model_fit<-model_fit%>%
  add_row(Model="Model02",Predictors=nrow(m2)-1,
          McFadden=signif(pscl::pR2(model2)["McFadden"],3),
          Deviance=signif(model2$deviance,3),AIC=signif(model2$aic,4))%>%
  add_row(Model="Model03",Predictors=nrow(m3)-1,
          McFadden=signif(pscl::pR2(model3)["McFadden"],3),
          Deviance=signif(model3$deviance,3),AIC=signif(model3$aic,4))%>%
  add_row(Model="Model04",Predictors=nrow(m4)-1,
          McFadden=signif(pscl::pR2(model4)["McFadden"],3),
          Deviance=signif(model4$deviance,3),AIC=signif(model4$aic,4))%>%
  add_row(Model="Model05",Predictors=nrow(m5)-1,
          McFadden=signif(pscl::pR2(model5)["McFadden"],3),
          Deviance=signif(model5$deviance,3),AIC=signif(model5$aic,4))%>%
  add_row(Model="Model06",Predictors=nrow(m6)-1,
          McFadden=signif(pscl::pR2(model6)["McFadden"],3),
          Deviance=signif(model6$deviance,3),AIC=signif(model6$aic,4))%>%
  add_row(Model="Model07",Predictors=nrow(m7)-1,
          McFadden=signif(pscl::pR2(model7)["McFadden"],3),
          Deviance=signif(model7$deviance,3),AIC=signif(model7$aic,4))%>%
  add_row(Model="Model08",Predictors=nrow(m8)-1,
          McFadden=signif(pscl::pR2(model8)["McFadden"],3),
          Deviance=signif(model8$deviance,3),AIC=signif(model8$aic,4))%>%
  add_row(Model="Model09",Predictors=nrow(m9)-1,
          McFadden=signif(pscl::pR2(model9)["McFadden"],3),
          Deviance=signif(model9$deviance,3),AIC=signif(model9$aic,4))%>%
  add_row(Model="Model10",Predictors=nrow(m10)-1,
          McFadden=signif(pscl::pR2(model10)["McFadden"],3),
          Deviance=signif(model10$deviance,3),AIC=signif(model10$aic,4))%>%
  add_row(Model="Model11",Predictors=nrow(m11)-1,
          McFadden=signif(pscl::pR2(model11)["McFadden"],3),
          Deviance=signif(model11$deviance,3),AIC=signif(model11$aic,4))%>%
  add_row(Model="Model12",Predictors=nrow(m12)-1,
          McFadden=signif(pscl::pR2(model12)["McFadden"],3),
          Deviance=signif(model12$deviance,3),AIC=signif(model12$aic,4))%>%
  add_row(Model="Model13",Predictors=nrow(m13)-1,
          McFadden=signif(pscl::pR2(model13)["McFadden"],3),
          Deviance=signif(model13$deviance,3),AIC=signif(model13$aic,4))%>%
  add_row(Model="Model14",Predictors=nrow(m14)-1,
          McFadden=signif(pscl::pR2(model14)["McFadden"],3),
          Deviance=signif(model14$deviance,3),AIC=signif(model14$aic,4))%>%
  add_row(Model="Model15",Predictors=nrow(m15)-1,
          McFadden=signif(pscl::pR2(model15)["McFadden"],3),
          Deviance=signif(model15$deviance,3),AIC=signif(model15$aic,4))%>%
  add_row(Model="Model16",Predictors=nrow(m16)-1,
          McFadden=signif(pscl::pR2(model16)["McFadden"],3),
          Deviance=signif(model16$deviance,3),AIC=signif(model16$aic,4))%>%
  add_row(Model="Model17",Predictors=nrow(m17)-1,
          McFadden=signif(pscl::pR2(model17)["McFadden"],3),
          Deviance=signif(model17$deviance,3),AIC=signif(model17$aic,4))%>%
  add_row(Model="Model18",Predictors=nrow(m18)-1,
          McFadden=signif(pscl::pR2(model18)["McFadden"],3),
          Deviance=signif(model18$deviance,3),AIC=signif(model18$aic,4))%>%
  add_row(Model="Model19",Predictors=nrow(m19)-1,
          McFadden=signif(pscl::pR2(model19)["McFadden"],3),
          Deviance=signif(model19$deviance,3),AIC=signif(model19$aic,4))%>%
  add_row(Model="Model20",Predictors=nrow(m20)-1,
          McFadden=signif(pscl::pR2(model20)["McFadden"],3),
          Deviance=signif(model20$deviance,3),AIC=signif(model20$aic,4))%>%
  add_row(Model="Model21",Predictors=nrow(m21)-1,
          McFadden=signif(pscl::pR2(model21)["McFadden"],3),
          Deviance=signif(model21$deviance,3),AIC=signif(model21$aic,4))%>%
  add_row(Model="Model22",Predictors=nrow(m22)-1,
          McFadden=signif(pscl::pR2(model22)["McFadden"],3),
          Deviance=signif(model22$deviance,3),AIC=signif(model22$aic,4))%>%
  add_row(Model="Model23",Predictors=nrow(m23)-1,
          McFadden=signif(pscl::pR2(model23)["McFadden"],3),
          Deviance=signif(model23$deviance,3),AIC=signif(model23$aic,4))%>%
  add_row(Model="Model24",Predictors=nrow(m24)-1,
          McFadden=signif(pscl::pR2(model24)["McFadden"],3),
          Deviance=signif(model24$deviance,3),AIC=signif(model24$aic,4))%>%
  add_row(Model="Model25",Predictors=nrow(m25)-1,
          McFadden=signif(pscl::pR2(model25)["McFadden"],3),
          Deviance=signif(model25$deviance,3),AIC=signif(model25$aic,4))%>%
  add_row(Model="Model26",Predictors=nrow(m26)-1,
        McFadden=signif(pscl::pR2(model26)["McFadden"],3),
        Deviance=signif(model26$deviance,3),AIC=signif(model26$aic,4))%>%
  add_row(Model="Model27",Predictors=nrow(m27)-1,
          McFadden=signif(pscl::pR2(model27)["McFadden"],3),
          Deviance=signif(model27$deviance,3),AIC=signif(model27$aic,4))

#write.csv(model_coefs, file = "coefficients.csv",row.names=FALSE)
#write.csv(model_odds, file = "odds.csv",row.names=FALSE)
#write.csv(model_p, file = "pvalues.csv",row.names=FALSE)
#write.csv(model_fit, file = "fit.csv",row.names=FALSE)
#write.csv(models, file = "models.csv",row.names=FALSE)

#Plots of one=predictor sigmoid functions------------------------------------
months<-data.frame(MonthsBehind=seq(0,15,.1))
plot1<-ggplot()+
  geom_line(data=months,aes(x=MonthsBehind,y=predict(model2,months,type="response")))+
  geom_point(data=mec,aes(MonthsBehind, as.numeric(as.character(Judgement)),
                          color=Judgement),alpha=.15)+
  labs(title="Logistic Regression Model Fit: Months Behind", 
       y="Probability of Eviction Judgement",
       subtitle=bquote(P==1/1+e^-(.(round(model2$coefficients[1],3))+
                                    .(round(model2$coefficients[2],3),3)~"(Months Behind)")),
       caption=bquote("McFadden="~.(signif(pscl::pR2(model2)["McFadden"],3))
                       ~",Deviance="~.(signif(model2$deviance,3))
                       ~",AIC="~.(signif(model2$aic,3))
                       ))

c<-data.frame(Children.yes=seq(0,1,.05))
ggplot()+
  geom_line(data=c,aes(x=Children.yes,y=predict(model1,c,type="response")))+
  geom_jitter(data=mec,aes(Children.yes, as.numeric(as.character(Judgement)),color=Judgement),
              width = 0.08, height = 0.08,alpha=.25)+
  labs(title="Logistic Regression Model Fit: Children",
       y="Probability of Eviction Judgement")

plot2<-ggplot()+
  geom_line(data=c,aes(x=Children.yes,y=predict(model1,c,type="response")))+
  geom_count(data=mec,aes(Children.yes, as.numeric(as.character(Judgement)),color=Judgement))+
  labs(title="Logistic Regression Model Fit: Children",
       y="Probability of Eviction Judgement",
       subtitle=bquote(P==1/1+e^-(.(round(model1$coefficients[1],3))+
                                    .(round(model1$coefficients[2],3),3)~"(Children)")),
       caption=bquote("McFadden="~.(signif(pscl::pR2(model1)["McFadden"],3))
                       ~",Deviance="~.(signif(model1$deviance,3))
                       ~",AIC="~.(signif(model1$aic,3))
       ))


ggplot()+
  geom_line(data=c,aes(x=Children.yes,y=predict(model1,c,type="response")))+
  geom_jitter(data=mec,aes(Children.yes, as.numeric(as.character(Judgement)),color=Judgement),
              width = 0.08, height = 0.08,alpha=.25)+
  labs(title="Logistic Regression Model Fit: Children",
       y="Probability of Eviction Judgement")

g<-data.frame(Gender.male=seq(0,1,.05))
plot3<-ggplot()+
  geom_line(data=g,aes(x=Gender.male,y=predict(model17,g,type="response")))+
  geom_count(data=mec,aes(Gender.male, as.numeric(as.character(Judgement)),color=Judgement))+
  labs(title="Logistic Regression Model Fit: Gender",
       y="Probability of Eviction Judgement",
       subtitle=bquote(P==1/1+e^-(.(round(model7$coefficients[1],3))+
                                    .(round(model7$coefficients[2],3),3)~"(male)")),
       caption=bquote("McFadden="~.(signif(pscl::pR2(model7)["McFadden"],3))
                       ~",Deviance="~.(signif(model7$deviance,3))
                       ~",AIC="~.(signif(model7$aic,3))
       ))

grid.arrange(plot1,plot2,plot3,nrow=1)

#Confidence Intervals for coefficients------------------------------------------------------------------
#Outliers & residuals----------------------------------------------
#Model 13
confint(model13)
#plot(mode26, which = 1:6, id.n = 5)
model13_data <- augment(model13) %>% 
  mutate(index = 1:n())
hist(model13$residuals)
hist(model13_data$.std.resid)
ggplot(model13_data, aes(index, .std.resid, color = Judgement)) + 
  geom_point(alpha = .5)+
  labs(title="Model 13 Standard Residuals")
plot(model7, which =4 , id.n = 5, main="Model 13 Influential Records")
m13_top5<-model13_data %>% 
  top_n(5, .cooksd)


#Model 18
#plot(mode26, which = 1:6, id.n = 5)
confint(model18)
model18_data <- augment(model18) %>% 
  mutate(index = 1:n())
hist(model18$residuals)
hist(model18_data$.std.resid)
ggplot(model18_data, aes(index, .std.resid, color = Judgement)) + 
  geom_point(alpha = .5)+
  labs(title="Model 18 Standard Residuals")
plot(model18, which =4 , id.n = 5, main="Model 18 Influential Records")
m18_top5<-model18_data %>% 
  top_n(5, .cooksd)

ggplot(mec)+
  geom_bar(aes(x=OwedPerIncomeBin,fill=as.factor(Rooms)))+
  facet_wrap(~Gender,nrow=2)

#Model 20
#plot(mode26, which = 1:6, id.n = 5)
confint(model20)
model20_data <- augment(model20) %>% 
  mutate(index = 1:n())
hist(model20$residuals)
hist(model20_data$.std.resid)
ggplot(model20_data, aes(index, .std.resid, color = Judgement)) + 
  geom_point(alpha = .5)+
  labs(title="Model 20 Standard Residuals")
plot(model20, which =4 , id.n = 5, main="Model 20 Influential Records")
m20_top5<-model20_data %>% 
  top_n(5, .cooksd)


#Model 27
#plot(mode26, which = 1:6, id.n = 5)
confint(model27)
model27_data <- augment(model27) %>% 
  mutate(index = 1:n())
hist(model27$residuals)
hist(model27_data$.std.resid)
ggplot(model27_data, aes(index, .std.resid, color = Judgement)) + 
  geom_point(alpha = .5)+
  labs(title="Model 27 Standard Residuals")
plot(model27, which =4 , id.n = 5, main="Model 27 Influential Records")
m27_top5<-model27_data %>% 
  top_n(5, .cooksd)

#write.csv(m13_top5, file = "m13_top5.csv",row.names=FALSE)
#write.csv(m18_top5, file = "m18_top5.csv",row.names=FALSE)
#write.csv(m20_top5, file = "m20_top5.csv",row.names=FALSE)
#write.csv(m27_top5, file = "m27_top5.csv",row.names=FALSE)

#model validation & Evaluation---------------------------------------------------------------------------
#predictions on validation data-----------------
valid1=predict(model1, validation, type = "response")
valid2=predict(model2, validation, type = "response")
valid3=predict(model3, validation, type = "response")
valid4=predict(model4, validation, type = "response")
valid5=predict(model5, validation, type = "response")
valid6=predict(model6, validation, type = "response")
valid7=predict(model7, validation, type = "response")
valid8=predict(model8, validation, type = "response")
valid9=predict(model9, validation, type = "response")
valid10=predict(model10, validation, type = "response")
valid11=predict(model11, validation, type = "response")
valid12=predict(model12, validation, type = "response")
valid13=predict(model13, validation, type = "response")
valid14=predict(model14, validation, type = "response")
valid15=predict(model15, validation, type = "response")
valid16=predict(model16, validation, type = "response")
valid17=predict(model17, validation, type = "response")
valid18=predict(model18, validation, type = "response")
valid19=predict(model19, validation, type = "response")
valid20=predict(model20, validation, type = "response")
valid21=predict(model21, validation, type = "response")
valid22=predict(model22, validation, type = "response")
valid23=predict(model23, validation, type = "response")
valid24=predict(model24, validation, type = "response")
valid25=predict(model25, validation, type = "response")
valid26=predict(model26, validation, type = "response")
valid27=predict(model27, validation, type = "response")
        
#Warnings: Model (5,7,12,15,17) prediction from a rank-deficient fit may be misleading


#MAE, RSME, RMSE/mean on validation set-----------------------------------------------------------------------
performance<-tibble(Model="Model 01",
                    MAE=MAE(valid1, as.numeric(as.character(validation$Judgement))),
                    RMSE=RMSE(valid1, as.numeric(as.character(validation$Judgement))),
                    NRMSE=RMSE(valid1, as.numeric(as.character(validation$Judgement)))/mean(as.numeric(as.character(validation$Judgement)))
                    )
performance<-performance%>%
  add_row(Model="Model 02",
          MAE=MAE(valid2, as.numeric(as.character(validation$Judgement))),
          RMSE=RMSE(valid2, as.numeric(as.character(validation$Judgement))),
          NRMSE=RMSE(valid2, as.numeric(as.character(validation$Judgement)))/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 03",
          MAE=MAE(valid3, as.numeric(as.character(validation$Judgement))),
          RMSE=RMSE(valid3, as.numeric(as.character(validation$Judgement))),
          NRMSE=RMSE(valid3, as.numeric(as.character(validation$Judgement)))/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 04",
          MAE=MAE(valid4, as.numeric(as.character(validation$Judgement))),
          RMSE=RMSE(valid4, as.numeric(as.character(validation$Judgement))),
          NRMSE=RMSE(valid4, as.numeric(as.character(validation$Judgement)))/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 05",
          MAE=MAE(valid5, as.numeric(as.character(validation$Judgement))),
          RMSE=RMSE(valid5, as.numeric(as.character(validation$Judgement))),
          NRMSE=RMSE(valid5, as.numeric(as.character(validation$Judgement)))/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 06",
          MAE=MAE(valid6, as.numeric(as.character(validation$Judgement))),
          RMSE=RMSE(valid6, as.numeric(as.character(validation$Judgement))),
          NRMSE=RMSE(valid6, as.numeric(as.character(validation$Judgement)))/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 07",
          MAE=MAE(valid7, as.numeric(as.character(validation$Judgement))),
          RMSE=RMSE(valid7, as.numeric(as.character(validation$Judgement))),
          NRMSE=RMSE(valid7, as.numeric(as.character(validation$Judgement)))/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 08",
          MAE=MAE(valid8, as.numeric(as.character(validation$Judgement))),
          RMSE=RMSE(valid8, as.numeric(as.character(validation$Judgement))),
          NRMSE=RMSE(valid8, as.numeric(as.character(validation$Judgement)))/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 09",
          MAE=MAE(valid9, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid9, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid9, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 10",
          MAE=MAE(valid10, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid10, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid10, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 11",
          MAE=MAE(valid11, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid11, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid11, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 12",
          MAE=MAE(valid12, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid12, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid12, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 13",
          MAE=MAE(valid13, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid13, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid13, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )       
performance<-performance%>%
  add_row(Model="Model 14",
          MAE=MAE(valid14, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid14, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid14, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  ) 
performance<-performance%>%
  add_row(Model="Model 15",
          MAE=MAE(valid15, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid15, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid15, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 16",
          MAE=MAE(valid16, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid16, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid16, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 17",
          MAE=MAE(valid17, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid17, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid17, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 18",
          MAE=MAE(valid18, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid18, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid18, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 19",
          MAE=MAE(valid19, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid19, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid19, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 20",
          MAE=MAE(valid20, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid20, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid20, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 21",
          MAE=MAE(valid21, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid21, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid21, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 22",
          MAE=MAE(valid22, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid22, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid22, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 23",
          MAE=MAE(valid23, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid23, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid23, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 24",
          MAE=MAE(valid24, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid24, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid24, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 25",
          MAE=MAE(valid25, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid25, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid25, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 26",
          MAE=MAE(valid26, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid26, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid26, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )
performance<-performance%>%
  add_row(Model="Model 27",
          MAE=MAE(valid27, as.numeric(as.character(validation$Judgement)),na.rm=T),
          RMSE=RMSE(valid27, as.numeric(as.character(validation$Judgement)),na.rm=T),
          NRMSE=RMSE(valid27, as.numeric(as.character(validation$Judgement)),na.rm=T)/mean(as.numeric(as.character(validation$Judgement)))
  )


#write.csv(performance, file = "perf_valid.csv",row.names=FALSE)


#AUC, PRAUC, confusion matrix for best one(s)-------------------------------------------------------------------
cutoff<-0.5

library(pROC)
citation("pROC")

roc_colors<-rainbow(10)
l<-c("Model 4","Model 7","Model 11","Model 13","Model 14","Model 18","Model 20","Model 25","Model 26","Model 27")

v4<-ifelse(valid4<cutoff,0,1)
v4_mat<-confusionMatrix(as.factor(v4), validation$Judgement,positive="1")
roc04<-roc(validation$Judgement,factor(valid4,ordered=T))
plot(roc04,print.auc=T,print.thres = T,legacy.axes=TRUE,main="ROC",col=roc_colors[1])
legend("topleft",legend=l,col=roc_colors,lty=1)

v7<-ifelse(valid7<cutoff,0,1)
v7_mat<-confusionMatrix(as.factor(v7), validation$Judgement,positive="1")
roc07<-roc(validation$Judgement,factor(valid7,ordered=T))
plot(roc07,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[2])

v11<-ifelse(valid11<cutoff,0,1)
v11_mat<-confusionMatrix(as.factor(v11), validation$Judgement,positive="1")
roc11<-roc(validation$Judgement,factor(valid11,ordered=T))
plot(roc11,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[3])

v13<-ifelse(valid13<cutoff,0,1)
v13_mat<-confusionMatrix(as.factor(v13), validation$Judgement,positive="1")
roc13<-roc(validation$Judgement,factor(valid13,ordered=T))
plot(roc13,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[4])

v14<-ifelse(valid14<cutoff,0,1)
v14_mat<-confusionMatrix(as.factor(v14), validation$Judgement,positive="1")
roc14<-roc(validation$Judgement,factor(valid14,ordered=T))
plot(roc14,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[5])

v18<-ifelse(valid18<cutoff,0,1)
v18_mat<-confusionMatrix(as.factor(v18), validation$Judgement,positive="1")
roc18<-roc(validation$Judgement,factor(valid18,ordered=T))
plot(roc18,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[6])


v20<-ifelse(valid20<cutoff,0,1)
v20_mat<-confusionMatrix(as.factor(v20), validation$Judgement,positive="1")
roc20<-roc(validation$Judgement,factor(valid20,ordered=T))
plot(roc20,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[7])

v25<-ifelse(valid25<cutoff,0,1)
v25_mat<-confusionMatrix(as.factor(v25), validation$Judgement,positive="1")
roc25<-roc(validation$Judgement,factor(valid25,ordered=T))
plot(roc25,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[8])

v26<-ifelse(valid26<cutoff,0,1)
v26_mat<-confusionMatrix(as.factor(v26), validation$Judgement,positive="1")
roc26<-roc(validation$Judgement,factor(valid26,ordered=T))
plot(roc26,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[9])

v27<-ifelse(valid27<cutoff,0,1)
v27_mat<-confusionMatrix(as.factor(v27), validation$Judgement,positive="1")
roc27<-roc(validation$Judgement,factor(valid27,ordered=T))
plot(roc27,print.auc=T,print.thres = T,legacy.axes=TRUE,add=T,col=roc_colors[10])

#Overall most interesting?  13,18,20,27?

#Precision-Recall-------------------------------------------------------------------------

library(PRROC)
citation("PRROC")
df.4<-data.frame(prob=valid4,act=validation$Judgement)
pr4<-pr.curve(scores.class0=na.omit(df.4[df.4$act==1,"prob"]),scores.class1=na.omit(df.4[df.4$act==0,"prob"]),curve=T)
r4<-roc.curve(scores.class0=na.omit(df.4[df.4$act==1,"prob"]),scores.class1=na.omit(df.4[df.4$act==0,"prob"]),curve=T)
df.7<-data.frame(prob=valid7,act=validation$Judgement)
pr7<-pr.curve(scores.class0=na.omit(df.7[df.7$act==1,"prob"]),scores.class1=na.omit(df.7[df.7$act==0,"prob"]),curve=T)
r7<-roc.curve(scores.class0=na.omit(df.7[df.7$act==1,"prob"]),scores.class1=na.omit(df.7[df.7$act==0,"prob"]),curve=T)
df.11<-data.frame(prob=valid11,act=validation$Judgement)
pr11<-pr.curve(scores.class0=na.omit(df.11[df.11$act==1,"prob"]),scores.class1=na.omit(df.11[df.11$act==0,"prob"]),curve=T)
r11<-roc.curve(scores.class0=na.omit(df.11[df.11$act==1,"prob"]),scores.class1=na.omit(df.11[df.11$act==0,"prob"]),curve=T)
df.14<-data.frame(prob=valid14,act=validation$Judgement)
pr14<-pr.curve(scores.class0=na.omit(df.14[df.14$act==1,"prob"]),scores.class1=na.omit(df.14[df.14$act==0,"prob"]),curve=T)
r14<-roc.curve(scores.class0=na.omit(df.14[df.14$act==1,"prob"]),scores.class1=na.omit(df.14[df.14$act==0,"prob"]),curve=T)
df.25<-data.frame(prob=valid25,act=validation$Judgement)
pr25<-pr.curve(scores.class0=na.omit(df.25[df.25$act==1,"prob"]),scores.class1=na.omit(df.25[df.25$act==0,"prob"]),curve=T)
r25<-roc.curve(scores.class0=na.omit(df.25[df.25$act==1,"prob"]),scores.class1=na.omit(df.25[df.25$act==0,"prob"]),curve=T)
df.26<-data.frame(prob=valid26,act=validation$Judgement)
pr26<-pr.curve(scores.class0=na.omit(df.26[df.26$act==1,"prob"]),scores.class1=na.omit(df.26[df.26$act==0,"prob"]),curve=T)
r26<-roc.curve(scores.class0=na.omit(df.26[df.26$act==1,"prob"]),scores.class1=na.omit(df.26[df.26$act==0,"prob"]),curve=T)

df.13<-data.frame(prob=valid13,act=validation$Judgement)
r13<-roc.curve(scores.class0=na.omit(df.13[df.13$act==1,"prob"]),scores.class1=na.omit(df.13[df.13$act==0,"prob"]),curve=T)
plot(r13,main="Model 13 ROC Curve")
pr13<-pr.curve(scores.class0=na.omit(df.13[df.13$act==1,"prob"]),scores.class1=na.omit(df.13[df.13$act==0,"prob"]),curve=T)
plot(pr13,main="Model 13 PR Curve")

df.18<-data.frame(prob=valid18,act=validation$Judgement)
r18<-roc.curve(scores.class0=na.omit(df.18[df.18$act==1,"prob"]),scores.class1=na.omit(df.18[df.18$act==0,"prob"]),curve=T)
plot(r18,main="Model 18 ROC Curve")
pr18<-pr.curve(scores.class0=na.omit(df.18[df.18$act==1,"prob"]),scores.class1=na.omit(df.18[df.18$act==0,"prob"]),curve=T)
plot(pr18,main="Model 18 PR Curve")

df.20<-data.frame(prob=valid20,act=validation$Judgement)
r20<-roc.curve(scores.class0=na.omit(df.20[df.20$act==1,"prob"]),scores.class1=na.omit(df.20[df.20$act==0,"prob"]),curve=T)
plot(r20,main="Model 20 ROC Curve")
pr20<-pr.curve(scores.class0=na.omit(df.20[df.20$act==1,"prob"]),scores.class1=na.omit(df.20[df.20$act==0,"prob"]),curve=T)
plot(pr20,main="Model 20 PR Curve")

df.27<-data.frame(prob=valid27,act=validation$Judgement)
r27<-roc.curve(scores.class0=na.omit(df.27[df.27$act==1,"prob"]),scores.class1=na.omit(df.27[df.27$act==0,"prob"]),curve=T)
plot(r27,main="Model 27 ROC Curve")
pr27<-pr.curve(scores.class0=na.omit(df.27[df.27$act==1,"prob"]),scores.class1=na.omit(df.27[df.27$act==0,"prob"]),curve=T)
plot(pr27,main="Model 27 PR Curve")

pr_table<-tibble(Model="Model 04",Recall=pr4$curve[, 1],Precision=pr4$curve[, 2])
pr_table<-pr_table%>%
  add_row(Model="Model 07",Recall=pr7$curve[, 1],Precision=pr7$curve[, 2])%>%
  add_row(Model="Model 11",Recall=pr11$curve[, 1],Precision=pr11$curve[, 2])%>%
  add_row(Model="Model 13",Recall=pr13$curve[, 1],Precision=pr13$curve[, 2])%>%
  add_row(Model="Model 14",Recall=pr14$curve[, 1],Precision=pr14$curve[, 2])%>%
  add_row(Model="Model 18",Recall=pr18$curve[, 1],Precision=pr18$curve[, 2])%>%
  add_row(Model="Model 20",Recall=pr20$curve[, 1],Precision=pr20$curve[, 2])%>%
  add_row(Model="Model 26",Recall=pr26$curve[, 1],Precision=pr26$curve[, 2])%>%
  add_row(Model="Model 27",Recall=pr27$curve[, 1],Precision=pr27$curve[, 2])


#(Model="Model 13",Recall=pr13$curve[, 1],Precision=pr13$curve[, 2])
#FPR=1-roc13$specificities,TPR=roc13$sensitivities)
ggplot(pr_table)+
  geom_line(aes(x=Recall,y=Precision,group=Model,color=Model))+
  labs(title="Precision-Recall")

r_table<-tibble(Model="Model04",FPR=r4$curve[, 1],Sensitivity=r4$curve[, 2])
r_table<-r_table%>%
  add_row(Model="Model07",FPR=r7$curve[, 1],Sensitivity=r7$curve[, 2])%>%
  add_row(Model="Model11",FPR=r11$curve[, 1],Sensitivity=r11$curve[, 2])%>%
  add_row(Model="Model13",FPR=r13$curve[, 1],Sensitivity=r13$curve[, 2])%>%
  add_row(Model="Model14",FPR=r14$curve[, 1],Sensitivity=r14$curve[, 2])%>%
  add_row(Model="Model18",FPR=r18$curve[, 1],Sensitivity=r18$curve[, 2])%>%
  add_row(Model="Model20",FPR=r20$curve[, 1],Sensitivity=r20$curve[, 2])%>%
  add_row(Model="Model25",FPR=r25$curve[, 1],Sensitivity=r25$curve[, 2])%>%
  add_row(Model="Model26",FPR=r26$curve[, 1],Sensitivity=r26$curve[, 2])%>%
  add_row(Model="Model27",FPR=r27$curve[, 1],Sensitivity=r27$curve[, 2])
    
    
ggplot(r_table)+
  geom_line(aes(x=FPR,y=Sensitivity,group=Model,color=Model))+
  labs(title="ROC")

mod04<-c("Model04",round(v4_mat$overall[1],4),round(v4_mat$byClass[1],4),round(v4_mat$byClass[2],4)
         ,round(v4_mat$byClass[5],4),round(roc04$auc,4),round(pr4$auc.integral,4))
mod07<-c("Model07",round(v7_mat$overall[1],4),round(v7_mat$byClass[1],4),round(v7_mat$byClass[2],4)
         ,round(v7_mat$byClass[5],4),round(roc07$auc,4),round(pr7$auc.integral,4))
mod11<-c("Model11",round(v11_mat$overall[1],4),round(v11_mat$byClass[1],4),round(v11_mat$byClass[2],4)
         ,round(v11_mat$byClass[5],4),round(roc11$auc,4),round(pr11$auc.integral,4))
mod13<-c("Model13",round(v13_mat$overall[1],4),round(v13_mat$byClass[1],4),round(v13_mat$byClass[2],4)
         ,round(v13_mat$byClass[5],4),round(roc13$auc,4),round(pr13$auc.integral,4))
mod14<-c("Model14",round(v14_mat$overall[1],4),round(v14_mat$byClass[1],4),round(v14_mat$byClass[2],4)
         ,round(v14_mat$byClass[5],4),round(roc14$auc,4),round(pr14$auc.integral,4))
mod18<-c("Model18",round(v18_mat$overall[1],4),round(v18_mat$byClass[1],4),round(v18_mat$byClass[2],4)
         ,round(v18_mat$byClass[5],4),round(roc18$auc,4),round(pr18$auc.integral,4))
mod20<-c("Model20",round(v20_mat$overall[1],4),round(v20_mat$byClass[1],4),round(v20_mat$byClass[2],4)
         ,round(v20_mat$byClass[5],4),round(roc20$auc,4),round(pr20$auc.integral,4))
mod25<-c("Model25",round(v25_mat$overall[1],4),round(v25_mat$byClass[1],4),round(v25_mat$byClass[2],4)
         ,round(v25_mat$byClass[5],4),round(roc25$auc,4),round(pr25$auc.integral,4))
mod26<-c("Model26",round(v26_mat$overall[1],4),round(v26_mat$byClass[1],4),round(v26_mat$byClass[2],4)
         ,round(v26_mat$byClass[5],4),round(roc26$auc,4),round(pr26$auc.integral,4))
mod27<-c("Model27",round(v27_mat$overall[1],4),round(v27_mat$byClass[1],4),round(v27_mat$byClass[2],4)
         ,round(v27_mat$byClass[5],4),round(roc27$auc,4),round(pr27$auc.integral,4))


eval<-data.frame(
  Model=character(),
  Accuracy=numeric(),
  Sensitivity=numeric(),  #Sensitivity = Recall
  Specificity=numeric(),
  Precision=numeric(),
  ROC_AUC=numeric(),
  PR_AUC=numeric(),
  stringsAsFactors = F)

eval[nrow(eval)+1,]<-mod04
eval<-rbind(eval,mod07)
eval<-rbind(eval,mod11)
eval<-rbind(eval,mod13)
eval<-rbind(eval,mod14)
eval<-rbind(eval,mod18)
eval<-rbind(eval,mod20)
eval<-rbind(eval,mod25)
eval<-rbind(eval,mod26)
eval<-rbind(eval,mod27)

#write.csv(eval, file = "valid_eval.csv",row.names=FALSE)
#cross-validation--------------------------------------------------------------------------
#Original MOdels
#13: Judgement ~ MonthsBehind+OwedPerIncome+IncomePerRes
#18:Judgement ~ Gender.male+Rooms+OwedPerIncomeBin
#20:Judgement ~ Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind
#27:Judgement ~ Children.yes+MonthsBehind+Gender.male
#metric=Accuracy
#LOO
## Define training control
train.control <- trainControl(method = "LOOCV")
## Train the model
model13A <- train(Judgement~MonthsBehind+OwedPerIncome+IncomePerRes, data = (rbind(train[train$Income!=0,],validation[validation$Income!=0,])),
                  method = "glm", trControl = train.control,na.action=na.omit)
model18A <- train(Judgement~Gender.male+Rooms+OwedPerIncomeBin, data = rbind(train,validation),
                 method = "glm", trControl = train.control,na.action=na.omit)
model20A <- train(Judgement~Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, data = rbind(train,validation),
                  method = "glm", trControl = train.control,na.action=na.omit)
model27A <- train(Judgement~Children.yes+MonthsBehind+Gender.male, data = rbind(train,validation),
                  method = "glm", trControl = train.control,na.action=na.omit)
#k-fold
set.seed(123)
train.control <- trainControl(method = "cv", number = 10)
model13B <- train(Judgement~MonthsBehind+OwedPerIncome+IncomePerRes, data = (rbind(train[train$Income!=0,],validation[validation$Income!=0,])),
                  method = "glm", trControl = train.control,na.action=na.omit)
model18B <- train(Judgement~Gender.male+Rooms+OwedPerIncomeBin, data = rbind(train,validation),
                  method = "glm", trControl = train.control,na.action=na.omit)
model20B <- train(Judgement~Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, data = rbind(train,validation),
                  method = "glm", trControl = train.control,na.action=na.omit)
model27B <- train(Judgement~Children.yes+MonthsBehind+Gender.male, data = rbind(train,validation),
                  method = "glm", trControl = train.control,na.action=na.omit)
#Repeated k-fold
set.seed(123)
train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3)
model13C <- train(Judgement~MonthsBehind+OwedPerIncome+IncomePerRes, data = (rbind(train[train$Income!=0,],validation[validation$Income!=0,])),
                  method = "glm", trControl = train.control,na.action=na.omit)
model18C <- train(Judgement~Gender.male+Rooms+OwedPerIncomeBin, data = rbind(train,validation),
                  method = "glm", trControl = train.control,na.action=na.omit)
model20C <- train(Judgement~Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, data = rbind(train,validation),
                  method = "glm", trControl = train.control,na.action=na.omit)
model27C <- train(Judgement~Children.yes+MonthsBehind+Gender.male, data = rbind(train,validation),
                  method = "glm", trControl = train.control,na.action=na.omit)

m13a<- data.frame(estimate=coef(model13A$finalModel),Model="Model13A")%>%rownames_to_column("term")
m13b<- data.frame(estimate=coef(model13B$finalModel),Model="Model13B")%>%rownames_to_column("term")
m13c<- data.frame(estimate=coef(model13C$finalModel),Model="Model13C")%>%rownames_to_column("term")

m18a<- data.frame(estimate=coef(model18A$finalModel),Model="Model18A")%>%rownames_to_column("term")
m18b<- data.frame(estimate=coef(model18B$finalModel),Model="Model18B")%>%rownames_to_column("term")
m18c<- data.frame(estimate=coef(model18C$finalModel),Model="Model18C")%>%rownames_to_column("term")

m20a<- data.frame(estimate=coef(model20A$finalModel),Model="Model20A")%>%rownames_to_column("term")
m20b<- data.frame(estimate=coef(model20B$finalModel),Model="Model20B")%>%rownames_to_column("term")
m20c<- data.frame(estimate=coef(model20C$finalModel),Model="Model20C")%>%rownames_to_column("term")

m27a<- data.frame(estimate=coef(model27A$finalModel),Model="Model27A")%>%rownames_to_column("term")
m27b<- data.frame(estimate=coef(model27B$finalModel),Model="Model27B")%>%rownames_to_column("term")
m27c<- data.frame(estimate=coef(model27C$finalModel),Model="Model27C")%>%rownames_to_column("term")

cv_models<-rbind(select(m13,term,estimate,Model),m13a,m13b,m13c,
                 select(m18,term,estimate,Model),m18a,m18b,m18c,
                 select(m20,term,estimate,Model),m20a,m20b,m20c,
                 select(m27,term,estimate,Model),m27a,m27b,m27c)
cv_models$term<-gsub("`","",cv_models$term)
cv_coefs<-cv_models%>%
  dplyr::select(term,estimate,Model)%>%
  pivot_wider(names_from=Model,values_from = c(estimate))
cv_odds<-cv_models%>%
  mutate(odds=exp(estimate))%>%
  dplyr::select(term,odds,Model)%>%
  pivot_wider(names_from=Model,values_from = c(odds))
#write.csv(cv_coefs, file = "cv_coefficients.csv",row.names=FALSE)
#write.csv(cv_odds, file = "cv_odds.csv",row.names=FALSE)

#class imbalances-------------------------------------------------------------------------
library(DMwR) # for smote implementation
citation("DMwR")
ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = twoClassSummary,
                     classProbs = TRUE)
train$Outcome<-factor(ifelse(train$Judgement == "1","evicted","no"),levels=c("no","evicted"))
validation$Outcome<-factor(ifelse(validation$Judgement == "1","evicted","no"),levels=c("no","evicted"))
test$Outcome<-factor(ifelse(test$Judgement == "1","evicted","no"),levels=c("no","evicted"))
tv<-rbind(train,validation)
set.seed(1234)
##Handling class imbalance with weighted or sampling methods
# Create model weights (they sum to one)
model_weights <- ifelse(tv$Judgement == "0",
                        (1/table(tv$Judgement)[1]) * 0.5,
                        (1/table(tv$Judgement)[2]) * 0.5)
#Model 13---------------------------------------------------------------------
orig_13 <- train(Outcome~MonthsBehind+OwedPerIncome+IncomePerRes, 
                 data = (tv[tv$Income!=0,]),
                 method = "glm", family="binomial",
                 metric = "ROC", trControl = ctrl,na.action=na.omit)
# Use the same seed to ensure same cross-validation splits
ctrl$seeds <- orig_13$control$seeds
# Create model weights (they sum to one)
model_weights <- ifelse(tv[tv$Income!=0,Judgement] == "0",
                        (1/table(tv[tv$Income!=0,Judgement])[1]) * 0.5,
                        (1/table(tv[tv$Income!=0,Judgement])[2]) * 0.5)
# Build weighted model
weighted_13 <- train(Outcome~MonthsBehind+OwedPerIncome+IncomePerRes, 
                     data = (tv[tv$Income!=0,]),
                     method = "glm", family="binomial",
                     metric = "ROC", trControl = ctrl,na.action=na.omit,
                     weights = model_weights)
# Build down-sampled model
ctrl$sampling <- "down"
down_13 <- train(Outcome~MonthsBehind+OwedPerIncome+IncomePerRes, 
                 data = (tv[tv$Income!=0,]),
                 method = "glm", family="binomial",
                 metric = "ROC", trControl = ctrl,na.action=na.omit)
# Build up-sampled model
ctrl$sampling <- "up"
up_13 <- train(Outcome~MonthsBehind+OwedPerIncome+IncomePerRes, 
               data = (tv[tv$Income!=0,]),
               method = "glm", family="binomial",
               metric = "ROC", trControl = ctrl,na.action=na.omit)
# Build smote model
ctrl$sampling <- "smote"
smote_13 <- train(Outcome~MonthsBehind+OwedPerIncome+IncomePerRes, 
                  data = (tv[tv$Income!=0,]),
                  method = "glm", family="binomial",
                  metric = "ROC", trControl = ctrl,na.action=na.omit)



#Model 18---------------------------------------------------------------------
orig_18 <- train(Outcome~ Gender.male+Rooms+OwedPerIncomeBin,
                 data = tv, method = "glm", family="binomial",
                 metric = "ROC", trControl = ctrl,na.action=na.omit)
# Use the same seed to ensure same cross-validation splits
ctrl$seeds <- orig_18$control$seeds
model_weights <- ifelse(tv[!is.na(tv$OwedPerIncomeBin),Judgement] == "0",
                        (1/table(tv[!is.na(tv$OwedPerIncomeBin),Judgement])[1]) * 0.5,
                        (1/table(tv[!is.na(tv$OwedPerIncomeBin),Judgement])[2]) * 0.5)
# Build weighted model
ctrl$sampling <- NULL
weighted_18 <- train(Outcome~ Gender.male+Rooms+OwedPerIncomeBin,
                     data = tv[!is.na(tv$OwedPerIncomeBin),], method = "glm", family="binomial",
                     metric = "ROC", trControl = ctrl,na.action=na.omit,
                     weights = model_weights)
# Build down-sampled model
ctrl$sampling <- "down"
down_18 <- train(Outcome~ Gender.male+Rooms+OwedPerIncomeBin,
                 data = tv, method = "glm", family="binomial",
                 metric = "ROC", trControl = ctrl,na.action=na.omit)
# Build up-sampled model
ctrl$sampling <- "up"
up_18 <- train(Outcome~ Gender.male+Rooms+OwedPerIncomeBin,
               data = tv, method = "glm", family="binomial",
               metric = "ROC", trControl = ctrl,na.action=na.omit)
# Build smote model
ctrl$sampling <- "smote"
smote_18 <- train(Outcome~ Gender.male+Rooms+OwedPerIncomeBin,
                  data = tv, method = "glm", family="binomial",
                  metric = "ROC", trControl = ctrl,na.action=na.omit)
#Model 20---------------------------------------------------------------------
orig_20 <- train(Outcome~ Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, 
                 data = tv, method = "glm", family="binomial",
                 metric = "ROC", trControl = ctrl,na.action=na.omit)
# Use the same seed to ensure same cross-validation splits
ctrl$seeds <- orig_20$control$seeds
model_weights <- ifelse(tv[!is.na(tv$MonthsBehind),Judgement] == "0",
                        (1/table(tv[!is.na(tv$MonthsBehind),Judgement])[1]) * 0.5,
                        (1/table(tv[!is.na(tv$MonthsBehind),Judgement])[2]) * 0.5)
# Build weighted model
ctrl$sampling <- NULL
weighted_20 <- train(Outcome~ Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, 
                     data = tv[!is.na(tv$MonthsBehind),], method = "glm", family="binomial",
                     metric = "ROC", trControl = ctrl,na.action=na.omit,
                     weights = model_weights)
# Build down-sampled model
ctrl$sampling <- "down"
down_20 <- train(Outcome~ Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, 
                 data = tv[!is.na(tv$MonthsBehind),], method = "glm", family="binomial",
                 metric = "ROC", trControl = ctrl,na.action=na.omit)
# Build up-sampled model
ctrl$sampling <- "up"
up_20 <- train(Outcome~ Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, 
               data = tv[!is.na(tv$MonthsBehind),], method = "glm", family="binomial",
               metric = "ROC", trControl = ctrl,na.action=na.omit)
# Build smote model
ctrl$sampling <- "smote"
smote_20 <- train(Outcome~ Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, 
                  data = tv[!is.na(tv$MonthsBehind),], method = "glm", family="binomial",
                  metric = "ROC", trControl = ctrl,na.action=na.omit)



#Model 27---------------------------------------------------------------------
orig_27 <- train(Outcome~Children.yes+MonthsBehind+Gender.male, data = tv,
                  method = "glm",na.action=na.omit,trControl=ctrl,metric="ROC")

# Use the same seed to ensure same cross-validation splits
ctrl$seeds <- orig_27$control$seeds
model_weights <- ifelse(tv[!is.na(tv$MonthsBehind),Judgement] == "0",
                        (1/table(tv[!is.na(tv$MonthsBehind),Judgement])[1]) * 0.5,
                        (1/table(tv[!is.na(tv$MonthsBehind),Judgement])[2]) * 0.5)
# Build weighted model
ctrl$sampling<-NULL
weighted_27 <- train(Outcome~Children.yes+MonthsBehind+Gender.male,
                     data = tv[!is.na(tv$MonthsBehind),], method = "glm", family="binomial",
                     metric = "ROC", trControl = ctrl,na.action=na.omit,
                     weights = model_weights)
# Build down-sampled model
ctrl$sampling <- "down"
down_27 <- train(Outcome~ Children.yes+MonthsBehind+Gender.male,
                 data = tv[!is.na(tv$MonthsBehind),], method = "glm", family="binomial",
                 metric = "ROC", trControl = ctrl,na.action=na.omit)
# Build up-sampled model
ctrl$sampling <- "up"
up_27 <- train(Outcome~Children.yes+MonthsBehind+Gender.male,
               data = tv[!is.na(tv$MonthsBehind),], method = "glm", family="binomial",
               metric = "ROC", trControl = ctrl,na.action=na.omit)
# Build smote model
ctrl$sampling <- "smote"
smote_27 <- train(Outcome~Children.yes+MonthsBehind+Gender.male,
                  data = tv[!is.na(tv$MonthsBehind),], method = "glm", family="binomial",
                  metric = "ROC", trControl = ctrl,na.action=na.omit)

#Resampling with AUPRC instead of AU ROC--------------------------------------------------------
ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = prSummary,
                     classProbs = TRUE,
                     savePredictions = T,
                     seeds = orig_13$control$seeds)
library(MLmetrics)
#library(MLeval)
orig_13PR <- train(Outcome~MonthsBehind+OwedPerIncome+IncomePerRes, 
                 data = (tv[tv$Income!=0,]),
                 method = "glm", family="binomial",
                 metric = "AUC", trControl = ctrl,na.action=na.omit)
#x<-evalm(orig_13PR)

ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = prSummary,
                     classProbs = TRUE,
                     seeds = orig_18$control$seeds)
orig_18PR <- train(Outcome~ Gender.male+Rooms+OwedPerIncomeBin,
                 data = tv, method = "glm", family="binomial",
                 metric = "AUC", trControl = ctrl,na.action=na.omit)

ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = prSummary,
                     classProbs = TRUE,
                     seeds = orig_20$control$seeds)
orig_20PR <- train(Outcome~ Gender.male+RentAmt+RaceHispanic+IncomePerRes+MonthsBehind, 
                 data = tv, method = "glm", family="binomial",
                 metric = "AUC", trControl = ctrl,na.action=na.omit)

ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = prSummary,
                     classProbs = TRUE,
                     seeds = orig_27$control$seeds)
orig_27PR <- train(Outcome~Children.yes+MonthsBehind+Gender.male, data = tv,
                 method = "glm",na.action=na.omit,trControl=ctrl,metric="AUC")

#cv & resmpling model performance------------------------------------------

valid13a<-predict.train(model13A, validation, type = "prob")
valid18a<-predict.train(model18A, validation, type = "prob")
valid20a<-predict.train(model20A, validation, type = "prob")
valid27a<-predict.train(model27A, validation, type = "prob")
#
v13a<-ifelse(valid13a$`1`<cutoff,0,1)
v13a_mat<-confusionMatrix(as.factor(v13a), validation[!is.na(validation$MonthsBehind & validation$Income!=0),Judgement],positive="1")
roc13a<-roc(validation[!is.na(validation$MonthsBehind & validation$Income!=0),Judgement],factor(valid13a$`1`,ordered=T))

v18a<-ifelse(valid18a$`1`<cutoff,0,1)
v18a_mat<-confusionMatrix(as.factor(v18a), validation[!is.na(validation$OwedPerIncomeBin),Judgement],positive="1")
roc18a<-roc(validation[!is.na(validation$OwedPerIncomeBin),Judgement],factor(valid18a$`1`,ordered=T))

v20a<-ifelse(valid20a$`1`<cutoff,0,1)
v20a_mat<-confusionMatrix(as.factor(v20a), validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement],positive="1")
roc20a<-roc(validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement],factor(valid20a$`1`,ordered=T))

v27a<-ifelse(valid27a$`1`<cutoff,0,1)
v27a_mat<-confusionMatrix(as.factor(v27a), validation[!is.na(validation$MonthsBehind),Judgement],positive="1")
roc27a<-roc(validation[!is.na(validation$MonthsBehind),Judgement],factor(valid27a$`1`,ordered=T))

roc_cv_col<-rainbow(8)
plot(roc13,print.auc=F,print.thres = F,legacy.axes=TRUE,main="ROC Curve, Cross-Validation Models",col=roc_cv_col[1])
legend("topleft",legend=c("Model 13","Model 13A","Model 18","Model 18A"
                          ,"Model 20","Model 20A","Model 27","Model 27A"),col=roc_cv_col,lty=1)
plot(roc13a,print.auc=F,print.thres = F,legacy.axes=TRUE,add=T,col=roc_cv_col[2])
plot(roc18,print.auc=F,print.thres = F,legacy.axes=TRUE,add=T,col=roc_cv_col[3])
plot(roc18a,print.auc=F,print.thres = F,legacy.axes=TRUE,add=T,col=roc_cv_col[4])
plot(roc20a,print.auc=F,print.thres = F,legacy.axes=TRUE,add=T,col=roc_cv_col[5])
plot(roc20a,print.auc=F,print.thres = F,legacy.axes=TRUE,add=T,col=roc_cv_col[6])
plot(roc27a,print.auc=F,print.thres = F,legacy.axes=TRUE,add=T,col=roc_cv_col[7])
plot(roc27a,print.auc=F,print.thres = F,legacy.axes=TRUE,add=T,col=roc_cv_col[8])

pr13a<-pr.curve(scores.class0=valid13a$`1`,valid13a$`0`,curve=T)
pr18a<-pr.curve(scores.class0=valid18a$`1`,valid18a$`0`,curve=T)
pr20a<-pr.curve(scores.class0=valid20a$`1`,valid20a$`0`,curve=T)
pr27a<-pr.curve(scores.class0=valid27a$`1`,valid27a$`0`,curve=T)

mod13a<-c("Model13A",round(v13a_mat$overall[1],4),round(v13a_mat$byClass[1],4),round(v13a_mat$byClass[2],4)
          ,round(v13a_mat$byClass[5],4),round(roc13a$auc,4),round(pr13a$auc.integral,4))
mod18a<-c("Model18A",round(v18a_mat$overall[1],4),round(v18a_mat$byClass[1],4),round(v18a_mat$byClass[2],4)
          ,round(v18a_mat$byClass[5],4),round(roc18a$auc,4),round(pr18a$auc.integral,4))
mod20a<-c("Model20A",round(v20a_mat$overall[1],4),round(v20a_mat$byClass[1],4),round(v20a_mat$byClass[2],4)
          ,round(v20a_mat$byClass[5],4),round(roc20a$auc,4),round(pr20a$auc.integral,4))
mod27a<-c("Model27A",round(v27a_mat$overall[1],4),round(v27a_mat$byClass[1],4),round(v27a_mat$byClass[2],4)
          ,round(v27a_mat$byClass[5],4),round(roc27a$auc,4),round(pr27a$auc.integral,4))


#Validation, Model 13----------------------------------------------------------------------
valid13d<-predict.train(orig_13, validation[validation$Income!=0&!is.na(validation$MonthsBehind),], type = "prob")
valid13d$act<-validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement]
valid13e<-predict.train(weighted_13, validation[validation$Income!=0&!is.na(validation$MonthsBehind),], type = "prob")
valid13e$act<-validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement]
valid13f<-predict.train(down_13, validation[validation$Income!=0&!is.na(validation$MonthsBehind),], type = "prob")
valid13f$act<-validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement]
valid13g<-predict.train(up_13, validation[validation$Income!=0&!is.na(validation$MonthsBehind),], type = "prob")
valid13g$act<-validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement]
valid13h<-predict.train(smote_13, validation[validation$Income!=0&!is.na(validation$MonthsBehind),], type = "prob")
valid13h$act<-validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement]
valid13j<-predict.train(orig_13PR, validation[validation$Income!=0&!is.na(validation$MonthsBehind),], type = "prob")
valid13j$act<-validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement]

v13d<-ifelse(valid13d$`evicted`<cutoff,0,1)
v13d_mat<-confusionMatrix(as.factor(v13d), validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement])
v13e<-ifelse(valid13e$`evicted`<cutoff,0,1)
v13e_mat<-confusionMatrix(as.factor(v13e), validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement])
v13f<-ifelse(valid13f$`evicted`<cutoff,0,1)
v13f_mat<-confusionMatrix(as.factor(v13f), validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement])
v13g<-ifelse(valid13g$`evicted`<cutoff,0,1)
v13g_mat<-confusionMatrix(as.factor(v13g), validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement])
v13h<-ifelse(valid13h$`evicted`<cutoff,0,1)
v13h_mat<-confusionMatrix(as.factor(v13h), validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement])
v13j<-ifelse(valid13j$`evicted`<cutoff,0,1)
v13j_mat<-confusionMatrix(as.factor(v13j), validation[validation$Income!=0&!is.na(validation$MonthsBehind),Judgement])

roc13d<-roc(validation[validation$Income!=0,Judgement],factor(valid13d$evicted,ordered=T))
pr13d<-pr.curve(scores.class0=valid13d[valid13d$act==1,"evicted"],scores.class1=valid13d[valid13d$act==0,"evicted"],curve=T)
roc13e<-roc(validation[validation$Income!=0,Judgement],factor(valid13e$evicted,ordered=T))
pr13e<-pr.curve(scores.class0=valid13e[valid13e$act==1,"evicted"],scores.class1=valid13e[valid13j$act==0,"evicted"],curve=T)
roc13f<-roc(validation[validation$Income!=0,Judgement],factor(valid13f$evicted,ordered=T))
pr13f<-pr.curve(scores.class0=valid13f[valid13f$act==1,"evicted"],scores.class1=valid13f[valid13f$act==0,"evicted"],curve=T)
roc13g<-roc(validation[validation$Income!=0,Judgement],factor(valid13g$evicted,ordered=T))
pr13g<-pr.curve(scores.class0=valid13g[valid13g$act==1,"evicted"],scores.class1=valid13g[valid13j$act==0,"evicted"],curve=T)
roc13h<-roc(validation[validation$Income!=0,Judgement],factor(valid13h$evicted,ordered=T))
pr13h<-pr.curve(scores.class0=valid13h[valid13h$act==1,"evicted"],scores.class1=valid13h[valid13j$act==0,"evicted"],curve=T)
roc13j<-roc(validation[validation$Income!=0,Judgement],factor(valid13j$evicted,ordered=T))
pr13j<-pr.curve(scores.class0=valid13j[valid13j$act==1,"evicted"],scores.class1=valid13j[valid13j$act==0,"evicted"],curve=T)


mod13d<-c("Model13D",round(v13d_mat$overall[1],4),round(v13d_mat$byClass[1],4),round(v13d_mat$byClass[2],4)
          ,round(v13d_mat$byClass[5],4),round(roc13d$auc,4),round(pr13d$auc.integral,4))
mod13e<-c("Model13E",round(v13e_mat$overall[1],4),round(v13e_mat$byClass[1],4),round(v13e_mat$byClass[2],4)
          ,round(v13e_mat$byClass[5],4),round(roc13e$auc,4),round(pr13e$auc.integral,4))
mod13f<-c("Model13F",round(v13f_mat$overall[1],4),round(v13f_mat$byClass[1],4),round(v13f_mat$byClass[2],4)
          ,round(v13f_mat$byClass[5],4),round(roc13f$auc,4),round(pr13f$auc.integral,4))
mod13g<-c("Model13G",round(v13g_mat$overall[1],4),round(v13g_mat$byClass[1],4),round(v13g_mat$byClass[2],4)
          ,round(v13g_mat$byClass[5],4),round(roc13g$auc,4),round(pr13g$auc.integral,4))
mod13h<-c("Model13H",round(v13h_mat$overall[1],4),round(v13h_mat$byClass[1],4),round(v13h_mat$byClass[2],4)
          ,round(v13h_mat$byClass[5],4),round(roc13h$auc,4),round(pr13h$auc.integral,4))
mod13j<-c("Model13J",round(v13j_mat$overall[1],4),round(v13j_mat$byClass[1],4),round(v13j_mat$byClass[2],4)
          ,round(v13j_mat$byClass[5],4),round(roc13j$auc,4),round(pr13j$auc.integral,4))

#plot ROC curves
roctable13<-tibble(Model="Model 13",Sensitivity=roc13$sensitivities,Specificity=roc13$specificities)
roctable13<-roctable13%>%
  add_row(Model="Model 13A",Sensitivity=roc13a$sensitivities,Specificity=roc13a$specificities)%>%
  add_row(Model="Model 13D",Sensitivity=roc13d$sensitivities,Specificity=roc13d$specificities)%>%
  add_row(Model="Model 13E",Sensitivity=roc13e$sensitivities,Specificity=roc13e$specificities)%>%
  add_row(Model="Model 13F",Sensitivity=roc13f$sensitivities,Specificity=roc13f$specificities)%>%
  add_row(Model="Model 13G",Sensitivity=roc13g$sensitivities,Specificity=roc13g$specificities)%>%
  add_row(Model="Model 13H",Sensitivity=roc13h$sensitivities,Specificity=roc13h$specificities)%>%
  add_row(Model="Model 13J",Sensitivity=roc13j$sensitivities,Specificity=roc13j$specificities)

ggplot(roctable13)+
  geom_line(aes(x=1-Sensitivity,y=Specificity,group=Model,color=Model))+
  labs(title="ROC Curves, Model 13")
  
#plot pr curves
prtable13<-tibble(Model="Model 13",Recall=pr13$curve[, 1],Precision=pr13$curve[, 2])
prtable13<-prtable13%>%
  add_row(Model="Model 13A",Recall=pr13a$curve[, 1],Precision=pr13a$curve[, 2])%>%
  add_row(Model="Model 13D",Recall=pr13d$curve[, 1],Precision=pr13d$curve[, 2])%>%
  add_row(Model="Model 13E",Recall=pr13e$curve[, 1],Precision=pr13e$curve[, 2])%>%
  add_row(Model="Model 13F",Recall=pr13f$curve[, 1],Precision=pr13f$curve[, 2])%>%
  add_row(Model="Model 13G",Recall=pr13g$curve[, 1],Precision=pr13g$curve[, 2])%>%
  add_row(Model="Model 13H",Recall=pr13h$curve[, 1],Precision=pr13h$curve[, 2])%>%
  add_row(Model="Model 13J",Recall=pr13j$curve[, 1],Precision=pr13j$curve[, 2])
  
ggplot(prtable13)+
  geom_line(aes(x=Recall,y=Precision,group=Model,color=Model))+
  labs(title="Precision-Recall Curves, Model 13")

#Validation, Model 18--------------------------------------------------
valid18d<-predict.train(orig_18, validation[validation$Income!=0,], type = "prob")
valid18d$act<-validation[validation$Income!=0,Judgement]
valid18e<-predict.train(weighted_18, validation[validation$Income!=0,], type = "prob")
valid18e$act<-validation[validation$Income!=0,Judgement]
valid18f<-predict.train(down_18, validation[validation$Income!=0,], type = "prob")
valid18f$act<-validation[validation$Income!=0,Judgement]
valid18g<-predict.train(up_18, validation[validation$Income!=0,], type = "prob")
valid18g$act<-validation[validation$Income!=0,Judgement]
valid18h<-predict.train(smote_18, validation[validation$Income!=0,], type = "prob")
valid18h$act<-validation[validation$Income!=0,Judgement]
valid18j<-predict.train(orig_18PR, validation[validation$Income!=0,], type = "prob")
valid18j$act<-validation[validation$Income!=0,Judgement]

v18d<-ifelse(valid18d$`evicted`<cutoff,0,1)
v18d_mat<-confusionMatrix(as.factor(v18d), validation[validation$Income!=0,Judgement])
v18e<-ifelse(valid18e$`evicted`<cutoff,0,1)
v18e_mat<-confusionMatrix(as.factor(v18e), validation[validation$Income!=0,Judgement])
v18f<-ifelse(valid18f$`evicted`<cutoff,0,1)
v18f_mat<-confusionMatrix(as.factor(v18f), validation[validation$Income!=0,Judgement])
v18g<-ifelse(valid18g$`evicted`<cutoff,0,1)
v18g_mat<-confusionMatrix(as.factor(v18g), validation[validation$Income!=0,Judgement])
v18h<-ifelse(valid18h$`evicted`<cutoff,0,1)
v18h_mat<-confusionMatrix(as.factor(v18h), validation[validation$Income!=0,Judgement])
v18j<-ifelse(valid18j$`evicted`<cutoff,0,1)
v18j_mat<-confusionMatrix(as.factor(v18j), validation[validation$Income!=0,Judgement])

roc18d<-roc(validation[validation$Income!=0,Judgement],factor(valid18d$evicted,ordered=T))
pr18d<-pr.curve(scores.class0=valid18d[valid18d$act==1,"evicted"],scores.class1=valid18d[valid18d$act==0,"evicted"],curve=T)
roc18e<-roc(validation[validation$Income!=0,Judgement],factor(valid18e$evicted,ordered=T))
pr18e<-pr.curve(scores.class0=valid18e[valid18e$act==1,"evicted"],scores.class1=valid18e[valid18j$act==0,"evicted"],curve=T)
roc18f<-roc(validation[validation$Income!=0,Judgement],factor(valid18f$evicted,ordered=T))
pr18f<-pr.curve(scores.class0=valid18f[valid18f$act==1,"evicted"],scores.class1=valid18f[valid18f$act==0,"evicted"],curve=T)
roc18g<-roc(validation[validation$Income!=0,Judgement],factor(valid18g$evicted,ordered=T))
pr18g<-pr.curve(scores.class0=valid18g[valid18g$act==1,"evicted"],scores.class1=valid18g[valid18j$act==0,"evicted"],curve=T)
roc18h<-roc(validation[validation$Income!=0,Judgement],factor(valid18h$evicted,ordered=T))
pr18h<-pr.curve(scores.class0=valid18h[valid18h$act==1,"evicted"],scores.class1=valid18h[valid18j$act==0,"evicted"],curve=T)
roc18j<-roc(validation[validation$Income!=0,Judgement],factor(valid18j$evicted,ordered=T))
pr18j<-pr.curve(scores.class0=valid18j[valid18j$act==1,"evicted"],scores.class1=valid18j[valid18j$act==0,"evicted"],curve=T)


mod18d<-c("Model18D",round(v18d_mat$overall[1],4),round(v18d_mat$byClass[1],4),round(v18d_mat$byClass[2],4)
          ,round(v18d_mat$byClass[5],4),round(roc18d$auc,4),round(pr18d$auc.integral,4))
mod18e<-c("Model18E",round(v18e_mat$overall[1],4),round(v18e_mat$byClass[1],4),round(v18e_mat$byClass[2],4)
          ,round(v18e_mat$byClass[5],4),round(roc18e$auc,4),round(pr18e$auc.integral,4))
mod18f<-c("Model18F",round(v18f_mat$overall[1],4),round(v18f_mat$byClass[1],4),round(v18f_mat$byClass[2],4)
          ,round(v18f_mat$byClass[5],4),round(roc18f$auc,4),round(pr18f$auc.integral,4))
mod18g<-c("Model18G",round(v18g_mat$overall[1],4),round(v18g_mat$byClass[1],4),round(v18g_mat$byClass[2],4)
          ,round(v18g_mat$byClass[5],4),round(roc18g$auc,4),round(pr18g$auc.integral,4))
mod18h<-c("Model18H",round(v18h_mat$overall[1],4),round(v18h_mat$byClass[1],4),round(v18h_mat$byClass[2],4)
          ,round(v18h_mat$byClass[5],4),round(roc18h$auc,4),round(pr18h$auc.integral,4))
mod18j<-c("Model18J",round(v18j_mat$overall[1],4),round(v18j_mat$byClass[1],4),round(v18j_mat$byClass[2],4)
          ,round(v18j_mat$byClass[5],4),round(roc18j$auc,4),round(pr18j$auc.integral,4))

#plot ROC curves
roctable18<-tibble(Model="Model 18",Sensitivity=roc18$sensitivities,Specificity=roc18$specificities)
roctable18<-roctable18%>%
  add_row(Model="Model 18A",Sensitivity=roc18a$sensitivities,Specificity=roc18a$specificities)%>%
  add_row(Model="Model 18D",Sensitivity=roc18d$sensitivities,Specificity=roc18d$specificities)%>%
  add_row(Model="Model 18E",Sensitivity=roc18e$sensitivities,Specificity=roc18e$specificities)%>%
  add_row(Model="Model 18F",Sensitivity=roc18f$sensitivities,Specificity=roc18f$specificities)%>%
  add_row(Model="Model 18G",Sensitivity=roc18g$sensitivities,Specificity=roc18g$specificities)%>%
  add_row(Model="Model 18H",Sensitivity=roc18h$sensitivities,Specificity=roc18h$specificities)%>%
  add_row(Model="Model 18J",Sensitivity=roc18j$sensitivities,Specificity=roc18j$specificities)

ggplot(roctable18)+
  geom_line(aes(x=1-Sensitivity,y=Specificity,group=Model,color=Model))+
  labs(title="ROC Curves, Model 18")

#plot pr curves
prtable18<-tibble(Model="Model 18",Recall=pr18$curve[, 1],Precision=pr18$curve[, 2])
prtable18<-prtable18%>%
  add_row(Model="Model 18A",Recall=pr18a$curve[, 1],Precision=pr18a$curve[, 2])%>%
  add_row(Model="Model 18D",Recall=pr18d$curve[, 1],Precision=pr18d$curve[, 2])%>%
  add_row(Model="Model 18E",Recall=pr18e$curve[, 1],Precision=pr18e$curve[, 2])%>%
  add_row(Model="Model 18F",Recall=pr18f$curve[, 1],Precision=pr18f$curve[, 2])%>%
  add_row(Model="Model 18G",Recall=pr18g$curve[, 1],Precision=pr18g$curve[, 2])%>%
  add_row(Model="Model 18H",Recall=pr18h$curve[, 1],Precision=pr18h$curve[, 2])%>%
  add_row(Model="Model 18J",Recall=pr18j$curve[, 1],Precision=pr18j$curve[, 2])

ggplot(prtable18)+
  geom_line(aes(x=Recall,y=Precision,group=Model,color=Model))+
  labs(title="Precision-Recall Curves, Model 18")

#Validation, Model 20--------------------------------------------------
valid20d<-predict.train(orig_20, validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),], type = "prob")
valid20d$act<-validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement]
valid20e<-predict.train(weighted_20, validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),], type = "prob")
valid20e$act<-validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement]
valid20f<-predict.train(down_20, validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),], type = "prob")
valid20f$act<-validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement]
valid20g<-predict.train(up_20, validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),], type = "prob")
valid20g$act<-validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement]
valid20h<-predict.train(smote_20, validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),], type = "prob")
valid20h$act<-validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement]
valid20j<-predict.train(orig_20PR, validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),], type = "prob")
valid20j$act<-validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement]

v20d<-ifelse(valid20d$`evicted`<cutoff,0,1)
v20d_mat<-confusionMatrix(as.factor(v20d),validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement])
v20e<-ifelse(valid20e$`evicted`<cutoff,0,1)
v20e_mat<-confusionMatrix(as.factor(v20e), validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement])
v20f<-ifelse(valid20f$`evicted`<cutoff,0,1)
v20f_mat<-confusionMatrix(as.factor(v20f), validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement])
v20g<-ifelse(valid20g$`evicted`<cutoff,0,1)
v20g_mat<-confusionMatrix(as.factor(v20g), validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement])
v20h<-ifelse(valid20h$`evicted`<cutoff,0,1)
v20h_mat<-confusionMatrix(as.factor(v20h), validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement])
v20j<-ifelse(valid20j$`evicted`<cutoff,0,1)
v20j_mat<-confusionMatrix(as.factor(v20j), validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement])

roc20d<-roc(validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement],factor(valid20d$evicted,ordered=T))
pr20d<-pr.curve(scores.class0=valid20d[valid20d$act==1,"evicted"],scores.class1=valid20d[valid20d$act==0,"evicted"],curve=T)
roc20e<-roc(validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement],factor(valid20e$evicted,ordered=T))
pr20e<-pr.curve(scores.class0=valid20e[valid20e$act==1,"evicted"],scores.class1=valid20e[valid20j$act==0,"evicted"],curve=T)
roc20f<-roc(validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement],factor(valid20f$evicted,ordered=T))
pr20f<-pr.curve(scores.class0=valid20f[valid20f$act==1,"evicted"],scores.class1=valid20f[valid20f$act==0,"evicted"],curve=T)
roc20g<-roc(validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement],factor(valid20g$evicted,ordered=T))
pr20g<-pr.curve(scores.class0=valid20g[valid20g$act==1,"evicted"],scores.class1=valid20g[valid20j$act==0,"evicted"],curve=T)
roc20h<-roc(validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement],factor(valid20h$evicted,ordered=T))
pr20h<-pr.curve(scores.class0=valid20h[valid20h$act==1,"evicted"],scores.class1=valid20h[valid20j$act==0,"evicted"],curve=T)
roc20j<-roc(validation[!is.na(validation$MonthsBehind)&!is.na(validation$Income),Judgement],factor(valid20j$evicted,ordered=T))
pr20j<-pr.curve(scores.class0=valid20j[valid20j$act==1,"evicted"],scores.class1=valid20j[valid20j$act==0,"evicted"],curve=T)


mod20d<-c("Model20D",round(v20d_mat$overall[1],4),round(v20d_mat$byClass[1],4),round(v20d_mat$byClass[2],4)
          ,round(v20d_mat$byClass[5],4),round(roc20d$auc,4),round(pr20d$auc.integral,4))
mod20e<-c("Model20E",round(v20e_mat$overall[1],4),round(v20e_mat$byClass[1],4),round(v20e_mat$byClass[2],4)
          ,round(v20e_mat$byClass[5],4),round(roc20e$auc,4),round(pr20e$auc.integral,4))
mod20f<-c("Model20F",round(v20f_mat$overall[1],4),round(v20f_mat$byClass[1],4),round(v20f_mat$byClass[2],4)
          ,round(v20f_mat$byClass[5],4),round(roc20f$auc,4),round(pr20f$auc.integral,4))
mod20g<-c("Model20G",round(v20g_mat$overall[1],4),round(v20g_mat$byClass[1],4),round(v20g_mat$byClass[2],4)
          ,round(v20g_mat$byClass[5],4),round(roc20g$auc,4),round(pr20g$auc.integral,4))
mod20h<-c("Model20H",round(v20h_mat$overall[1],4),round(v20h_mat$byClass[1],4),round(v20h_mat$byClass[2],4)
          ,round(v20h_mat$byClass[5],4),round(roc20h$auc,4),round(pr20h$auc.integral,4))
mod20j<-c("Model20J",round(v20j_mat$overall[1],4),round(v20j_mat$byClass[1],4),round(v20j_mat$byClass[2],4)
          ,round(v20j_mat$byClass[5],4),round(roc20j$auc,4),round(pr20j$auc.integral,4))

#plot ROC curves
roctable20<-tibble(Model="Model 20",Sensitivity=roc20$sensitivities,Specificity=roc20$specificities)
roctable20<-roctable20%>%
  add_row(Model="Model 20A",Sensitivity=roc20a$sensitivities,Specificity=roc20a$specificities)%>%
  add_row(Model="Model 20D",Sensitivity=roc20d$sensitivities,Specificity=roc20d$specificities)%>%
  add_row(Model="Model 20E",Sensitivity=roc20e$sensitivities,Specificity=roc20e$specificities)%>%
  add_row(Model="Model 20F",Sensitivity=roc20f$sensitivities,Specificity=roc20f$specificities)%>%
  add_row(Model="Model 20G",Sensitivity=roc20g$sensitivities,Specificity=roc20g$specificities)%>%
  add_row(Model="Model 20H",Sensitivity=roc20h$sensitivities,Specificity=roc20h$specificities)%>%
  add_row(Model="Model 20J",Sensitivity=roc20j$sensitivities,Specificity=roc20j$specificities)

ggplot(roctable20)+
  geom_line(aes(x=1-Sensitivity,y=Specificity,group=Model,color=Model))+
  labs(title="ROC Curves, Model 20")

#plot pr curves
prtable20<-tibble(Model="Model 20",Recall=pr20$curve[, 1],Precision=pr20$curve[, 2])
prtable20<-prtable20%>%
  add_row(Model="Model 20A",Recall=pr20a$curve[, 1],Precision=pr20a$curve[, 2])%>%
  add_row(Model="Model 20D",Recall=pr20d$curve[, 1],Precision=pr20d$curve[, 2])%>%
  add_row(Model="Model 20E",Recall=pr20e$curve[, 1],Precision=pr20e$curve[, 2])%>%
  add_row(Model="Model 20F",Recall=pr20f$curve[, 1],Precision=pr20f$curve[, 2])%>%
  add_row(Model="Model 20G",Recall=pr20g$curve[, 1],Precision=pr20g$curve[, 2])%>%
  add_row(Model="Model 20H",Recall=pr20h$curve[, 1],Precision=pr20h$curve[, 2])%>%
  add_row(Model="Model 20J",Recall=pr20j$curve[, 1],Precision=pr20j$curve[, 2])

ggplot(prtable20)+
  geom_line(aes(x=Recall,y=Precision,group=Model,color=Model))+
  labs(title="Precision-Recall Curves, Model 20")

#Validation, Model 27--------------------------------------------------
valid27d<-predict.train(orig_27, validation[!is.na(validation$MonthsBehind),], type = "prob")
valid27d$act<-validation[!is.na(validation$MonthsBehind),Judgement]
valid27e<-predict.train(weighted_27, validation[!is.na(validation$MonthsBehind),], type = "prob")
valid27e$act<-validation[!is.na(validation$MonthsBehind),Judgement]
valid27f<-predict.train(down_27, validation[!is.na(validation$MonthsBehind),], type = "prob")
valid27f$act<-validation[!is.na(validation$MonthsBehind),Judgement]
valid27g<-predict.train(up_27, validation[!is.na(validation$MonthsBehind),], type = "prob")
valid27g$act<-validation[!is.na(validation$MonthsBehind),Judgement]
valid27h<-predict.train(smote_27, validation[!is.na(validation$MonthsBehind),], type = "prob")
valid27h$act<-validation[!is.na(validation$MonthsBehind),Judgement]
valid27j<-predict.train(orig_27PR, validation[!is.na(validation$MonthsBehind),], type = "prob")
valid27j$act<-validation[!is.na(validation$MonthsBehind),Judgement]

v27d<-ifelse(valid27d$`evicted`<cutoff,0,1)
v27d_mat<-confusionMatrix(as.factor(v27d), validation[!is.na(validation$MonthsBehind),Judgement])
v27e<-ifelse(valid27e$`evicted`<cutoff,0,1)
v27e_mat<-confusionMatrix(as.factor(v27e), validation[!is.na(validation$MonthsBehind),Judgement])
v27f<-ifelse(valid27f$`evicted`<cutoff,0,1)
v27f_mat<-confusionMatrix(as.factor(v27f), validation[!is.na(validation$MonthsBehind),Judgement])
v27g<-ifelse(valid27g$`evicted`<cutoff,0,1)
v27g_mat<-confusionMatrix(as.factor(v27g), validation[!is.na(validation$MonthsBehind),Judgement])
v27h<-ifelse(valid27h$`evicted`<cutoff,0,1)
v27h_mat<-confusionMatrix(as.factor(v27h), validation[!is.na(validation$MonthsBehind),Judgement])
v27j<-ifelse(valid27j$`evicted`<cutoff,0,1)
v27j_mat<-confusionMatrix(as.factor(v27j), validation[!is.na(validation$MonthsBehind),Judgement])

roc27d<-roc(validation[!is.na(validation$MonthsBehind),Judgement],factor(valid27d$evicted,ordered=T))
pr27d<-pr.curve(scores.class0=valid27d[valid27d$act==1,"evicted"],scores.class1=valid27d[valid27d$act==0,"evicted"],curve=T)
roc27e<-roc(validation[!is.na(validation$MonthsBehind),Judgement],factor(valid27e$evicted,ordered=T))
pr27e<-pr.curve(scores.class0=valid27e[valid27e$act==1,"evicted"],scores.class1=valid27e[valid27j$act==0,"evicted"],curve=T)
roc27f<-roc(validation[!is.na(validation$MonthsBehind),Judgement],factor(valid27f$evicted,ordered=T))
pr27f<-pr.curve(scores.class0=valid27f[valid27f$act==1,"evicted"],scores.class1=valid27f[valid27f$act==0,"evicted"],curve=T)
roc27g<-roc(validation[!is.na(validation$MonthsBehind),Judgement],factor(valid27g$evicted,ordered=T))
pr27g<-pr.curve(scores.class0=valid27g[valid27g$act==1,"evicted"],scores.class1=valid27g[valid27j$act==0,"evicted"],curve=T)
roc27h<-roc(validation[!is.na(validation$MonthsBehind),Judgement],factor(valid27h$evicted,ordered=T))
pr27h<-pr.curve(scores.class0=valid27h[valid27h$act==1,"evicted"],scores.class1=valid27h[valid27j$act==0,"evicted"],curve=T)
roc27j<-roc(validation[!is.na(validation$MonthsBehind),Judgement],factor(valid27j$evicted,ordered=T))
pr27j<-pr.curve(scores.class0=valid27j[valid27j$act==1,"evicted"],scores.class1=valid27j[valid27j$act==0,"evicted"],curve=T)


mod27d<-c("Model27D",round(v27d_mat$overall[1],4),round(v27d_mat$byClass[1],4),round(v27d_mat$byClass[2],4)
          ,round(v27d_mat$byClass[5],4),round(roc27d$auc,4),round(pr27d$auc.integral,4))
mod27e<-c("Model27E",round(v27e_mat$overall[1],4),round(v27e_mat$byClass[1],4),round(v27e_mat$byClass[2],4)
          ,round(v27e_mat$byClass[5],4),round(roc27e$auc,4),round(pr27e$auc.integral,4))
mod27f<-c("Model27F",round(v27f_mat$overall[1],4),round(v27f_mat$byClass[1],4),round(v27f_mat$byClass[2],4)
          ,round(v27f_mat$byClass[5],4),round(roc27f$auc,4),round(pr27f$auc.integral,4))
mod27g<-c("Model27G",round(v27g_mat$overall[1],4),round(v27g_mat$byClass[1],4),round(v27g_mat$byClass[2],4)
          ,round(v27g_mat$byClass[5],4),round(roc27g$auc,4),round(pr27g$auc.integral,4))
mod27h<-c("Model27H",round(v27h_mat$overall[1],4),round(v27h_mat$byClass[1],4),round(v27h_mat$byClass[2],4)
          ,round(v27h_mat$byClass[5],4),round(roc27h$auc,4),round(pr27h$auc.integral,4))
mod27j<-c("Model27J",round(v27j_mat$overall[1],4),round(v27j_mat$byClass[1],4),round(v27j_mat$byClass[2],4)
          ,round(v27j_mat$byClass[5],4),round(roc27j$auc,4),round(pr27j$auc.integral,4))

#plot ROC curves
roctable27<-tibble(Model="Model 27",Sensitivity=roc27$sensitivities,Specificity=roc27$specificities)
roctable27<-roctable27%>%
  add_row(Model="Model 27A",Sensitivity=roc27a$sensitivities,Specificity=roc27a$specificities)%>%
  add_row(Model="Model 27D",Sensitivity=roc27d$sensitivities,Specificity=roc27d$specificities)%>%
  add_row(Model="Model 27E",Sensitivity=roc27e$sensitivities,Specificity=roc27e$specificities)%>%
  add_row(Model="Model 27F",Sensitivity=roc27f$sensitivities,Specificity=roc27f$specificities)%>%
  add_row(Model="Model 27G",Sensitivity=roc27g$sensitivities,Specificity=roc27g$specificities)%>%
  add_row(Model="Model 27H",Sensitivity=roc27h$sensitivities,Specificity=roc27h$specificities)%>%
  add_row(Model="Model 27J",Sensitivity=roc27j$sensitivities,Specificity=roc27j$specificities)

ggplot(roctable27)+
  geom_line(aes(x=1-Sensitivity,y=Specificity,group=Model,color=Model))+
  labs(title="ROC Curves, Model 27")

#plot pr curves
prtable27<-tibble(Model="Model 27",Recall=pr27$curve[, 1],Precision=pr27$curve[, 2])
prtable27<-prtable27%>%
  add_row(Model="Model 27A",Recall=pr27a$curve[, 1],Precision=pr27a$curve[, 2])%>%
  add_row(Model="Model 27D",Recall=pr27d$curve[, 1],Precision=pr27d$curve[, 2])%>%
  add_row(Model="Model 27E",Recall=pr27e$curve[, 1],Precision=pr27e$curve[, 2])%>%
  add_row(Model="Model 27F",Recall=pr27f$curve[, 1],Precision=pr27f$curve[, 2])%>%
  add_row(Model="Model 27G",Recall=pr27g$curve[, 1],Precision=pr27g$curve[, 2])%>%
  add_row(Model="Model 27H",Recall=pr27h$curve[, 1],Precision=pr27h$curve[, 2])%>%
  add_row(Model="Model 27J",Recall=pr27j$curve[, 1],Precision=pr27j$curve[, 2])

ggplot(prtable27)+
  geom_line(aes(x=Recall,y=Precision,group=Model,color=Model))+
  labs(title="Precision-Recall Curves, Model 27")


#----------------------------------------------------
exp(coef(orig_27PR$finalModel))

coef(orig_13PR$finalModel)

# evaluation table------------------------------------------
eval_cv<-data.frame(
  Model=character(),
  Accuracy=numeric(),
  Sensitivity=numeric(),  #Sensitivity = Recall
  Specificity=numeric(),
  Precision=numeric(),
  ROC_AUC=numeric(),
  PR_AUC=numeric(),
  stringsAsFactors = F)

eval_cv[nrow(eval_cv)+1,]<-mod13
eval_cv<-rbind(eval_cv,mod13a,mod18,mod18a,mod20,mod20a,mod27,mod27a)
eval_cv<-rbind(eval_cv,mod13d,mod13e,mod13f,mod13g,mod13h,mod13j)
eval_cv<-rbind(eval_cv,mod18d,mod18e,mod18f,mod18g,mod18h,mod18j)
eval_cv<-rbind(eval_cv,mod20d,mod20e,mod20f,mod20g,mod20h,mod20j)
eval_cv<-rbind(eval_cv,mod27d,mod20e,mod27f,mod27g,mod27h,mod27j)
#write.csv(eval_cv, file = "cv_eval.csv",row.names=FALSE)
#model evaluation:  test data----------------------------------------------------------------------
#4,7,11,13,14,18,20,25,26,27
test4=predict(model4, test, type = "response")
test7=predict(model7, test, type = "response")
test11=predict(model11, test, type = "response")
test13=predict(model13, test, type = "response")
test14=predict(model14, test, type = "response")
test18=predict(model18, test, type = "response")
test20=predict(model20, test, type = "response")
test25=predict(model25, test, type = "response")
test26=predict(model26, test, type = "response")
test27=predict(model27, test, type = "response")

test13d<-predict.train(orig_13, test[test$Income!=0&!is.na(test$MonthsBehind),], type = "prob")
test13d$act<-test[test$Income!=0&!is.na(test$MonthsBehind),Judgement]
test13e<-predict.train(weighted_13, test[test$Income!=0&!is.na(test$MonthsBehind),], type = "prob")
test13e$act<-test[test$Income!=0&!is.na(test$MonthsBehind),Judgement]
test13f<-predict.train(down_13, test[test$Income!=0&!is.na(test$MonthsBehind),], type = "prob")
test13f$act<-test[test$Income!=0&!is.na(test$MonthsBehind),Judgement]
test13g<-predict.train(up_13, test[test$Income!=0&!is.na(test$MonthsBehind),], type = "prob")
test13g$act<-test[test$Income!=0&!is.na(test$MonthsBehind),Judgement]
test13h<-predict.train(smote_13, test[test$Income!=0&!is.na(test$MonthsBehind),], type = "prob")
test13h$act<-test[test$Income!=0&!is.na(test$MonthsBehind),Judgement]
test13j<-predict.train(orig_13PR,test[test$Income!=0&!is.na(test$MonthsBehind),], type = "prob")
test13j$act<-test[test$Income!=0&!is.na(test$MonthsBehind),Judgement]

test18d<-predict.train(orig_18, test[test$Income!=0,], type = "prob")
test18d$act<-test[test$Income!=0,Judgement]
test18e<-predict.train(weighted_18, test[test$Income!=0,], type = "prob")
test18e$act<-test[test$Income!=0,Judgement]
test18f<-predict.train(down_18, test[test$Income!=0,], type = "prob")
test18f$act<-test[test$Income!=0,Judgement]
test18g<-predict.train(up_18, test[test$Income!=0,], type = "prob")
test18g$act<-test[test$Income!=0,Judgement]
test18h<-predict.train(smote_18, test[test$Income!=0,], type = "prob")
test18h$act<-test[test$Income!=0,Judgement]
test18j<-predict.train(orig_18PR, test[test$Income!=0,], type = "prob")
test18j$act<-test[test$Income!=0,Judgement]

test20d<-predict.train(orig_20, test[!is.na(test$MonthsBehind)&!is.na(test$Income),], type = "prob")
test20d$act<-test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement]
test20e<-predict.train(weighted_20, test[!is.na(test$MonthsBehind)&!is.na(test$Income),], type = "prob")
test20e$act<-test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement]
test20f<-predict.train(down_20, test[!is.na(test$MonthsBehind)&!is.na(test$Income),], type = "prob")
test20f$act<-test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement]
test20g<-predict.train(up_20, test[!is.na(test$MonthsBehind)&!is.na(test$Income),], type = "prob")
test20g$act<-test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement]
test20h<-predict.train(smote_20, test[!is.na(test$MonthsBehind)&!is.na(test$Income),], type = "prob")
test20h$act<-test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement]
test20j<-predict.train(orig_20PR, test[!is.na(test$MonthsBehind)&!is.na(test$Income),], type = "prob")
test20j$act<-test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement]

test27d<-predict.train(orig_27, test[!is.na(test$MonthsBehind),], type = "prob")
test27d$act<-test[!is.na(test$MonthsBehind),Judgement]
test27e<-predict.train(weighted_27, test[!is.na(test$MonthsBehind),], type = "prob")
test27e$act<-test[!is.na(test$MonthsBehind),Judgement]
test27f<-predict.train(down_27, test[!is.na(test$MonthsBehind),], type = "prob")
test27f$act<-test[!is.na(test$MonthsBehind),Judgement]
test27g<-predict.train(up_27, test[!is.na(test$MonthsBehind),], type = "prob")
test27g$act<-test[!is.na(test$MonthsBehind),Judgement]
test27h<-predict.train(smote_27, test[!is.na(test$MonthsBehind),], type = "prob")
test27h$act<-test[!is.na(test$MonthsBehind),Judgement]
test27j<-predict.train(orig_27PR, test[!is.na(test$MonthsBehind),], type = "prob")
test27j$act<-test[!is.na(test$MonthsBehind),Judgement]

t4<-ifelse(test4<cutoff,0,1)
t4_mat<-confusionMatrix(as.factor(t4), test$Judgement,positive="1")
roct04<-roc(test$Judgement,factor(test4,ordered=T))
t7<-ifelse(test7<cutoff,0,1)
t7_mat<-confusionMatrix(as.factor(t7), test$Judgement,positive="1")
roct07<-roc(test$Judgement,factor(test7,ordered=T))
t11<-ifelse(test11<cutoff,0,1)
t11_mat<-confusionMatrix(as.factor(t11), test$Judgement,positive="1")
roct11<-roc(test$Judgement,factor(test11,ordered=T))
t13<-ifelse(test13<cutoff,0,1)
t13_mat<-confusionMatrix(as.factor(t13), test$Judgement,positive="1")
roct13<-roc(test$Judgement,factor(test13,ordered=T))
t14<-ifelse(test14<cutoff,0,1)
t14_mat<-confusionMatrix(as.factor(t14), test$Judgement,positive="1")
roct14<-roc(test$Judgement,factor(test14,ordered=T))
t18<-ifelse(test18<cutoff,0,1)
t18_mat<-confusionMatrix(as.factor(t18), test$Judgement,positive="1")
roct18<-roc(test$Judgement,factor(test18,ordered=T))
t20<-ifelse(test20<cutoff,0,1)
t20_mat<-confusionMatrix(as.factor(t20), test$Judgement,positive="1")
roct20<-roc(test$Judgement,factor(test20,ordered=T))
t25<-ifelse(test25<cutoff,0,1)
t25_mat<-confusionMatrix(as.factor(t25), test$Judgement,positive="1")
roct25<-roc(test$Judgement,factor(test25,ordered=T))
t26<-ifelse(test26<cutoff,0,1)
t26_mat<-confusionMatrix(as.factor(t26), test$Judgement,positive="1")
roct26<-roc(test$Judgement,factor(test26,ordered=T))
t27<-ifelse(test27<cutoff,0,1)
t27_mat<-confusionMatrix(as.factor(t27), test$Judgement,positive="1")
roct27<-roc(test$Judgement,factor(test27,ordered=T))

df.t4<-data.frame(prob=test4,act=test$Judgement)
prt4<-pr.curve(scores.class0=na.omit(df.t4[df.t4$act==1,"prob"]),scores.class1=na.omit(df.t4[df.t4$act==0,"prob"]),curve=T)
df.t7<-data.frame(prob=test7,act=test$Judgement)
prt7<-pr.curve(scores.class0=na.omit(df.t7[df.t7$act==1,"prob"]),scores.class1=na.omit(df.t7[df.t7$act==0,"prob"]),curve=T)
df.t11<-data.frame(prob=test11,act=test$Judgement)
prt11<-pr.curve(scores.class0=na.omit(df.t11[df.t11$act==1,"prob"]),scores.class1=na.omit(df.t11[df.t11$act==0,"prob"]),curve=T)
df.t13<-data.frame(prob=test13,act=test$Judgement)
prt13<-pr.curve(scores.class0=na.omit(df.t13[df.t13$act==1,"prob"]),scores.class1=na.omit(df.t13[df.t13$act==0,"prob"]),curve=T)
df.t14<-data.frame(prob=test14,act=test$Judgement)
prt14<-pr.curve(scores.class0=na.omit(df.t14[df.t14$act==1,"prob"]),scores.class1=na.omit(df.t14[df.14$act==0,"prob"]),curve=T)
df.t18<-data.frame(prob=test18,act=test$Judgement)
prt18<-pr.curve(scores.class0=na.omit(df.t18[df.t18$act==1,"prob"]),scores.class1=na.omit(df.t18[df.t18$act==0,"prob"]),curve=T)
df.t20<-data.frame(prob=test20,act=test$Judgement)
prt20<-pr.curve(scores.class0=na.omit(df.t20[df.t20$act==1,"prob"]),scores.class1=na.omit(df.t20[df.t20$act==0,"prob"]),curve=T)
df.t25<-data.frame(prob=test25,act=test$Judgement)
prt25<-pr.curve(scores.class0=na.omit(df.t25[df.t25$act==1,"prob"]),scores.class1=na.omit(df.t25[df.t25$act==0,"prob"]),curve=T)
df.t26<-data.frame(prob=test26,act=test$Judgement)
prt26<-pr.curve(scores.class0=na.omit(df.t26[df.t26$act==1,"prob"]),scores.class1=na.omit(df.t26[df.t26$act==0,"prob"]),curve=T)
df.t27<-data.frame(prob=test27,act=test$Judgement)
prt27<-pr.curve(scores.class0=na.omit(df.t27[df.t27$act==1,"prob"]),scores.class1=na.omit(df.t27[df.t27$act==0,"prob"]),curve=T)

modt04<-c("Model04",round(t4_mat$overall[1],4),round(t4_mat$byClass[1],4),round(t4_mat$byClass[2],4)
          ,round(t4_mat$byClass[5],4),round(roct04$auc,4),round(prt4$auc.integral,4))
modt07<-c("Model07",round(t7_mat$overall[1],4),round(t7_mat$byClass[1],4),round(t7_mat$byClass[2],4)
          ,round(t7_mat$byClass[5],4),round(roct07$auc,4),round(prt7$auc.integral,4))
modt11<-c("Model11",round(t11_mat$overall[1],4),round(t11_mat$byClass[1],4),round(t11_mat$byClass[2],4)
          ,round(t11_mat$byClass[5],4),round(roct11$auc,4),round(prt11$auc.integral,4))
modt13<-c("Model13",round(t13_mat$overall[1],4),round(t13_mat$byClass[1],4),round(t13_mat$byClass[2],4)
          ,round(t13_mat$byClass[5],4),round(roct13$auc,4),round(prt13$auc.integral,4))
modt14<-c("Model14",round(t14_mat$overall[1],4),round(t14_mat$byClass[1],4),round(t14_mat$byClass[2],4)
          ,round(t14_mat$byClass[5],4),round(roct14$auc,4),round(prt14$auc.integral,4))
modt18<-c("Model18",round(t18_mat$overall[1],4),round(t18_mat$byClass[1],4),round(t18_mat$byClass[2],4)
          ,round(t18_mat$byClass[5],4),round(roct18$auc,4),round(prt18$auc.integral,4))
modt20<-c("Model20",round(t20_mat$overall[1],4),round(t20_mat$byClass[1],4),round(t20_mat$byClass[2],4)
          ,round(t20_mat$byClass[5],4),round(roct20$auc,4),round(prt20$auc.integral,4))
modt25<-c("Model25",round(t25_mat$overall[1],4),round(t25_mat$byClass[1],4),round(t25_mat$byClass[2],4)
          ,round(t25_mat$byClass[5],4),round(roct25$auc,4),round(prt25$auc.integral,4))
modt26<-c("Model26",round(t26_mat$overall[1],4),round(t26_mat$byClass[1],4),round(t26_mat$byClass[2],4)
          ,round(t26_mat$byClass[5],4),round(roct26$auc,4),round(prt26$auc.integral,4))
modt27<-c("Model27",round(t27_mat$overall[1],4),round(t27_mat$byClass[1],4),round(t27_mat$byClass[2],4)
          ,round(t27_mat$byClass[5],4),round(roct27$auc,4),round(prt27$auc.integral,4))


test13a<-predict.train(model13A, test, type = "prob")
test18a<-predict.train(model18A, test, type = "prob")
test20a<-predict.train(model20A, test, type = "prob")
test27a<-predict.train(model27A, test, type = "prob")

t13a<-ifelse(test13a$`1`<cutoff,0,1)
t13a_mat<-confusionMatrix(as.factor(t13a), test[!is.na(test$MonthsBehind & test$Income!=0),Judgement],positive="1")
roc13a<-roc(test[!is.na(test$MonthsBehind & test$Income!=0),Judgement],factor(test13a$`1`,ordered=T))
t18a<-ifelse(test18a$`1`<cutoff,0,1)
t18a_mat<-confusionMatrix(as.factor(t18a), test[!is.na(test$OwedPerIncomeBin),Judgement],positive="1")
roc18a<-roc(test[!is.na(test$OwedPerIncomeBin),Judgement],factor(test18a$`1`,ordered=T))
t20a<-ifelse(test20a$`1`<cutoff,0,1)
t20a_mat<-confusionMatrix(as.factor(t20a), test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement],positive="1")
roc20a<-roc(test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement],factor(test20a$`1`,ordered=T))
t27a<-ifelse(test27a$`1`<cutoff,0,1)
t27a_mat<-confusionMatrix(as.factor(t27a), test[!is.na(test$MonthsBehind),Judgement],positive="1")
roc27a<-roc(test[!is.na(test$MonthsBehind),Judgement],factor(test27a$`1`,ordered=T))

prt13a<-pr.curve(scores.class0=test13a$`1`,test13a$`0`,curve=T)
prt18a<-pr.curve(scores.class0=test18a$`1`,test18a$`0`,curve=T)
prt20a<-pr.curve(scores.class0=test20a$`1`,test20a$`0`,curve=T)
prt27a<-pr.curve(scores.class0=test27a$`1`,test27a$`0`,curve=T)

modt13a<-c("Model13A",round(t13a_mat$overall[1],4),round(t13a_mat$byClass[1],4),round(t13a_mat$byClass[2],4)
           ,round(t13a_mat$byClass[5],4),round(roc13a$auc,4),round(pr13a$auc.integral,4))
modt18a<-c("Model18A",round(t18a_mat$overall[1],4),round(t18a_mat$byClass[1],4),round(t18a_mat$byClass[2],4)
           ,round(t18a_mat$byClass[5],4),round(roc18a$auc,4),round(pr18a$auc.integral,4))
modt20a<-c("Model20A",round(t20a_mat$overall[1],4),round(t20a_mat$byClass[1],4),round(t20a_mat$byClass[2],4)
           ,round(t20a_mat$byClass[5],4),round(roc20a$auc,4),round(pr20a$auc.integral,4))
modt27a<-c("Model27A",round(t27a_mat$overall[1],4),round(t27a_mat$byClass[1],4),round(t27a_mat$byClass[2],4)
           ,round(t27a_mat$byClass[5],4),round(roc27a$auc,4),round(pr27a$auc.integral,4))


t13d<-ifelse(test13d$`evicted`<cutoff,0,1)
t13d_mat<-confusionMatrix(as.factor(t13d), test[test$Income!=0&!is.na(test$MonthsBehind),Judgement])
t13e<-ifelse(test13e$`evicted`<cutoff,0,1)
t13e_mat<-confusionMatrix(as.factor(t13e), test[test$Income!=0&!is.na(test$MonthsBehind),Judgement])
t13f<-ifelse(test13f$`evicted`<cutoff,0,1)
t13f_mat<-confusionMatrix(as.factor(t13f), test[test$Income!=0&!is.na(test$MonthsBehind),Judgement])
t13g<-ifelse(test13g$`evicted`<cutoff,0,1)
t13g_mat<-confusionMatrix(as.factor(t13g), test[test$Income!=0&!is.na(test$MonthsBehind),Judgement])
t13h<-ifelse(test13h$`evicted`<cutoff,0,1)
t13h_mat<-confusionMatrix(as.factor(t13h), test[test$Income!=0&!is.na(test$MonthsBehind),Judgement])
t13j<-ifelse(test13j$`evicted`<cutoff,0,1)
t13j_mat<-confusionMatrix(as.factor(t13j), test[test$Income!=0&!is.na(test$MonthsBehind),Judgement])

roct13d<-roc(test[test$Income!=0&!is.na(test$MonthsBehind),Judgement],factor(test13d$evicted,ordered=T))
prt13d<-pr.curve(scores.class0=test13d[test13d$act==1,"evicted"],scores.class1=test13d[test13d$act==0,"evicted"],curve=T)
roct13e<-roc(test[test$Income!=0&!is.na(test$MonthsBehind),Judgement],factor(test13e$evicted,ordered=T))
prt13e<-pr.curve(scores.class0=test13e[test13e$act==1,"evicted"],scores.class1=test13e[test13j$act==0,"evicted"],curve=T)
roct13f<-roc(test[test$Income!=0&!is.na(test$MonthsBehind),Judgement],factor(test13f$evicted,ordered=T))
prt13f<-pr.curve(scores.class0=test13f[test13f$act==1,"evicted"],scores.class1=test13f[test13f$act==0,"evicted"],curve=T)
roct13g<-roc(test[test$Income!=0&!is.na(test$MonthsBehind),Judgement],factor(test13g$evicted,ordered=T))
prt13g<-pr.curve(scores.class0=test13g[test13g$act==1,"evicted"],scores.class1=test13g[test13j$act==0,"evicted"],curve=T)
roct13h<-roc(test[test$Income!=0&!is.na(test$MonthsBehind),Judgement],factor(test13h$evicted,ordered=T))
prt13h<-pr.curve(scores.class0=test13h[test13h$act==1,"evicted"],scores.class1=test13h[test13j$act==0,"evicted"],curve=T)
roct13j<-roc(test[test$Income!=0&!is.na(test$MonthsBehind),Judgement],factor(test13j$evicted,ordered=T))
prt13j<-pr.curve(scores.class0=test13j[test13j$act==1,"evicted"],scores.class1=test13j[test13j$act==0,"evicted"],curve=T)


modt13d<-c("Model13D",round(t13d_mat$overall[1],4),round(t13d_mat$byClass[1],4),round(t13d_mat$byClass[2],4)
           ,round(t13d_mat$byClass[5],4),round(roct13d$auc,4),round(prt13d$auc.integral,4))
modt13e<-c("Model13E",round(t13e_mat$overall[1],4),round(t13e_mat$byClass[1],4),round(t13e_mat$byClass[2],4)
           ,round(t13e_mat$byClass[5],4),round(roct13e$auc,4),round(prt13e$auc.integral,4))
modt13f<-c("Model13F",round(t13f_mat$overall[1],4),round(t13f_mat$byClass[1],4),round(t13f_mat$byClass[2],4)
           ,round(t13f_mat$byClass[5],4),round(roct13f$auc,4),round(prt13f$auc.integral,4))
modt13g<-c("Model13G",round(t13g_mat$overall[1],4),round(t13g_mat$byClass[1],4),round(t13g_mat$byClass[2],4)
           ,round(t13g_mat$byClass[5],4),round(roct13g$auc,4),round(prt13g$auc.integral,4))
modt13h<-c("Model13H",round(t13h_mat$overall[1],4),round(t13h_mat$byClass[1],4),round(t13h_mat$byClass[2],4)
           ,round(t13h_mat$byClass[5],4),round(roct13h$auc,4),round(prt13h$auc.integral,4))
modt13j<-c("Model13J",round(t13j_mat$overall[1],4),round(t13j_mat$byClass[1],4),round(t13j_mat$byClass[2],4)
           ,round(t13j_mat$byClass[5],4),round(roct13j$auc,4),round(prt13j$auc.integral,4))


t18d<-ifelse(test18d$`evicted`<cutoff,0,1)
t18d_mat<-confusionMatrix(as.factor(t18d), test[test$Income!=0,Judgement])
t18e<-ifelse(test18e$`evicted`<cutoff,0,1)
t18e_mat<-confusionMatrix(as.factor(t18e), test[test$Income!=0,Judgement])
t18f<-ifelse(test18f$`evicted`<cutoff,0,1)
t18f_mat<-confusionMatrix(as.factor(t18f), test[test$Income!=0,Judgement])
t18g<-ifelse(test18g$`evicted`<cutoff,0,1)
t18g_mat<-confusionMatrix(as.factor(t18g), test[test$Income!=0,Judgement])
t18h<-ifelse(test18h$`evicted`<cutoff,0,1)
t18h_mat<-confusionMatrix(as.factor(t18h), test[test$Income!=0,Judgement])
t18j<-ifelse(test18j$`evicted`<cutoff,0,1)
t18j_mat<-confusionMatrix(as.factor(t18j), test[test$Income!=0,Judgement])

roct18d<-roc(test[test$Income!=0,Judgement],factor(test18d$evicted,ordered=T))
prt18d<-pr.curve(scores.class0=test18d[test18d$act==1,"evicted"],scores.class1=test18d[test18d$act==0,"evicted"],curve=T)
roct18e<-roc(test[test$Income!=0,Judgement],factor(test18e$evicted,ordered=T))
prt18e<-pr.curve(scores.class0=test18e[test18e$act==1,"evicted"],scores.class1=test18e[test18j$act==0,"evicted"],curve=T)
roct18f<-roc(test[test$Income!=0,Judgement],factor(test18f$evicted,ordered=T))
prt18f<-pr.curve(scores.class0=test18f[test18f$act==1,"evicted"],scores.class1=test18f[test18f$act==0,"evicted"],curve=T)
roct18g<-roc(test[test$Income!=0,Judgement],factor(test18g$evicted,ordered=T))
prt18g<-pr.curve(scores.class0=test18g[test18g$act==1,"evicted"],scores.class1=test18g[test18j$act==0,"evicted"],curve=T)
roct18h<-roc(test[test$Income!=0,Judgement],factor(test18h$evicted,ordered=T))
prt18h<-pr.curve(scores.class0=test18h[test18h$act==1,"evicted"],scores.class1=test18h[test18j$act==0,"evicted"],curve=T)
roct18j<-roc(test[test$Income!=0,Judgement],factor(test18j$evicted,ordered=T))
prt18j<-pr.curve(scores.class0=test18j[test18j$act==1,"evicted"],scores.class1=test18j[test18j$act==0,"evicted"],curve=T)


modt18d<-c("Model18D",round(t18d_mat$overall[1],4),round(t18d_mat$byClass[1],4),round(t18d_mat$byClass[2],4)
           ,round(t18d_mat$byClass[5],4),round(roct18d$auc,4),round(prt18d$auc.integral,4))
modt18e<-c("Model18E",round(t18e_mat$overall[1],4),round(t18e_mat$byClass[1],4),round(t18e_mat$byClass[2],4)
           ,round(t18e_mat$byClass[5],4),round(roct18e$auc,4),round(prt18e$auc.integral,4))
modt18f<-c("Model18F",round(t18f_mat$overall[1],4),round(t18f_mat$byClass[1],4),round(t18f_mat$byClass[2],4)
           ,round(t18f_mat$byClass[5],4),round(roct18f$auc,4),round(prt18f$auc.integral,4))
modt18g<-c("Model18G",round(t18g_mat$overall[1],4),round(t18g_mat$byClass[1],4),round(t18g_mat$byClass[2],4)
           ,round(t18g_mat$byClass[5],4),round(roct18g$auc,4),round(prt18g$auc.integral,4))
modt18h<-c("Model18H",round(t18h_mat$overall[1],4),round(t18h_mat$byClass[1],4),round(t18h_mat$byClass[2],4)
           ,round(t18h_mat$byClass[5],4),round(roct18h$auc,4),round(prt18h$auc.integral,4))
modt18j<-c("Model18J",round(t18j_mat$overall[1],4),round(t18j_mat$byClass[1],4),round(t18j_mat$byClass[2],4)
           ,round(t18j_mat$byClass[5],4),round(roct18j$auc,4),round(prt18j$auc.integral,4))


v20d<-ifelse(test20d$`evicted`<cutoff,0,1)
v20d_mat<-confusionMatrix(as.factor(v20d),test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement])
v20e<-ifelse(test20e$`evicted`<cutoff,0,1)
v20e_mat<-confusionMatrix(as.factor(v20e), test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement])
v20f<-ifelse(test20f$`evicted`<cutoff,0,1)
v20f_mat<-confusionMatrix(as.factor(v20f), test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement])
v20g<-ifelse(test20g$`evicted`<cutoff,0,1)
v20g_mat<-confusionMatrix(as.factor(v20g), test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement])
v20h<-ifelse(test20h$`evicted`<cutoff,0,1)
v20h_mat<-confusionMatrix(as.factor(v20h), test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement])
v20j<-ifelse(test20j$`evicted`<cutoff,0,1)
v20j_mat<-confusionMatrix(as.factor(v20j), test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement])

roct20d<-roc(test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement],factor(test20d$evicted,ordered=T))
prt20d<-pr.curve(scores.class0=test20d[test20d$act==1,"evicted"],scores.class1=test20d[test20d$act==0,"evicted"],curve=T)
roct20e<-roc(test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement],factor(test20e$evicted,ordered=T))
prt20e<-pr.curve(scores.class0=test20e[test20e$act==1,"evicted"],scores.class1=test20e[test20j$act==0,"evicted"],curve=T)
roct20f<-roc(test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement],factor(test20f$evicted,ordered=T))
prt20f<-pr.curve(scores.class0=test20f[test20f$act==1,"evicted"],scores.class1=test20f[test20f$act==0,"evicted"],curve=T)
roct20g<-roc(test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement],factor(test20g$evicted,ordered=T))
prt20g<-pr.curve(scores.class0=test20g[test20g$act==1,"evicted"],scores.class1=test20g[test20j$act==0,"evicted"],curve=T)
roct20h<-roc(test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement],factor(test20h$evicted,ordered=T))
prt20h<-pr.curve(scores.class0=test20h[test20h$act==1,"evicted"],scores.class1=test20h[test20j$act==0,"evicted"],curve=T)
roct20j<-roc(test[!is.na(test$MonthsBehind)&!is.na(test$Income),Judgement],factor(test20j$evicted,ordered=T))
prt20j<-pr.curve(scores.class0=test20j[test20j$act==1,"evicted"],scores.class1=test20j[test20j$act==0,"evicted"],curve=T)


modt20d<-c("Model20D",round(v20d_mat$overall[1],4),round(v20d_mat$byClass[1],4),round(v20d_mat$byClass[2],4)
           ,round(v20d_mat$byClass[5],4),round(roct20d$auc,4),round(prt20d$auc.integral,4))
modt20e<-c("Model20E",round(v20e_mat$overall[1],4),round(v20e_mat$byClass[1],4),round(v20e_mat$byClass[2],4)
           ,round(v20e_mat$byClass[5],4),round(roct20e$auc,4),round(prt20e$auc.integral,4))
modt20f<-c("Model20F",round(v20f_mat$overall[1],4),round(v20f_mat$byClass[1],4),round(v20f_mat$byClass[2],4)
           ,round(v20f_mat$byClass[5],4),round(roct20f$auc,4),round(prt20f$auc.integral,4))
modt20g<-c("Model20G",round(v20g_mat$overall[1],4),round(v20g_mat$byClass[1],4),round(v20g_mat$byClass[2],4)
           ,round(v20g_mat$byClass[5],4),round(roct20g$auc,4),round(prt20g$auc.integral,4))
modt20h<-c("Model20H",round(v20h_mat$overall[1],4),round(v20h_mat$byClass[1],4),round(v20h_mat$byClass[2],4)
           ,round(v20h_mat$byClass[5],4),round(roct20h$auc,4),round(prt20h$auc.integral,4))
modt20j<-c("Model20J",round(v20j_mat$overall[1],4),round(v20j_mat$byClass[1],4),round(v20j_mat$byClass[2],4)
           ,round(v20j_mat$byClass[5],4),round(roct20j$auc,4),round(prt20j$auc.integral,4))

t27d<-ifelse(test27d$`evicted`<cutoff,0,1)
t27d_mat<-confusionMatrix(as.factor(t27d), test[!is.na(test$MonthsBehind),Judgement])
t27e<-ifelse(test27e$`evicted`<cutoff,0,1)
t27e_mat<-confusionMatrix(as.factor(t27e), test[!is.na(test$MonthsBehind),Judgement])
t27f<-ifelse(test27f$`evicted`<cutoff,0,1)
t27f_mat<-confusionMatrix(as.factor(t27f), test[!is.na(test$MonthsBehind),Judgement])
t27g<-ifelse(test27g$`evicted`<cutoff,0,1)
t27g_mat<-confusionMatrix(as.factor(t27g), test[!is.na(test$MonthsBehind),Judgement])
t27h<-ifelse(test27h$`evicted`<cutoff,0,1)
t27h_mat<-confusionMatrix(as.factor(t27h), test[!is.na(test$MonthsBehind),Judgement])
t27j<-ifelse(test27j$`evicted`<cutoff,0,1)
t27j_mat<-confusionMatrix(as.factor(t27j), test[!is.na(test$MonthsBehind),Judgement])

roct27d<-roc(test[!is.na(test$MonthsBehind),Judgement],factor(test27d$evicted,ordered=T))
prt27d<-pr.curve(scores.class0=test27d[test27d$act==1,"evicted"],scores.class1=test27d[test27d$act==0,"evicted"],curve=T)
roct27e<-roc(test[!is.na(test$MonthsBehind),Judgement],factor(test27e$evicted,ordered=T))
prt27e<-pr.curve(scores.class0=test27e[test27e$act==1,"evicted"],scores.class1=test27e[test27j$act==0,"evicted"],curve=T)
roct27f<-roc(test[!is.na(test$MonthsBehind),Judgement],factor(test27f$evicted,ordered=T))
prt27f<-pr.curve(scores.class0=test27f[test27f$act==1,"evicted"],scores.class1=test27f[test27f$act==0,"evicted"],curve=T)
roct27g<-roc(test[!is.na(test$MonthsBehind),Judgement],factor(test27g$evicted,ordered=T))
prt27g<-pr.curve(scores.class0=test27g[test27g$act==1,"evicted"],scores.class1=test27g[test27j$act==0,"evicted"],curve=T)
roct27h<-roc(test[!is.na(test$MonthsBehind),Judgement],factor(test27h$evicted,ordered=T))
prt27h<-pr.curve(scores.class0=test27h[test27h$act==1,"evicted"],scores.class1=test27h[test27j$act==0,"evicted"],curve=T)
roct27j<-roc(test[!is.na(test$MonthsBehind),Judgement],factor(test27j$evicted,ordered=T))
prt27j<-pr.curve(scores.class0=test27j[test27j$act==1,"evicted"],scores.class1=test27j[test27j$act==0,"evicted"],curve=T)


modt27d<-c("Model27D",round(t27d_mat$overall[1],4),round(t27d_mat$byClass[1],4),round(t27d_mat$byClass[2],4)
           ,round(t27d_mat$byClass[5],4),round(roct27d$auc,4),round(prt27d$auc.integral,4))
modt27e<-c("Model27E",round(t27e_mat$overall[1],4),round(t27e_mat$byClass[1],4),round(t27e_mat$byClass[2],4)
           ,round(t27e_mat$byClass[5],4),round(roct27e$auc,4),round(prt27e$auc.integral,4))
modt27f<-c("Model27F",round(t27f_mat$overall[1],4),round(t27f_mat$byClass[1],4),round(t27f_mat$byClass[2],4)
           ,round(t27f_mat$byClass[5],4),round(roct27f$auc,4),round(prt27f$auc.integral,4))
modt27g<-c("Model27G",round(t27g_mat$overall[1],4),round(t27g_mat$byClass[1],4),round(t27g_mat$byClass[2],4)
           ,round(t27g_mat$byClass[5],4),round(roct27g$auc,4),round(prt27g$auc.integral,4))
modt27h<-c("Model27H",round(t27h_mat$overall[1],4),round(t27h_mat$byClass[1],4),round(t27h_mat$byClass[2],4)
           ,round(t27h_mat$byClass[5],4),round(roct27h$auc,4),round(prt27h$auc.integral,4))
modt27j<-c("Model27J",round(t27j_mat$overall[1],4),round(t27j_mat$byClass[1],4),round(t27j_mat$byClass[2],4)
           ,round(t27j_mat$byClass[5],4),round(roct27j$auc,4),round(prt27j$auc.integral,4))


eval_test<-data.frame(
  Model=character(),
  Accuracy=numeric(),
  Sensitivity=numeric(),  #Sensitivity = Recall
  Specificity=numeric(),
  Precision=numeric(),
  ROC_AUC=numeric(),
  PR_AUC=numeric(),
  stringsAsFactors = F)

eval_test[nrow(eval_test)+1,]<-modt04
eval_test<-rbind(eval_test,modt07,modt11,modt13,modt14,modt18,modt20,modt25,modt26,modt27)
eval_test<-rbind(eval_test,modt13a,modt18a,modt20a,modt27a)
eval_test<-rbind(eval_test,modt13d,modt13e,modt13f,modt13g,modt13h,modt13j)
eval_test<-rbind(eval_test,modt18d,modt18e,modt18f,modt18g,modt18h,modt18j)
eval_test<-rbind(eval_test,modt20d,modt20e,modt20f,modt20g,modt20h,modt20j)
eval_test<-rbind(eval_test,modt27d,modt20e,modt27f,modt27g,modt27h,modt27j)

#write.csv(eval_test, file = "test_eval.csv",row.names=FALSE)
