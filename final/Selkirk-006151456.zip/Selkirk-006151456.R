
library(tidyverse)
library(stringr)
library(tidyr)
library(dplyr)
library(vcd)
library(ggplot2)
library(plyr)
library(aod)
library (caTools)
library(broom) 
library(caret)
library(blorr)
library(ROCR)
library(pscl)
library(survey)

#Load data and remove unwanted columns
new_data <- read.delim2("PartD_Prescriber_PUF_NPI_Drug_16.txt")
new_data <- subset(new_data, select=-c(1:4, 7, 9, 10, 12, 13, 15:21))

#Remove all but 3 drugs
ibu_vs_oxy_data <- subset(new_data, new_data$drug_name == "OXYCODONE HCL" | 
                            new_data$drug_name == "OXYCODONE-ACETAMINOPHEN" |
                            new_data$drug_name == "IBUPROFEN")

#Change the Name and change to factor variable
ibu_vs_oxy_data$drug_name <- revalue(ibu_vs_oxy_data$drug_name, c("OXYCODONE HCL"="OXYCODONE", "OXYCODONE-ACETAMINOPHEN"="OXYCODONE"))
ibu_vs_oxy_data$drug_name <- as.factor(ibu_vs_oxy_data$drug_name)

#Remove unwanted states
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "AE")
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "AP")
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "GU")
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "VI")
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "MP")
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "AA")
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "ZZ")
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "XX")
ibu_vs_oxy_data <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$nppes_provider_state != "AS")

ibu_vs_oxy_data_spec <- subset(ibu_vs_oxy_data, ibu_vs_oxy_data$specialty_description == "Family Practice" |
                                 ibu_vs_oxy_data$specialty_description == "Internal Medicine" |
                                 ibu_vs_oxy_data$specialty_description == "Nurse Practitioner" |
                                 ibu_vs_oxy_data$specialty_description == "Physician Assistant" |
                                 ibu_vs_oxy_data$specialty_description == "Physical Medicine and Rehabilitation" |
                                 ibu_vs_oxy_data$specialty_description == "Orthopedic Surgery" |
                                 ibu_vs_oxy_data$specialty_description == "Anesthesiology" |
                                 ibu_vs_oxy_data$specialty_description == "Pain Management" |
                                 ibu_vs_oxy_data$specialty_description == "Interventional Pain Management" |
                                 ibu_vs_oxy_data$specialty_description == "Dentist" |
                                 ibu_vs_oxy_data$specialty_description == "General Practice" |
                                 ibu_vs_oxy_data$specialty_description == "Oral Surgery (Dentists Only)" |
                                 ibu_vs_oxy_data$specialty_description == "Rheumatology" |
                                 ibu_vs_oxy_data$specialty_description == "Emergency Medicine" )

#Convert Dataset to CSV
write.csv(ibu_vs_oxy_data_spec,"PartD_Prescriber_PUF_NPI_Drug_16.csv", row.names = FALSE)

#split data into train and test set
set.seed(123)
dt <- sort(sample(nrow(ibu_vs_oxy_data_spec), nrow(ibu_vs_oxy_data_spec)*.7))
train<-ibu_vs_oxy_data_spec[dt,]
test<-ibu_vs_oxy_data_spec[-dt,]

#Run logit model
logitmodel <- glm(formula = drug_name ~ total_claim_count + specialty_description + nppes_provider_state, family = "binomial",
                  data = train)

summary(logitmodel)

#Get coefficients of the model
exp(coef(logitmodel))


caret::varImp(logitmodel)


#Look for psuedo R^2
blr_rsq_mcfadden(logitmodel)

pR2(logitmodel)

#Test the model using test dataset
test.predicted <- predict(logitmodel, newdata = test, type = "response")

table(test$drug_name, test.predicted > 0.5) %>% prop.table() %>% round(3)

prediction(test.predicted, test$drug_name) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()

prediction(test.predicted, test$drug_name) %>%
  performance(measure = "auc") %>%
  .@y.values


#Cross validation
ctrl <- trainControl(method = "repeatedcv", number = 10, savePredictions = TRUE)

mod_fit <- train(drug_name ~ total_claim_count + specialty_description + nppes_provider_state,
                 data=ibu_vs_oxy_data_spec, method="glm", family="binomial",
                 trControl = ctrl, tuneLength = 5)

mod_fit$resample

pred <- predict(logitmodel, newdata=test)
confusionMatrix(data=pred, test$drug_name)



