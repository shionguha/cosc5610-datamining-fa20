#Data Mining Project
#Online Shopper's Purchasing Intension
#Logistic Regression Modeling
#Project By: AISHWARYA SANGANALU MATTHA
#MUID: 006193330
#Submission Date: 12/09/2020

rm(list = ls())

#Import libraries
library(tidyverse)
library(corrplot)
library(modelr)     # provides easy pipeline modeling functions
library(caret)
library(DMwR) # for smote implementation
library(purrr) # for functional programming (map)
library(pROC) # for AUC calculations

#Load input data file
data <- read.csv("SanganaluMattha-006193330.csv", header = TRUE)
sparedata <- data

str(data)

## DATA PREPROCESSING
#check missing values in the dataset
sum(is.na(data))

#fix the structure of data
data$Revenue <- ifelse(data$Revenue == 'TRUE', 1, 0)
data$Weekend <- ifelse(data$Weekend == 'TRUE', 1, 0)
data$Month <- as.factor(data$Month)
data$OperatingSystems <- as.factor(data$OperatingSystems)
data$Browser <- as.factor(data$Browser)
data$Region <- as.factor(data$Region)
data$TrafficType <- as.factor(data$TrafficType)
data$VisitorType <- as.factor(data$VisitorType)
summary(data)

#testmodel <- glm(Revenue ~ Weekend, family = "binomial", data = data)
#summary(testmodel)

#Correlation plot
data1 <- data
data1[-c(7,8)] <- lapply(data1[-c(7,8)], as.double)
cor(data1)
corrplot(cor(data1)) #, method = "number"
#== With respect to our Predictor variable 'Revenue'
#==We can see that there is a high correlation of PageValues with Revenue(predictor variable) => Model 1
#==p-value < 0.05 for Administrative, Administrative_Duration, Informational, Informational_Duration, ProductRelated, ProductRelated_Duration => Model 2
#==Consider all variables for modelling => Model 3


#Split data 
set.seed(1)
sample <- sample(c(TRUE, FALSE), nrow(data), replace = T, prob = c(0.6,0.4))
train_data <- data[sample, ]
test_data <- data[!sample, ]


# MODEL 1
#Considering 'PageValues' only
model1 <- glm(Revenue ~ PageValues, family = "binomial", data = train_data)
summary(model1)

#Model1 residual plot
library(broom)
library(pscl)
model1_data <- augment(model1) %>% 
  mutate(index = 1:n())

ggplot(model1_data, aes(index, .std.resid, color = Revenue)) + 
  geom_point(alpha = .5) +
  geom_ref_line(h = 3)

hist(model1_data$.std.resid,breaks=25,xlab="Residuals",main = "Model 1 Residuals Histogram")


# MODEL 2
#Considering Administrative, Administrative_Duration, Informational, Informational_Duration, ProductRelated, ProductRelated_Duration
model2 <- glm(Revenue ~ Administrative + Administrative_Duration + Informational + Informational_Duration + ProductRelated + ProductRelated_Duration, 
              family = "binomial", data = train_data)
summary(model2)

#Model2 residual plot
model2_data <- augment(model2) %>% 
  mutate(index = 1:n())

ggplot(model2_data, aes(index, .std.resid, color = Revenue)) + 
  geom_point(alpha = .5) +
  geom_ref_line(h = 3)

hist(model2_data$.std.resid,breaks=25,xlab="Residuals",main = "Model 2 Residuals Histogram")


# MODEL 3
#Considering all variables
model3 <- glm(Revenue ~ ., family = "binomial", data = train_data)
summary(model3)

#Model3 residual plot
model3_data <- augment(model3) %>% 
  mutate(index = 1:n())

model3_data <- na.omit(model3_data)
ggplot(model3_data, aes(index, .std.resid, color = Revenue)) + 
  geom_point(alpha = .5) +
  geom_ref_line(h = 3)

hist(model3_data$.std.resid,breaks=25,xlab="Residuals",main = "Model 3 Residuals Histogram")



#Odds Ratio
caret::varImp(model2)
caret::varImp(model2)
caret::varImp(model3)

#model fit and diagnostics
anova(model1, model2, model3, test = "Chisq")
#== Model 3 deviance is lower and is statistically significant (p<0.05), Therefore model3 is better with all variables as predictors

library(pscl)

list(model1 = pscl::pR2(model1)["McFadden"],
     model2 = pscl::pR2(model2)["McFadden"],
     model3 = pscl::pR2(model3)["McFadden"])
#==Model3 has higher McFadden's R^2, and is closer to 0.5



#model validation
test.predicted.m1 <- predict(model1, newdata = test_data, type = "response")
test.predicted.m2 <- predict(model2, newdata = test_data, type = "response")
test.predicted.m3 <- predict(model3, newdata = test_data, type = "response")

list(
  model1 = table(test_data$Revenue, test.predicted.m1 > 0.5) %>% prop.table() %>% round(3),
  model2 = table(test_data$Revenue, test.predicted.m2 > 0.5) %>% prop.table() %>% round(3),
  model3 = table(test_data$Revenue, test.predicted.m3 > 0.5) %>% prop.table() %>% round(3)
)


test_data %>%
  mutate(m1.pred = ifelse(test.predicted.m1 > 0.5, 1, 0),
         m2.pred = ifelse(test.predicted.m2 > 0.5, 1, 0),
         m3.pred = ifelse(test.predicted.m3 > 0.5, 1, 0)) %>%
  summarise(m1.error = mean(Revenue != m1.pred),
            m2.error = mean(Revenue != m2.pred),
            m3.error = mean(Revenue != m3.pred))


#AUC
library(ROCR)

par(mfrow=c(1, 3))

prediction(test.predicted.m1, test_data$Revenue) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()

prediction(test.predicted.m2, test_data$Revenue) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()

prediction(test.predicted.m3, test_data$Revenue) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()

# model 1 AUC
prediction(test.predicted.m1, test_data$Revenue) %>%
  performance(measure = "auc") %>%
  .@y.values

# model 2 AUC
prediction(test.predicted.m2, test_data$Revenue) %>%
  performance(measure = "auc") %>%
  .@y.values

# model 3 AUC
prediction(test.predicted.m3, test_data$Revenue) %>%
  performance(measure = "auc") %>%
  .@y.values



# CROSS VALIDATION
# compute the R2, RMSE and MAE
errors <- data.frame( R2 = R2(test.predicted.m1   , test_data$Revenue),
            RMSE = RMSE(test.predicted.m1   , test_data$Revenue),
            MAE = MAE(test.predicted.m1   , test_data$Revenue),
            PredictionErrorRate = RMSE(test.predicted.m1   , test_data$Revenue)/mean(test_data$Revenue))
errors <- rbind(errors, c(R2(test.predicted.m2, test_data$Revenue), 
                          RMSE(test.predicted.m2, test_data$Revenue), 
                          MAE(test.predicted.m1, test_data$Revenue),
                          RMSE(test.predicted.m2, test_data$Revenue)/mean(test_data$Revenue)))

errors <- rbind(errors, c(R2(test.predicted.m3, test_data$Revenue), 
                          RMSE(test.predicted.m3, test_data$Revenue), 
                          MAE(test.predicted.m3, test_data$Revenue),
                          RMSE(test.predicted.m3, test_data$Revenue)/mean(test_data$Revenue)))
errors


#LOO
cv_data <- sparedata
cv_data$Revenue <- as.factor(cv_data$Revenue)
# Define training control
train.control <- trainControl(method = "LOOCV")
# Train the model
model1_LOO <- train(Revenue ~ PageValues, data = cv_data, method = "glm",
               trControl = train.control)

model2_LOO <- train(Revenue ~ Administrative + Administrative_Duration + Informational + Informational_Duration + ProductRelated + ProductRelated_Duration, 
                    data = cv_data, method = "glm", trControl = train.control)

model3_LOO <- train(Revenue ~ ., data = cv_data, method = "glm",
                    trControl = train.control)

LOO <- cbind(Model1 = model1_LOO[["results"]][["Accuracy"]], Model2 = model2_LOO[["results"]][["Accuracy"]], Model3 = model3_LOO[["results"]][["Accuracy"]])



# K-fold CV
set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)

model1_kfold <- train(Revenue ~ PageValues, data = cv_data, method = "glm",
                    trControl = train.control)

model2_kfold <- train(Revenue ~ Administrative + Administrative_Duration + Informational + Informational_Duration + ProductRelated + ProductRelated_Duration, 
                    data = cv_data, method = "glm", trControl = train.control)

model3_kfold <- train(Revenue ~ ., data = cv_data, method = "glm",
                    trControl = train.control)

kfold <- cbind(Model1 = model1_kfold[["results"]][["Accuracy"]], Model2 = model2_kfold[["results"]][["Accuracy"]], Model3 = model3_kfold[["results"]][["Accuracy"]])



#Repeated k-fold CV
set.seed(123) 
train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3)

model1_kfold_r <- train(Revenue ~ PageValues, data = cv_data, method = "glm",
                      trControl = train.control)

model2_kfold_r <- train(Revenue ~ Administrative + Administrative_Duration + Informational + Informational_Duration + ProductRelated + ProductRelated_Duration, 
                      data = cv_data, method = "glm", trControl = train.control)

model3_kfold_r <- train(Revenue ~ ., data = cv_data, method = "glm",
                      trControl = train.control)

kfold_r <- cbind(Model1 = model1_kfold_r[["results"]][["Accuracy"]], Model2 = model2_kfold_r[["results"]][["Accuracy"]], Model3 = model3_kfold_r[["results"]][["Accuracy"]])


#Creating table for LOO, kfold, kfold-repeated
crossvalidation <- (rbind("LOO" = LOO, "K-Fold" = kfold, "Repeated K-Fold" = kfold_r))
row.names(crossvalidation) <-  c("LOO", "K-fold", "Repeated K-fold")
crossvalidation


#CLASS IMBALANCE

train_ci <- train_data
test_ci <- test_data

train_ci$Revenue <- ifelse(train_ci$Revenue == 1, "yes", "no")
test_ci$Revenue <- ifelse(test_ci$Revenue == 1, "yes", "no")
#train_ci$Revenue <- as.factor(train_ci$Revenue)

# Set up control function for training
ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = twoClassSummary,
                     classProbs = TRUE)

set.seed(99)


#Original fit
orig_fit <- train(Revenue ~ .,
                  data = train_ci,
                  method = "glm")

#Weighted model

model_weights <- ifelse(train_ci$Revenue == "no",
                        (1/table(train_ci$Revenue)[1]) * 0.5,
                        (1/table(train_ci$Revenue)[2]) * 0.5)

# Use the same seed to ensure same cross-validation splits

ctrl$seeds <- model3$control$seeds

# Build weighted model

weighted_fit <- train(Revenue ~ .,
                      data = train_ci,
                      method = "glm",
                      weights = model_weights,
                      metric = "ROC",
                      trControl = ctrl)


# Build down-sampled model

ctrl$sampling <- "down"

down_fit <- train(Revenue ~ .,
                  data = train_ci,
                  method = "glm",
                  metric = "ROC",
                  trControl = ctrl)


# Build up-sampled model

ctrl$sampling <- "up"

up_fit <- train(Revenue ~ .,
                data = train_ci,
                method = "glm",
                metric = "ROC",
                trControl = ctrl)


# Build smote model

ctrl$sampling <- "smote"

smote_fit <- train(Revenue ~ .,
                   data = train_ci,
                   method = "glm",
                   metric = "ROC",
                   trControl = ctrl)


# Build custom AUC function to extract AUC
test_roc <- function(model, data) {
  
  roc(data$Revenue,
      predict(model, data, type = "prob")[, "yes"])
  
}


# Examine results for test set

model_list <- list(original = orig_fit,
                   weighted = weighted_fit,
                   down = down_fit,
                   up = up_fit,
                   SMOTE = smote_fit)

model_list_roc <- model_list %>%
  map(test_roc, data = test_ci)

model_list_roc %>%
  map(auc)

results_list_roc <- list(NA)
num_mod <- 1

for(the_roc in model_list_roc){
  
  results_list_roc[[num_mod]] <- 
    data_frame(tpr = the_roc$sensitivities,
               fpr = 1 - the_roc$specificities,
               model = names(model_list)[num_mod])
  
  num_mod <- num_mod + 1
  
}

results_df_roc <- bind_rows(results_list_roc)

# Plot ROC curve for all 5 models

custom_col <- c("#000000", "#009E73", "#0072B2", "#D55E00", "#CC79A7")

ggplot(aes(x = fpr,  y = tpr, group = model), data = results_df_roc) +
  geom_line(aes(color = model), size = 1) +
  scale_color_manual(values = custom_col) +
  geom_abline(intercept = 0, slope = 1, color = "gray", size = 1) +
  theme_bw(base_size = 18)


#prediction resolving class imbalance
test.predicted.m3.orig <- predict(orig_fit, newdata = test_ci, type = "prob")[, "yes"]
test.predicted.m3.downsample <- predict(down_fit, newdata = test_ci, type = "prob")[, "yes"]
# test.predicted.m3.upsample <- predict(up_fit, newdata = test_ci, type = "prob")[, "yes"]
# test.predicted.m3.weighted <- predict(weighted_fit, newdata = test_ci, type = "prob")[, "yes"]
# test.predicted.m3.smote <- predict(smote_fit, newdata = test_ci, type = "prob")[, "yes"]

errors.ci <- data.frame( R2 = R2(test.predicted.m3.downsample   , test_data$Revenue),
                      RMSE = RMSE(test.predicted.m3.downsample   , test_data$Revenue),
                      MAE = MAE(test.predicted.m3.downsample   , test_data$Revenue),
                      PredictionErrorRate = RMSE(test.predicted.m3.downsample   , test_data$Revenue)/mean(test_data$Revenue))


errors.ci <- rbind(errors.ci, c( R2 = R2(test.predicted.m3.orig   , test_data$Revenue),
                                                 RMSE = RMSE(test.predicted.m3.orig   , test_data$Revenue),
                                                 MAE = MAE(test.predicted.m3.orig   , test_data$Revenue),
                                                 PredictionErrorRate = RMSE(test.predicted.m3.orig   , test_data$Revenue)/mean(test_data$Revenue)))
errors.ci

row.names(errors.ci) <-  c("Down-sampled data", "Original Data")
errors.ci


