library(dplyr)
library(ggplot2)
library(usmap)
library(tidyverse)
library(caTools)
library(mlbench)
library(MASS)
library(pROC)
library(cowplot)
library(pROC)
library(arm)
library(VGAM)
library(caret)
library(boot)
library(pscl)

district.2017.03.15 <- read.csv("district.2017.03.15.csv")
# df <- read.csv("district.2017.03.15.csv")
df <- district.2017.03.15
# extract public school columns 
df_public <- data.frame(df$pupMONEY_reg, df$hasCounc_reg, df$puptch_reg, df$TEACH_FYSY_RATIO_reg, df$TEACH_ABSENT_RATIO_reg, df$gradRate_reg)

# extract alternative school columns 
df_alt <- data.frame(df$pupMONEY_alt, df$hasCounc_alt, df$puptch_alt, df$TEACH_FYSY_RATIO_alt, df$TEACH_ABSENT_RATIO_alt, df$gradRate_alt)

# add in binary column to public schools dataset with all 1's
df_public$is_public = 1

# add in binary column to alt schools dataset with all 0's 
df_alt$is_public = 0

#rename columns 
df_public <- df_public %>% rename(per_pupil_funding = `df.pupMONEY_reg`, 
                                  percent_has_counselor = `df.hasCounc_reg`,
                                  avg_student_teach_ratio = `df.puptch_reg`,
                                  fysy_ratio = `df.TEACH_FYSY_RATIO_reg`,
                                  teach_absent_ratio = `df.TEACH_ABSENT_RATIO_reg`,
                                  grad_rate = `df.gradRate_reg`
)

#rename columns 
df_alt <- df_alt %>% rename(per_pupil_funding = `df.pupMONEY_alt`, 
                            percent_has_counselor = `df.hasCounc_alt`,
                            avg_student_teach_ratio = `df.puptch_alt`,
                            fysy_ratio = `df.TEACH_FYSY_RATIO_alt`,
                            teach_absent_ratio = `df.TEACH_ABSENT_RATIO_alt`,
                            grad_rate = `df.gradRate_alt`)

# merge the two dataframes 
df_total <- rbind(df_public, df_alt)

#convert column to binary 
df_total$is_public <- as.factor(df_total$is_public)
prop.table(table(df_total$is_public))
# how many of these cases are complete? 
comp <- complete.cases(df_total)
summary(comp)

df_omit <- na.omit(df_total)
prop.table(table(df_omit$is_public))

#################################################################


df_omit <- df_total
df_omit <- na.omit(df_total)

#shuffle it all around
df_omit <- df_omit[sample(nrow(df_omit)),]

# split into test and train 
split = sample.split(df_omit$is_public, SplitRatio = 0.75)
train = subset(df_omit, split == TRUE)
test = subset(df_omit, split == FALSE)

#sample <- sample(c(TRUE, FALSE), nrow(df_omit), replace = T, prob = c(0.7,0.3))
#train <- df_omit[sample, ]
#test <- df_omit[!sample, ]

mylogit1 <- glm(is_public ~ ., data = train, family = binomial)
summary(mylogit)
# based on this, fet rid of avg_student_teacher_ratio and absent ratio

mylogit1 <- glm(is_public ~ grad_rate + per_pupil_funding, data = train, family = binomial)

mylogit2 <- glm(is_public ~ grad_rate + per_pupil_funding + fysy_ratio, data = train, family = binomial)

mylogit3 <- glm(is_public ~ grad_rate + per_pupil_funding + fysy_ratio + percent_has_counselor, data = train, family = binomial)

predicted <- data.frame(probability.of.is_public=mylogit3$fitted.values, is_public=train$is_public)
predicted <- predicted[order(predicted$probability.of.is_public, decreasing = FALSE),]
#create number associated with that list, in ascending order, so the lower rank has the lowest prob of being public
predicted$rank<- 1:nrow(predicted)

# plot logistic regression 
ggplot(data=predicted, aes(x=rank,y=probability.of.is_public))+
  geom_point(aes(color=is_public), alpha=1, shape=4, stroke=2) +
  xlab("Index") +
  ylab("Predicted probability of school district data corresponding to public schools")

#likihood ratio test
anova(mylogit3, test = "LRT")

library(lmtest)
lrtest(mylogit1, mylogit2)
# Pseudo R squared 
#pull out the log-liklihood of the null model, get null deviance and devide by -2
ll.null.m1 <- mylogit1$null.deviance/-2
#pull log liklihood of model by taking residual deviance and dividing by negative two
ll.proposed.m1 <- mylogit1$deviance/-2
pseudoR2.m1 <- (ll.null.m1 - ll.proposed.m1) / ll.null.m1

# Pseudo R squared 
ll.null.m2 <- mylogit2$null.deviance/-2
ll.proposed.m2 <- mylogit2$deviance/-2
pseudoR2.m2 <- (ll.null.m2 - ll.proposed.m2) / ll.null.m2

# Pseudo R squared 
ll.null.m3 <- mylogit3$null.deviance/-2
ll.proposed.m3 <- mylogit3$deviance/-2
pseudoR2.m3 <- (ll.null.m3 - ll.proposed.m3) / ll.null.m3


model1_data <- augment(mylogit1) %>% 
  mutate(index = 1:n())

ggplot(model1_data, aes(index, .std.resid, color = is_public)) + 
  geom_point(alpha = .5)

plot(mylogit1, which = 4, id.n = 5)

model1_data %>% 
  top_n(5, .cooksd)

predicted.m1 <- predict(mylogit1, newdata = test, type = "response")
predicted.m2 <- predict(mylogit2, newdata = test, type = "response")
predicted.m3 <- predict(mylogit3, newdata = test, type = "response")


list(
  mylogit1 = table(test$is_public, predicted.m1 > 0.5) %>% prop.table() %>% round(3),
  mylogit2 = table(test$is_public, predicted.m2 > 0.5) %>% prop.table() %>% round(3),
  mylogit3 = table(test$is_public, predicted.m3 > 0.5) %>% prop.table() %>% round(3)
)

test %>%
  mutate(m1.pred = ifelse(predicted.m1 > 0.5, "Yes", "No"),
         m2.pred = ifelse(predicted.m2 > 0.5, "Yes", "No"),
         m3.pred = ifelse(predicted.m3 > 0.5, "Yes", "No")) %>%
  summarise(m1.error = mean(is_public != m1.pred),
            m2.error = mean(is_public != m2.pred),
            m3.error = mean(is_public != m3.pred))

table(test$is_public, predicted.m1 > 0.5)
table(test$is_public, predicted.m2 > 0.5)
table(test$is_public, predicted.m3 > 0.5)

#################################################################################

df_omit <- df_total
df_omit <- na.omit(df_total)

#shuffle it all around
df_omit <- df_omit[sample(nrow(df_omit)),]

# split into test and train 
set.seed(536)
split = sample.split(df_omit$is_public, SplitRatio = 0.75)
train = subset(df_omit, split == TRUE)
test = subset(df_omit, split == FALSE)

mylogit3 <- glm(is_public ~ grad_rate + per_pupil_funding + fysy_ratio + percent_has_counselor, data = train, family = binomial)
pred = predict(mylogit3, newdata=test)

#confusionMatrix(data=pred, test$is_public)

# repeated cv
set.seed(352)
ctrl1 <- trainControl(method = "repeatedcv", number = 10, savePredictions = TRUE)

mod_fit1 <- train(is_public ~ grad_rate + per_pupil_funding + fysy_ratio + percent_has_counselor,
                  data=df_omit, method="glm", family="binomial", 
                  trControl = ctrl1, tuneLength = 5)

pred1 = predict(mod_fit1, newdata=test)
confusionMatrix(data=pred1, test$is_public)

## CV 
ctrl2 <- trainControl(method = "cv", number = 10)
mod_fit2 <- train(is_public ~ grad_rate + per_pupil_funding + fysy_ratio + percent_has_counselor,
                  data=df_omit, method="glm", family="binomial", 
                  trControl = ctrl2, tuneLength = 5)

pred2 = predict(mod_fit2, newdata=test)
confusionMatrix(data=pred2, test$is_public)


## LOOCV
ctrl3 <- trainControl(method = "LOOCV", number = 10)

mod_fit3 <- train(is_public ~ grad_rate + per_pupil_funding + fysy_ratio + percent_has_counselor,
                  data=df_omit, method="glm", family="binomial", 
                  trControl = ctrl3, tuneLength = 5)

pred3 = predict(mod_fit3, newdata=test)
confusionMatrix(data=pred3, test$is_public)

#########################################################################################
df_omit <- df_total
df_omit <- na.omit(df_total)

#shuffle it all around
df_omit <- df_omit[sample(nrow(df_omit)),]

# split into test and train 
set.seed(536)
split = sample.split(df_omit$is_public, SplitRatio = 0.75)
imbal_train = subset(df_omit, split == TRUE)
imbal_test = subset(df_omit, split == FALSE)


#######################################################
# Original model
ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 3)

orig_fit <- train(is_public ~ grad_rate + per_pupil_funding + 
                    fysy_ratio + percent_has_counselor,
                  data=imbal_train, method="glm", family="binomial", 
                  trControl = ctrl)

pred_orig = predict(orig_fit, newdata=imbal_test, type = "prob")


############################################################
# weighted model 
model_weights = ifelse(imbal_train$is_public == 1,
                       (1/table(imbal_train$is_public)[2]) * 0.5,
                       (1/table(imbal_train$is_public)[1]) * 0.5)

ctrl$seeds <- orig_fit$control$seeds

weighted_fit <- train(is_public ~ grad_rate + per_pupil_funding + 
                        fysy_ratio + percent_has_counselor,
                      data=imbal_train, method="glm", family="binomial", 
                      weights = model_weights, trControl = ctrl)
pred_weight <- predict(weighted_fit, newdata=imbal_test, type = "prob")
#########################################################
# smote
ctrl$sampling <- "smote"

smote_fit <- train(is_public ~ grad_rate + per_pupil_funding + 
                     fysy_ratio + percent_has_counselor,
                   data=imbal_train, method="glm", family="binomial", 
                   trControl = ctrl)

pred_smote <- predict(smote_fit, newdata=imbal_test, type = "prob")
#########################################################
# Rose
ctrl$sampling <- "rose"

rose_fit <- train(is_public ~ grad_rate + per_pupil_funding + 
                    fysy_ratio + percent_has_counselor,
                  data=imbal_train, method="glm", family="binomial", 
                  trControl = ctrl)
pred_rose <- predict(rose_fit, newdata=imbal_test, type = "prob")
###########################################

ctrl$sampling <- "up"

up_fit <- train(is_public ~ grad_rate + per_pupil_funding + 
                  fysy_ratio + percent_has_counselor,
                data=imbal_train, method="glm", family="binomial", 
                trControl = ctrl)
pred_up <- predict(up_fit, newdata=imbal_test, type = "prob")

#####################################
# down
ctrl$sampling <- "down"

down_fit <- train(is_public ~ grad_rate + per_pupil_funding + 
                    fysy_ratio + percent_has_counselor,
                  data=imbal_train, method="glm", family="binomial", 
                  trControl = ctrl)
pred_down <- predict(down_fit, newdata=imbal_test, type = "prob")
# now plot them and display ROC
par(pty = "s")

roc(imbal_test$is_public, pred_orig[,"1"], plot=TRUE, 
    col = "blue", print.auc=TRUE)
plot.roc(imbal_test$is_public, pred_weight[,"1"], 
         col = "red", print.auc=TRUE, add= TRUE,print.auc.y=.45,print.auc.x=.45)
plot.roc(imbal_test$is_public, pred_smote[,"1"], 
         col = "dark green", print.auc=TRUE, add= TRUE,print.auc.y=.55,print.auc.x=.55)
plot.roc(imbal_test$is_public, pred_rose[,"1"], 
         col = "orange", print.auc=TRUE, add= TRUE,print.auc.y=.6,print.auc.x=.60)
plot.roc(imbal_test$is_public, pred_up[,"1"], 
         col = "gray", print.auc=TRUE, add= TRUE,print.auc.y=.65,print.auc.x=.65)
plot.roc(imbal_test$is_public, pred_down[,"1"], 
         col = "purple", print.auc=TRUE, add= TRUE,print.auc.y=.70,print.auc.x=.70)
legend("bottomright", legend=c("Original","Weighted", "SMOTE", "ROSE",
                               "Up","Down"), 
       col=c("blue", "red","dark green", "orange", "gray", "purple"), lwd=4)

