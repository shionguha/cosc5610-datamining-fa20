library(tidyverse)
library(modelr)
library(broom)

library(dataPreparation)
library(caret)
library(magrittr)
library(ROCR)
library(e1071)
library(data.table)

library(dplyr)
library(forcats)
library(grid)
library(gridExtra)
library(kableExtra)
library(scales)
library(aod)

########################### Data Loading
### Read datas
allegations <- read.csv("allegations-cleaned.csv")


##### class imbalances

########################### Data Preparation & Cleaning
## cleaning and prep from -> https://cran.r-project.org/web/packages/dataPreparation/vignettes/train_test_prep.html
## sample() func code from prof guha script


## Sampling
set.seed(89723)
allegations$sustained <- factor(allegations$sustained)
sample <- sample(c(TRUE, FALSE), nrow(allegations), replace = T, prob = c(0.6, 0.4))
# test_index <- setdiff(1:nrow(allegations), train_index)



## Build train and test
X_train <- allegations[sample,]
# y_train <- allegations[train_index, "required.corrective.action"]

X_test <- allegations[!sample,]
# y_test <- allegations[test_index, "required.corrective.action"]

# old
##train_index <- sample(1:nrow(allegations), 0.6 * nrow(allegations))
# train <- data[sample,]
# test <- data[!sample,]

## check for useless variables
constant_cols <- which_are_constant(allegations)
double_cols <- which_are_in_double(allegations)
bijections_cols <- which_are_bijection(allegations)

## Scaling not needed - vars are categorical

## Discretization (bins)
## incident.complainant.age and incident.officer.age
c_bins <- build_bins(data_set = X_train, cols = "complainantAge", n_bins = 12, type = "equal_freq", verbose = TRUE)
o_bins <- build_bins(data_set = X_train, cols = "officerAge", n_bins = 12, type = "equal_freq", verbose = TRUE)

X_train <- fast_discretization(data_set = X_train, bins = list(complainantAge = c(0, 18, 21, 23, 25, 28, 30, 33, 36, 41, 45, 51, Inf)))
X_train <- fast_discretization(data_set = X_train, bins = list(officerAge = c(25, 26, 28, 29, 30, 31, 33, 34, 36, 38, 42, Inf)))
X_test <- fast_discretization(data_set = X_test, bins = list(complainantAge = c(0, 18, 21, 23, 25, 28, 30, 33, 36, 41, 45, 51, Inf)))
X_test <- fast_discretization(data_set = X_test, bins = list(officerAge = c(25, 26, 28, 29, 30, 31, 33, 34, 36, 38, 42, Inf)))


## encoding - one_hot_encoder
## boosts cols out to 1k
encoding <- build_encoding(data_set = X_train, cols="auto", verbose = TRUE)
X_train <- one_hot_encoder(data_set = X_train, encoding = encoding, drop = TRUE, verbose = TRUE)
X_test <- one_hot_encoder(data_set = X_test, encoding = encoding, drop = TRUE, verbose = TRUE)

print("Dim X_Train: ")
print(dim(X_train))
print("Dim X_Test: " )
print(dim(X_test))

## re-filter train/test
## this takes 30 minutes
# bijections <- which_are_bijection(data_set = X_train, verbose = TRUE)
# print(names(X_train)[bijections])
# Results:
# "incidentCmd.TB H.O" 
# "incidentCmd.TB CAN" 
# "officerGender.F"
# "allegation.Animal"  
# "sustained.1" -> will drop sustained.0  


### this step is dependent on the output of the above guide is not working - have to manually enter it with within() command
X_train <- within(X_train, rm("officerGender.F", "incidentCmd.TB H.O", "incidentCmd.TB CAN", "allegation.Animal", "sustained.0"))
X_test <- within(X_test, rm("officerGender.F", "incidentCmd.TB H.O", "incidentCmd.TB CAN", "allegation.Animal", "sustained.0"))

X_train <- rename(X_train, sustained = sustained.1)
X_test <- rename(X_test, sustained = sustained.1)


## make sure train/test have same shape
X_test <- same_shape(X_test, reference_set = X_test, verbose = TRUE)


## VAR PREP - Grep help from R discord
currentCmdVars <- paste0(grep("currentCmd", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ") 	
currentRnk <- paste0(grep("currentRnk", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
incidentCmd <- paste0(grep("incidentCmd", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
incidentRnk <- paste0(grep("incidentRnk", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
officerEthnicity <- paste0(grep("officerEthnicity", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
officerGender <- paste0(grep("officerGender", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
officerAge <- paste0(grep("officerAge", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
complainantEthnicity <- paste0(grep("complainantEthnicity", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
complainantGender <- paste0(grep("complainantGender", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
complainantAge <- paste0(grep("complainantAge", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
fado <- paste0(grep("fado", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
allegation <- paste0(grep("allegation", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")
contactReason <- paste0(grep("contactReason", paste0("`", names(X_train), "`"), value = TRUE, fixed = TRUE), collapse = " + ")

############################# Formulas

#3
formula_curr_off <- as.formula(paste("sustained ~",
                              "officerID", "+",
                              currentCmdVars, "+",
                              currentRnk, "+",
                              officerEthnicity, "+",
                              officerGender, "+",
                              officerAge, "+",
                              allegation))

#8
cooa_formula <- as.formula(paste("sustained ~",
                                 "officerID", "+",
                                 currentCmdVars, "+",
                                 officerAge, "+",
                                 officerGender, "+",
                                 "precinctID", "+",
                                 "yearClosed", "+",
                                  allegation))

#9
formula38 <- as.formula(paste("sustained ~",
                              "officerID", "+",
                              currentCmdVars, "+",
                              currentRnk, "+",
                              officerEthnicity, "+",
                              officerAge, "+",
                              officerGender, "+",
                              allegation, "+",
                              "precinctID", "+",
                              "yearClosed"))

#4
formula4 <- as.formula(paste("sustained ~",
                                        "officerID", "+",
                                        currentCmdVars, "+",
                                        currentRnk, "+",
                                        officerEthnicity, "+",
                                        officerAge, "+",
                                        officerGender, "+",
                                        complainantAge, "+",
                                        complainantEthnicity, "+",
                                        allegation, "+",
                                        "precinctID", "+",
                                        "yearClosed"))

#10 Ethnicity
formula5 <- as.formula(paste("sustained ~",
                              officerEthnicity, "+",
                              #officerAge, "+",
                              complainantEthnicity, "+",
                              allegation))#, "+",
                              #"precinctID", "+",
                              #"yearClosed"))



########################### Modeling
curr_off_model <- glm(formula_curr_off, data = X_train, family="binomial")
cooa_model <- glm(cooa_formula, data = X_train, family="binomial")
model_38 <- glm(formula38, data = X_train, family = "binomial")
model_oc <- glm(formula4, data = X_train, family = "binomial")
model_e <- glm(formula5, data = X_train, family = "binomial")

list(
  summary(curr_off_model),
  summary(cooa_model),
  summary(model_38),
  summary(model_oc),
  summary(model_e)
  )

#################### goodness of fit
list(
  curr_off_pR2 = pscl::pR2(curr_off_model)["McFadden"],
  cooa_pR2 = pscl::pR2(cooa_model)["McFadden"],
  model38_pR2 = pscl::pR2(model_38)["McFadden"],
  model_oc_pR2 = pscl::pR2(model_oc)["McFadden"],
  model_e_pr2 = pscl::pR2(model_e)["McFadden"])

m3s <- coef(summary(curr_off_model))
m3s <- m3s[m3s[,"Pr(>|z|)"] < .05,]
m3s <- m3s[order(m3s[,"Pr(>|z|)"], decreasing=F),]

m8s <- coef(summary(cooa_model))
m8s <- m8s[m8s[,"Pr(>|z|)"] < .05,]
m8s <- m8s[order(m8s[,"Pr(>|z|)"], decreasing=F),]

m38s <- coef(summary(model_38))
m38s <- m38s[m38s[,"Pr(>|z|)"] < .05,]
m38s <- m38s[order(m38s[,"Pr(>|z|)"], decreasing=F),]

mnocs <- coef(summary(model_oc))
mncos <- mnocs[mnocs[,"Pr(>|z|)"] < .05,]
mnocs <- mnocs[order(mnocs[,"Pr(>|z|)"], decreasing=F),]




######################## from example script 
test <- X_test
test.predicted.m3 <- predict(curr_off_model, newdata = test, type = "response")
test.predicted.m8 <- predict(cooa_model, newdata = test, type = "response")
test.predicted.m38 <- predict(model_38, newdata = test, type = "response")
test.predicted.m4 <- predict(model_oc, newdata = test, type = "response")

model3 <- table(test$sustained, test.predicted.m3 > 0.5) %>% prop.table() %>% round(3)
model8 <- table(test$sustained, test.predicted.m8 > 0.5) %>% prop.table() %>% round(3)
model38 <- table(test$sustained, test.predicted.m38 > 0.5) %>% prop.table() %>% round(3)
model4 <- table(test$sustained, test.predicted.m4 > 0.5) %>% prop.table() %>% round(3)


list(model3,
     model8,
     model38,
     model4)

#### PLOT PERCENT

model3 %>% mosaicplot() %>% title(main = "Model 3")
model8 %>% mosaicplot() %>% title(main = "Model 8")
model38 %>% mosaicplot() %>% title(main = "Model 38")
model4 %>% mosaicplot() %>% title(main = "Model 4")


test3 <- mutate(test, m3.pred = ifelse(test.predicted.m3 > 0.5, "1", "0"))
test8 <- mutate(test, m8.pred = ifelse(test.predicted.m8 > 0.5, "1", "0"))
test38 <- mutate(test, m38.pred = ifelse(test.predicted.m38 > 0.5, "1", "0"))
test4 <- mutate(test, m4.pred = ifelse(test.predicted.m4 > 0.5, "1", "0"))

test3_summary <- summarise(test3, m3.error = mean(sustained != m3.pred))
test8_summary <- summarise(na.omit(test8), m8.error = mean(sustained != m8.pred))
test38_summary <- summarise(na.omit(test38), m38.error = mean(sustained != m38.pred))
test4_summary <- summarise(na.omit(test4), m4.error = mean(sustained != m4.pred))

list(
  test3_summary,
  test8_summary,
  test38_summary,
  test4_summary
)

test8_c <- na.omit(test8)
test38_c <- na.omit(test38)
test4_c <- na.omit(test4)


table(test3$sustained, na.omit(test.predicted.m3) > 0.5)
table(test8_c$sustained, na.omit(test.predicted.m8) > 0.5)
table(test38_c$sustained, na.omit(test.predicted.m38) > 0.5)
table(test4$sustained, test.predicted.m4 > 0.5)

m3auc = prediction(test.predicted.m3, test3$sustained) %>%
  performance(measure = "auc") %>%
  .@y.values

m8auc = prediction(list(na.omit(test.predicted.m8)), test8_c$sustained) %>%
  performance(measure = "auc") %>%
  .@y.values

m38auc = prediction(list(na.omit(test.predicted.m38)), test38_c$sustained) %>%
  performance(measure = "auc") %>%
  .@y.values

m4auc = prediction(list(na.omit(test.predicted.m4)), test4_c$sustained) %>%
  performance(measure = "auc") %>%
  .@y.values

prediction(test.predicted.m3, test3$sustained) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()
  title(main = paste("M3 ROC - AUC = ", m3auc))

prediction(list(na.omit(test.predicted.m8)), test8_c$sustained) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()
  title(main = paste("M8 ROC - AUC = ", m8auc))

prediction(list(na.omit(test.predicted.m38)), test38_c$sustained) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()
  title(main = paste("M38 ROC - AUC = ", m38auc))

prediction(list(na.omit(test.predicted.m4)), test4_c$sustained) %>%
  performance(measure = "tpr", x.measure = "fpr") %>%
  plot()
  title(main = paste("M4 ROC - AUC = ", m4auc))




################### Cross validation & Errors

##RMSE - lower
RMSE3 = RMSE(test.predicted.m3, test3$sustained)
RMSE8 = RMSE(na.omit(test.predicted.m8), test8_c$sustained)
RMSE38 = RMSE(na.omit(test.predicted.m38), test38_c$sustained)
RMSE4 = RMSE(na.omit(test.predicted.m4), test4_c$sustained)

##MAE - lower
MAE3 = MAE(test.predicted.m3, test3$sustained)
MAE8 = MAE(na.omit(test.predicted.m8), test8_c$sustained)
MAE38 = MAE(na.omit(test.predicted.m38), test38_c$sustained)
MAE4 = MAE(na.omit(test.predicted.m4), test4_c$sustained)

##R2 - Higher
R2_3 = R2(test.predicted.m3, test3$sustained)
R2_8 = R2(na.omit(test.predicted.m8), test8_c$sustained)
R2_38 = R2(na.omit(test.predicted.m38), test38_c$sustained)
R2_4 = R2(na.omit(test.predicted.m4), test4_c$sustained)

rmse = c(RMSE3,RMSE8,RMSE38, RMSE4)
mae = c(MAE3,MAE8, MAE38, MAE4)
r2 = c(R2_3,R2_8, R2_38, R2_4)


errors <- data.frame(
  r2,
  rmse,
  mae
)

errors_t <- transpose(errors)
rownames(errors_t) <- colnames(errors)
colnames(errors_t) <- rownames(errors)
errors <- errors_t
errors %>% 
  rename(
    "model 3" = '1',
    "model 8" = '2',
    "model 38" = '3',
    "model 4" = '4'
  )


######### Tables

cols = c("McFadden's Pseudo-R2")
rows = c("model 3", "model 8", "model 38", "model 4")

vals <- c(0.121742, 
          0.1194583, 
          0.124229,
          0.1257921)

mcfads <- data.frame(vals)
rownames(mcfads) <- rows
colnames(mcfads) <- cols
kbl(mcfads , row.names = TRUE, caption = "Table 10. McFadden's Pseudo-R2") %>% kable_classic_2(full_width = F)

kbl(head(m3s, 20) , row.names = TRUE, caption = "Table 1. Model 3 Significant Coefs") %>% kable_classic_2(full_width = F)
kbl(head(m8s, 20) , row.names = TRUE, caption = "Table 2. Model 8 Significant Coefs") %>% kable_classic_2(full_width = F)
kbl(head(m38s, 20) , row.names = TRUE, caption = "Table 3. Model 38 Significant Coefs") %>% kable_classic_2(full_width = F)
kbl(head(mnocs, 20) , row.names = TRUE, caption = "Table 4. Model 4 Significant Coefs") %>% kable_classic_2(full_width = F)

kbl(head(model3, 10), row.names = TRUE, caption = "Table 5. Model 3 Prop Table") %>% kable_classic_2(full_width = F)
kbl(head(model8, 10), row.names = TRUE, caption = "Table 6. Model 8 Prop Table") %>% kable_classic_2(full_width = F)
kbl(head(model38, 10), row.names = TRUE, caption = "Table 7. Model 38 Prop Table") %>% kable_classic_2(full_width = F)
kbl(head(model4, 10), row.names = TRUE, caption = "Table 8. Model 4 Prop Tables") %>% kable_classic_2(full_width = F)

kbl(errors, row.names = TRUE, caption = "Table 9. Error Table") %>% kable_classic_2(full_width = F)
########### Cross Validation
train.control <- trainControl(method = "cv", number = 10)
model4_cv_a <- train(formula4, data = X_train, method = "glm",
               trControl = train.control, na.action = "na.omit")
print(model4_cv)

train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3)
model4_cv_b <- train(formula4, data = X_train, method = "glm",
                   trControl = train.control, na.action = "na.omit")
print(model4_cv)


################# REFERENCES
#Wickham et al., (2019). Welcome to the tidyverse. Journal of Open Source Software,
#4(43), 1686, https://doi.org/10.21105/joss.01686

#Hadley Wickham (2020). modelr: Modelling Functions that Work with the Pipe. R package
#version 0.1.8. https://CRAN.R-project.org/package=modelr

#David Robinson, Alex Hayes and Simon Couch (2020). broom: Convert Statistical Objects
#into Tidy Tibbles. R package version 0.7.0. https://CRAN.R-project.org/package=broom

#Emmanuel-Lin Toulemonde (2020). dataPreparation: Automated Data Preparation. R package
#version 1.0.0. https://CRAN.R-project.org/package=dataPreparation

#Max Kuhn (2020). caret: Classification and Regression Training. R package version
#6.0-86. https://CRAN.R-project.org/package=caret

#Stefan Milton Bache and Hadley Wickham (2020). magrittr: A Forward-Pipe Operator for R.
#R package version 2.0.1. https://CRAN.R-project.org/package=magrittr

#Sing T, Sander O, Beerenwinkel N, Lengauer T (2005). “ROCR: visualizing classifier
#performance in R.” _Bioinformatics_, *21*(20), 7881. <URL:
#  http://rocr.bioinf.mpi-sb.mpg.de>.

#David Meyer, Evgenia Dimitriadou, Kurt Hornik, Andreas Weingessel and Friedrich Leisch
#(2020). e1071: Misc Functions of the Department of Statistics, Probability Theory Group
#(Formerly: E1071), TU Wien. R package version 1.7-4.
#https://CRAN.R-project.org/package=e1071


#Matt Dowle and Arun Srinivasan (2020). data.table: Extension of `data.frame`. R package
#version 1.13.0. https://CRAN.R-project.org/package=data.table

#Hadley Wickham, Romain François, Lionel Henry and Kirill Müller (2020). dplyr: A
#Grammar of Data Manipulation. R package version 1.0.2.
#https://CRAN.R-project.org/package=dplyr

#Hadley Wickham (2020). forcats: Tools for Working with Categorical Variables (Factors).
#R package version 0.5.0. https://CRAN.R-project.org/package=forcats

#R Core Team (2020). R: A language and environment for statistical computing. R
#Foundation for Statistical Computing, Vienna, Austria. URL https://www.R-project.org/.

#Baptiste Auguie (2017). gridExtra: Miscellaneous Functions for "Grid" Graphics. R
#package version 2.3. https://CRAN.R-project.org/package=gridExtra

#Yihui Xie (2020). knitr: A General-Purpose Package for Dynamic Report Generation in R.
#R package version 1.29.

#Hao Zhu (2020). kableExtra: Construct Complex Table with 'kable' and Pipe Syntax. R
#package version 1.3.1. https://CRAN.R-project.org/package=kableExtra

#Hadley Wickham and Dana Seidel (2020). scales: Scale Functions for Visualization. R
#package version 1.1.1. https://CRAN.R-project.org/package=scales

#Lesnoff, M., Lancelot, R. (2012). aod: Analysis of Overdispersed Data. R package
#version 1.3.1, URL http://cran.r-project.org/package=aod