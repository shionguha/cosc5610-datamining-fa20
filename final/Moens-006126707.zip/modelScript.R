#package installs
install.packages("tidyverse")
install.packages("caret")
install.packages("ROCR")
install.packages("DMwR")
install.packages("ROSE")

library(tidyverse)
library(caret)
library(ROCR) #for AUC
library(DMwR) # for smote implementation
library(ROSE)

#-----------------------------------------------------
#start here when you begin to run things
#-----------------------------------------------------

#getting data and modifying it as done previously
mydata <- read.csv("C:/Users/18474/Desktop/Misc School/Data Mining/dataset.csv")
names(mydata)[names(mydata) == "DEATH_EVENT"] <- "death"
names(mydata)[names(mydata) == "creatinine_phosphokinase"] <- "crea_pho"
names(mydata)[names(mydata) == "serum_creatinine"] <- "serum_crea"
#removing time as it is a baised metric
df = subset(mydata, select = -c(time))

set.seed(123)
training.samples <- createDataPartition(df$death, p = 0.8, list = FALSE)

train.data <- df[training.samples, ]
test.data <- df[-training.samples, ]

#----------------------------------------------------
#model making
#----------------------------------------------------

#choosing between variables to include/not include to see difference
model1 <- lm(death ~ age + anaemia + high_blood_pressure + crea_pho + 
               ejection_fraction + serum_crea + serum_sodium, data = train.data)

model2 <- lm(death ~ age + high_blood_pressure + crea_pho + ejection_fraction +
               serum_crea + serum_sodium, data = train.data)

model3 <- lm(death ~ age + crea_pho + ejection_fraction +
               serum_crea + serum_sodium, data = train.data)

summary(model1)
summary(model2)
summary(model3)

#get the predicted data
train.predicted.m1 <- predict(model1, type = "response")
train.predicted.m2 <- predict(model2, type = "response")
train.predicted.m3 <- predict(model3, type = "response")

#confusion matricies
tapply(train.predicted.m1, train.data$death, mean)
table(train.data$death, train.predicted.m1 > 0.47)

tapply(train.predicted.m2, train.data$death, mean)
table(train.data$death, train.predicted.m2 > 0.47)

tapply(train.predicted.m3, train.data$death, mean)
table(train.data$death, train.predicted.m3 > 0.47)

#get prediction accuracy from the predictions
prediction(train.predicted.m1, train.data$death) %>%
  performance(measure = "auc") %>%
  .@y.values

prediction(train.predicted.m2, train.data$death) %>%
  performance(measure = "auc") %>%
  .@y.values

prediction(train.predicted.m3, train.data$death) %>%
  performance(measure = "auc") %>%
  .@y.values

#find the importances of the variables in each model
varImp(model1)
varImp(model2)
varImp(model3)

#----------------------------------------------------
#class imbalances
#----------------------------------------------------

#oversampling
table(train.data$death)
data.balanced.over <- ovun.sample(death ~ ., data = train.data, method = "over", N = 324)$data
table(data.balanced.over$death)

#undersampling
table(train.data$death)
data.balanced.under <- ovun.sample(death ~ ., data = train.data, method = "under", N = 156, seed = 1)$data
table(data.balanced.under$death)

#both under and over. ROSE does the same without a need for N, using that instead
#table(train.data$death)
#data.balanced.both <- ovun.sample(death ~ ., data = train.data, method = "both", N = 240, seed = 1)$data
#table(data.balanced.both$death)

#ROSE (same as over under if N = 240)
table(train.data$death)
data.balanced.rose <- ROSE(death ~ ., data = train.data, seed = 1)$data
table(data.balanced.rose$death)

#----------------------------------------------------
#model making part 2
#----------------------------------------------------

#model1 did the best, so we apply the imbalanced data techniques to it
model1o <- lm(death ~ age + anaemia + high_blood_pressure + crea_pho + 
                ejection_fraction + serum_crea + serum_sodium, data = data.balanced.over)

model1u <- lm(death ~ age + anaemia + high_blood_pressure + crea_pho + 
                ejection_fraction + serum_crea + serum_sodium, data = data.balanced.under)

model1r <- lm(death ~ age + anaemia + high_blood_pressure + crea_pho + 
                ejection_fraction + serum_crea + serum_sodium, data = data.balanced.rose)

#predict again with new data
train.predicted.m1o <- predict(model1o, type = "response")
train.predicted.m1u <- predict(model1u, type = "response")
train.predicted.m1r <- predict(model1r, type = "response")

#confusion matricies for the balanced model 1 data
tapply(train.predicted.m1o, data.balanced.over$death, mean)
table(data.balanced.over$death, train.predicted.m1o > 0.5)

tapply(train.predicted.m1u, data.balanced.under$death, mean)
table(data.balanced.under$death, train.predicted.m1u > 0.5)

tapply(train.predicted.m1r, data.balanced.rose$death, mean)
table(data.balanced.rose$death, train.predicted.m1r > 0.5)

#get prediction accuracy for the new ones
prediction(train.predicted.m1o, data.balanced.over$death) %>%
  performance(measure = "auc") %>%
  .@y.values

prediction(train.predicted.m1u, data.balanced.under$death) %>%
  performance(measure = "auc") %>%
  .@y.values

prediction(train.predicted.m1r, data.balanced.rose$death) %>%
  performance(measure = "auc") %>%
  .@y.values

#base data again for reference
prediction(train.predicted.m1, train.data$death) %>%
  performance(measure = "auc") %>%
  .@y.values

#make auc graph for comparisons between model 1 and its data alterations
ROCRpred = prediction(train.predicted.m1, train.data$death)
ROCRperf = performance(ROCRpred, "tpr", "fpr")
plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7), main = "Base")

ROCRpred = prediction(train.predicted.m1o, data.balanced.over$death)
ROCRperf = performance(ROCRpred, "tpr", "fpr")
plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7), main = "Oversampled")

ROCRpred = prediction(train.predicted.m1u, data.balanced.under$death)
ROCRperf = performance(ROCRpred, "tpr", "fpr")
plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7), main = "Undersampled")

ROCRpred = prediction(train.predicted.m1r, data.balanced.rose$death)
ROCRperf = performance(ROCRpred, "tpr", "fpr")
plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7), main = "ROSEsampled")


#since oversampling provided the best results, we will use it for the following models
#build the model
model <- lm(death ~ age + anaemia + high_blood_pressure + crea_pho + 
               ejection_fraction + serum_crea + serum_sodium, data = data.balanced.over)

# Make predictions and compute the R2, RMSE and MAE
predictions <- model %>% predict(test.data)
data.frame( R2 = R2(predictions, test.data$death),
            RMSE = RMSE(predictions, test.data$death),
            MAE = MAE(predictions, test.data$death))

RMSE(predictions, test.data$death)/mean(test.data$death)

#define traning control
train.control <- trainControl(method = "LOOCV")
#train the model
model <- train(death ~ age + anaemia + high_blood_pressure + crea_pho + ejection_fraction +
                 serum_crea + serum_sodium, data = df, method = "lm", trControl = train.control)

#summarize the results
print(model)

# Define training control
set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)
# Train the model
model <- train(death ~ age + anaemia + high_blood_pressure + crea_pho + ejection_fraction +
                 serum_crea + serum_sodium, data = df, method = "lm", trControl = train.control)
# Summarize the results
print(model)

# Define training control
set.seed(123)
train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3)
# Train the model
model <- train(death ~ age + anaemia + high_blood_pressure + crea_pho + ejection_fraction +
                 serum_crea + serum_sodium, data = df, method = "lm", trControl = train.control)
# Summarize the results
print(model)
