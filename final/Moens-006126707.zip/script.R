install.packages(c("tidyr", "dplyr", "plyr"))
install.packages(c("ggplot2", "reshape2"))
install.packages("caret")

library(tidyr)
library(plyr)
library(dplyr)
library(ggplot2)
library(reshape2)

mydata <- read.csv("C:/Users/18474/Desktop/Misc School/Data Mining/dataset.csv")

names(mydata)[names(mydata) == "DEATH_EVENT"] <- "death"
names(mydata)[names(mydata) == "creatinine_phosphokinase"] <- "crea_pho"
names(mydata)[names(mydata) == "serum_creatinine"] <- "serum_crea"

#asdf <- cor.test(mydata$sex, mydata$death)

#mydata$sex <- ifelse(mydata$sex == '1', 'M', mydata$sex)
#mydata$sex <- ifelse(mydata$sex == '0', 'F', mydata$sex)

#check text.txt for information on what the cor.test means
cor.test(mydata$age, mydata$death) #significant
cor.test(mydata$anaemia, mydata$death)
cor.test(mydata$crea_pho, mydata$death)
cor.test(mydata$diabetes, mydata$death)
cor.test(mydata$ejection_fraction, mydata$death) #significant
cor.test(mydata$high_blood_pressure, mydata$death)
cor.test(mydata$platelets, mydata$death)
cor.test(mydata$serum_crea, mydata$death) #significant
cor.test(mydata$serum_sodium, mydata$death) #significant
cor.test(mydata$sex, mydata$death)
cor.test(mydata$smoking, mydata$death)
cor.test(mydata$time, mydata$death) #significant

##
#age related graphs
##
ggplot(mydata, mapping = aes(x=factor(age))) + geom_bar(fill = "coral") + theme_classic() + labs(title = "Age distribution")

data_graph <- mydata %>% 
  mutate(death = factor(death, labels = c("no", "yes")), age=factor(age))
#total count plot
ggplot(data_graph, aes(x = age, fill = death)) + geom_bar() + theme_classic() + labs(title = "Age distribution by Death")
#percentages
ggplot(data_graph, aes(x = age, fill = death)) + geom_bar(position = "fill") + theme_classic() +
  labs(title = "Age distribution by Death")
#separated
ggplot(data_graph, aes(x = age, fill = death)) + geom_bar(position = position_dodge()) + theme_classic() + 
  labs(title = "Age distribution by Death separated")

##
#ejection_fraction graphs
##
ggplot(mydata, mapping = aes(x=factor(ejection_fraction))) + geom_bar(fill = "coral") + theme_classic() + 
    labs(title = "Ejection Fraction distribution")

data_graph <- mydata %>% 
  mutate(death = factor(death, labels = c("no", "yes")), eject=factor(ejection_fraction))

ggplot(data_graph, aes(x = eject, fill = death)) + geom_bar(position = "fill") + theme_classic() +
  labs(title = "Ejection Fraction distribution by Death")

ggplot(data_graph, aes(x=eject, fill = death)) + geom_bar() + theme_classic() + 
  labs(title = "Ejection Fraction distribution by Death")
#ggplot(data, aes(x=ejection_fraction, y=factor(death))) + geom_point() + 
#labs(title = "Ejection Fraction distribution by Death")

##
#serum_creatinine
##
ggplot(mydata, mapping = aes(x=factor(serum_crea))) + geom_bar(fill = "coral") + theme_classic() + 
  labs(title = "Serum Creatinine distribution")

data_graph <- mydata %>% 
  mutate(death = factor(death, labels = c("no", "yes")), s_c=factor(serum_crea))

ggplot(data_graph, aes(x=s_c, fill = death)) + geom_bar() + theme_classic() + 
  labs(title = "Serum Creatinine distribution by Death")

ggplot(data_graph, aes(x = s_c, fill = death)) + geom_bar(position = "fill") + theme_classic() +
  labs(title = "Serum Creatinine distribution by Death")

ggplot(data_graph, aes(x=s_c, y=factor(death))) + geom_point() + 
  labs(title = "Serum Creatinine distribution by Death")

##
#serum_sodium graphs
##

ggplot(data, mapping = aes(x=factor(serum_sodium))) + geom_bar(fill = "coral") + theme_classic() + 
  labs(title = "Serum Sodium distribution")

data_graph <- mydata %>% 
  mutate(death = factor(death, labels = c("no", "yes")), s_s=factor(serum_sodium))

ggplot(data_graph, aes(x = s_s, fill = death)) + geom_bar(position = "fill") + theme_classic() +
  labs(title = "Serum Sodium distribution by Death")

ggplot(data_graph, aes(x=s_s, fill = death)) + geom_bar() + theme_classic() + 
  labs(title = "Serum Sodium distribution by Death")

##
#time graphs
##

#ggplot(data, mapping = aes(x=factor(time))) + geom_bar(fill = "coral") +
#theme_classic() + labs(title = "Time(days) since last visit distribution")

data_graph <- mydata %>% 
  mutate(death = factor(death, labels = c("no", "yes")), time=time)

ggplot(data_graph, aes(x=time, fill = death)) + geom_bar() + theme_classic() + 
  labs(title = "Time(days) since last visit distribution by Death")

ggplot(data_graph, aes(x = time, fill = death)) + geom_bar(position = "fill") + theme_classic() +
  labs(title = "Time(days) since last visit distribution by Death")

ggplot(data_graph, aes(x=time, y=factor(death))) + geom_point() + 
  labs(title = "Time(days) since last visit distribution by Death")

##THE FOLLOWING IS SOURCED FROM THE STHDA SOURCE GIVEN IN THE SOURCES CATEGORY OF THE PAPER

cormat <- round(cor(mydata), 2)
melted_cormat <- melt(cormat)
ggplot(mydata = melted_cormat, aes(x=Var1, y=Var2, fill=value))+geom_tile() + scale_fill_gradient(low = "Black", high = "White")

get_upper_tri <- function(cormat){
  cormat[lower.tri(cormat)]<- NA
  return(cormat)
}

upper_tri <- get_upper_tri(cormat)

melted_cormat <- melt(upper_tri, na.rm = TRUE)

ggplot(mydata = melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab", 
                       name="Pearson\nCorrelation") +
  theme_minimal()+ 
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1))+
  coord_fixed()

reorder_cormat <- function(cormat){
  # Use correlation between variables as distance
  dd <- as.dist((1-cormat)/2)
  hc <- hclust(dd)
  cormat <-cormat[hc$order, hc$order]
}

# Reorder the correlation matrix
cormat <- reorder_cormat(cormat)
upper_tri <- get_upper_tri(cormat)
# Melt the correlation matrix
melted_cormat <- melt(upper_tri, na.rm = TRUE)
# Create a ggheatmap
ggheatmap <- ggplot(melted_cormat, aes(Var2, Var1, fill = value))+ geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab", name="Pearson\nCorrelation") +
  theme_minimal()+ # minimal theme
  theme(axis.text.x = element_text(angle = 45, vjust = 1, size = 12, hjust = 1))+
  coord_fixed()
# Print the heatmap
print(ggheatmap)

ggheatmap + geom_text(aes(Var2, Var1, label = value), color = "black", size = 4) +
  theme(
    axis.title.x = element_blank(), axis.title.y = element_blank(),
    panel.grid.major = element_blank(), panel.border = element_blank(),
    panel.background = element_blank(), axis.ticks = element_blank(),
    legend.justification = c(1, 0), legend.position = c(0.6, 0.7),
    legend.direction = "horizontal")+
  guides(fill = guide_colorbar(barwidth = 7, barheight = 1, title.position = "top", title.hjust = 0.5))

#END STHDA SOURCED CODE
