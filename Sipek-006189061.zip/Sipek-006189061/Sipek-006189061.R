library(tidyverse)
library(ggplot2)
library(plyr)
library(caret)
library(ROCR)
library(DMwR) 
library(ROSE)

#convert percent of available and potentially available beds needed into binary 1 or 0 if percentage is greater than 100 or not
COVID20$binavail6<- as.numeric(COVID20$avail6 > 1)
COVID20$binpavail6<- as.numeric(COVID20$pavail6 > 1)
COVID20$binavail12<- as.numeric(COVID20$avail12 > 1)
COVID20$binpavail12<- as.numeric(COVID20$pavail12 > 1)
COVID20$binavail18<- as.numeric(COVID20$avail18 > 1)
COVID20$binpavail18<- as.numeric(COVID20$pavail18 > 1)
COVID20$biniavail6<- as.numeric(COVID20$iavail6 > 1)
COVID20$binipavail6<- as.numeric(COVID20$ipavail6 > 1)
COVID20$biniavail12<- as.numeric(COVID20$iavail12 > 1)
COVID20$binipavail12<- as.numeric(COVID20$ipavail12 > 1)
COVID20$biniavail18<- as.numeric(COVID20$iavail18 > 1)
COVID20$binipavail18<- as.numeric(COVID20$ipavail18 > 1)

#remove unnecessary columns
df=subset(COVID20,select=-c(HRR, AHB, PAHB, AIB, PAIB, PIIC, need6, total6, need12, total12, need18, total18, ineed6, itotal6, ineed12, itotal12, ineed18, itotal18))

#determine how many hospitals in each region will have over 100% of available and potentially available hospital and ICU beds need in 6, 12 and 18 months
with(COVID20, table(Region, binavail6))
with(COVID20, table(Region, binpavail6))
with(COVID20, table(Region, binavail12))
with(COVID20, table(Region, binpavail12))
with(COVID20, table(Region, binavail18))
with(COVID20, table(Region, binpavail18))
with(COVID20, table(Region, biniavail6))
with(COVID20, table(Region, binipavail6))
with(COVID20, table(Region, biniavail12))
with(COVID20, table(Region, binipavail12))
with(COVID20, table(Region, biniavail18))
with(COVID20, table(Region, binipavail18))

#split training and test data
set.seed(123)
trainset <- createDataPartition(df$binavail6, p=0.8, list=FALSE)
train.data <- df[trainset, ]
test.data <- df[-trainset, ]

#model 1 using number beds, region, adult population, 65+ population, infected individuals, hospitalized individuals
model1 <- lm(binavail6 ~ THB + Region + AP + P65 + PII + PHI, data=train.data)
summary(model1)

#model 2 using number beds, region, 65+ population, infected individuals, hospitalized individuals
model2 <- lm(binavail6 ~ THB + Region + P65 + PII + PHI, data=train.data)
summary(model2)

#model 2 using number beds, region, 65+ population, hospitalized individuals
model3 <- lm(binavail6 ~ THB + Region + P65 + PHI, data=train.data)
summary(model3)

#create confusion matrices
train.predict.m1 <- predict(model1,type="response")
table(train.predict.m1 > 0.97, train.data$binavail6)
prediction(train.predict.m1, train.data$binavail6) %>%performance(measure = "auc")%>% .@y.values

train.predict.m2 <- predict(model2,type="response")
table(train.predict.m2 > 0.97, train.data$binavail6)
prediction(train.predict.m2, train.data$binavail6) %>%performance(measure = "auc")%>% .@y.values

train.predict.m3 <- predict(model3,type="response")
table(train.predict.m3 > 0.97, train.data$binavail6)
prediction(train.predict.m3, train.data$binavail6) %>%performance(measure = "auc")%>% .@y.values

varImp(model1)
varImp(model2)
varImp(model3)

#R2, RMSE, MAE for model 2 (best accuracy)
predictions <- model2 %>% predict(train.data)
data.frame( R2 = R2(predictions, train.data$binavail6),RMSE = RMSE(predictions, train.data$binavail6),MAE = MAE(predictions, train.data$binavail6))

#oversampling
table(train.data$binavail6)
over <- ovun.sample(binavail6 ~ ., data = train.data, method = "over",N = 478)$data
table(over$binavail6)

#undersampling
under <- ovun.sample(binavail6 ~ ., data = train.data, method = "under",N = 10)$data
table(under$binavail6)

#both
both <- ovun.sample(binavail6 ~ ., data = train.data, method = "both", p=0.5, N = 244)$data
table(both$binavail6)

#ROC for training data
ROCRpred = prediction(train.predict.m2, train.data$binavail6)
ROCRperf = performance(ROCRpred, "tpr", "fpr")
plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))

#accuracy for oversampling, undersampling, both, training data
model2u <- lm(binavail6 ~ THB + Region + P65 + PII + PHI, data=under)
summary(model2u)
train.predict.m2u <- predict(model2u,type="response")
table(train.predict.m2u > 0.5, under$binavail6)
prediction(train.predict.m2u, under$binavail6) %>%performance(measure = "auc")%>% .@y.values

model2o <- lm(binavail6 ~ THB + Region + P65 + PII + PHI, data=over)
summary(model2o)
train.predict.m2o <- predict(model2o,type="response")
table(train.predict.m2o > 0.5, over$binavail6)
prediction(train.predict.m2o, over$binavail6) %>%performance(measure = "auc")%>% .@y.values

model2b <- lm(binavail6 ~ THB + Region + P65 + PII + PHI, data=both)
summary(model2b)
train.predict.m2b <- predict(model2b,type="response")
table(train.predict.m2b > 0.5, both$binavail6)
prediction(train.predict.m2b, both$binavail6) %>%performance(measure = "auc")%>% .@y.values

#accuracy for oversampling, undersampling, both, training data
test.predict.under <- predict(model2u, newdata = test.data, type = "response")
prediction(test.predict.under, test.data$binavail6) %>%performance(measure = "auc") %>%.@y.values

test.predict.over <- predict(model2o, newdata = test.data, type = "response")
prediction(test.predict.over, test.data$binavail6) %>%performance(measure = "auc") %>%.@y.values

test.predict.both <- predict(model2b, newdata = test.data, type = "response")
prediction(test.predict.both, test.data$binavail6) %>%performance(measure = "auc") %>%.@y.values

#R2, RMSE, MAE for test data
predictions <- model2b %>% predict(test.data)
data.frame( R2 = R2(predictions, test.data$binavail6), RMSE = RMSE(predictions, test.data$binavail6), MAE = MAE(predictions, test.data$binavail6))

ROCRpred = prediction(test.predict.both, test.data$binavail6)
ROCRperf = performance(ROCRpred, "tpr", "fpr")
plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))

#CV
set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)
modelcv <- train(binavail6 ~ THB + Region + AP + P65 + PII + PHI, data=df, trControl = train.control)
print(modelcv)

#repeated CV
set.seed(123)
train.control <- trainControl(method = "repeatedcv", number = 10, repeats = 3)
modelcv <- train(binavail6 ~ THB + Region + AP + P65 + PII + PHI, data=df, trControl = train.control)
print(modelcv)
