# This R environment comes with many helpful analytics packages installed
# It is defined by the kaggle/rstats Docker image: https://github.com/kaggle/docker-rstats
# For example, here's a helpful package to load

library(tidyverse) # metapackage of all tidyverse packages
library(ggplot2)
library(visdat)
library(ggvis)
library(class)
library(gmodels)
library(caret)
library(arsenal)
library(gapminder)




# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

#csv input path
dataset <- read.csv(here::here("../input/updatedup/noAge.csv"), stringsAsFactors = FALSE)

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

#This is used to randomly assign the data to the testing or training sets at a 2/3, 1/3 split. 2/3 go to the training set and 1/3 to the testing
ind <- sample(2, nrow(dataset), replace=TRUE, prob=c(0.67, 0.33))

# Creates training set, the columns are of officer gender, race, complaintant gender, and race
dataset.training <- dataset[ind==1, 16:19]

# Creates test set
dataset.test <- dataset[ind==2, 16:19]

# Creates the training labels, column is the board outcome
dataset.trainLabels <- dataset[ind==1,26]

# Creates the test labels
dataset.testLabels <- dataset[ind==2, 26]

#Train is the function that trains our dataset using gbm
model_gbm <- train(dataset.training, dataset.trainLabels, method='gbm', trControl = trainControl(method = "repeatedcv", 
                                                  number = 5, 
                                                  repeats = 5, 
                                                  verboseIter = FALSE,
                                                  ),
                                                  verbose = 0)
print(model_gbm)

#This uses our generated model from above to make predictions on the test dataset
predictions<-predict(object=model_gbm,dataset.test, interval = "confidence")

# Predictions table
table(predictions)

#R2, RMSE, MAE are different values used to evaluate your predictions on the test set
R2 = R2(predictions, dataset.testLabels)
RMSE = RMSE(predictions, dataset.testLabels)
MAE = MAE(predictions, dataset.testLabels)
print(R2)
print(RMSE)
print(MAE)

#Graph of predictions
counts <- table(predictions)
barplot(counts, main="Frequency of numbers predicted",
  xlab="Number Predicted", ylab="Frequency", col=c("darkblue","red","green","pink","purple","yellow","black","tan","gray","maroon","violet"),
  legend = rownames(counts))