library(readxl)
library(caret)
library(ggplot2)
library(pacman)
library(tidyverse)
library(caret)
library(broom)
library(modelr)
library(ROCR)
library(ROSE)

mydata <- read.csv("thedataset.csv", header = TRUE, sep = ",")
names(mydata)[names(mydata) == "age_range"] <- "year"
names(mydata)[names(mydata) == "ethnicity_range"] <- "ethn"
names(mydata)[names(mydata) == "gang_attire"] <- "clothes"
with(mydata, table(age, ethnicity))
head(mydata)
nrow(mydata)

set.seed(123)
trainIndex <- createDataPartition(mydata$arrested, p = 0.8, list = FALSE)
trainwork <- mydata[trainIndex, ]
testwork <- mydata[-trainIndex, ]
#view(trainwork)
#view(testwork)

#Models
model1 <- glm(arrested ~ clothes + ethnicity + age + year + gender, family="binomial", data = trainwork)
summary(model1)
model2 <- glm(arrested ~ clothes + ethnicity + age + year, family="binomial", data = trainwork)
summary(model2)
model3 <- glm(arrested ~ clothes + ethnicity + age, family="binomial", data = trainwork)
summary(model3)

#Probabilities
test.predicted.m1 <- predict(model1, newdata = testwork, type = "response")
test.predicted.m2 <- predict(model2, newdata = testwork, type = "response")
test.predicted.m3 <- predict(model3, newdata = testwork, type = "response")

#Model Predictions
table(test.predicted.m1 > 0.5, testwork$arrested)
table(test.predicted.m2 > 0.5, testwork$arrested)
table(test.predicted.m3 > 0.5, testwork$arrested)

#Performing AUC to Test Models 
prediction(test.predicted.m1, testwork$arrested) %>%
  performance(measure = "auc") %>%
  .@y.values
prediction(test.predicted.m2, testwork$arrested) %>%
  performance(measure = "auc") %>%
  .@y.values
prediction(test.predicted.m3, testwork$arrested) %>%
  performance(measure = "auc") %>%
  .@y.values

#ROC Model 3
ROCRpred = prediction(test.predicted.m3, testwork$arrested)
ROCRperf = performance(ROCRpred, "tpr", "fpr")
plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))

#Variables of Models
varImp(model1)
varImp(model2)
varImp(model3)

#R2/RMSE,MAE Model 3
predictions <- model3 %>% predict(testwork)
data.frame(
  R2 = R2(predictions, testwork$arrested),
  RMSE = RMSE(predictions, testwork$arrested),
  MAE = MAE(predictions, testwork$arrested)
)

