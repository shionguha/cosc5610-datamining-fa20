# Data Mining Project Verson 2 and Final Version
# October 27, 2020 & December 9, 2020
# Helen Wang
# MU ID: : 006178927

### Women's E-Commerce Clothing Review Project - Version 2.
### Data Exploration and Visualization
### October 27, 2020


# cleaning
rm(list=ls())
# load library packages
library(tidyverse)  # data manipulation and visualization
library(gridExtra)
library(corrplot)
library(vcd)
library(caret)

# read the data 
eClothing.df <- read.csv("Wang-006178927.csv")
view(eClothing.df) # view data
str(eClothing.df) # check data structure and data types

# check data if clean -- find out the missing value
is.na(eClothing.df)
str(eClothing.df)

## .	How the predictors impact the outcome variables Recommended IND -- making bar plots 
# data type -- factor for bar charts

# Age - covert Age from int data type to factor
eClothing.df$Age <- as.factor(eClothing.df$Age)
b1 <- ggplot(eClothing.df) + geom_bar(aes(x = Age), fill = 'navy')
b1
# plot bar chart with ggplot
ggplot(eClothing.df) + geom_bar(aes(x = Age, fill = Department.Name))

# Rating - covert Rating from int data type to factor
eClothing.df$Rating <- as.factor(eClothing.df$Rating)
str(eClothing.df)
b2 <- ggplot(eClothing.df) + geom_bar(aes(x = Rating), fill = 'green')
b2

## .	Is a higher rating means definitely recommend the items to others online?
ggplot(eClothing.df) + geom_bar(aes(x = Rating, fill = Recommended.IND))

# Recommended.IND as the predicted variable
eClothing.df$Recommended.IND <- as.factor(eClothing.df$Recommended.IND)
b3 <- ggplot(eClothing.df) + geom_bar(aes(x = Recommended.IND), fill = 'blue')
b3
b31 <- ggplot(eClothing.df) + geom_bar(aes(x = Recommended.IND, fill = Department.Name))
b31
b32 <- ggplot(eClothing.df) + geom_bar(aes(x = Recommended.IND, fill = Division.Name))
b32
b33 <- ggplot(eClothing.df) + geom_bar(aes(x = Recommended.IND, fill = Class.Name))
b33

## arrage the bar tables to compare in one page
grid.arrange (b31, b32, b33, nrow = 1)

# Positive.Feedback.Count as X axis
eClothing.df$Positive.Feedback.Count <- as.factor(eClothing.df$Positive.Feedback.Count)
b4 <- ggplot(eClothing.df) + geom_bar(aes(x = Positive.Feedback.Count), fill = 'pink')
b4


## .	How the Positive Feedback Count and affect the probability of Recommended IND?
ggplot(eClothing.df) + geom_bar(aes(x = Positive.Feedback.Count, fill = Recommended.IND))

# Division.Name as X axis
b5 <- ggplot(eClothing.df) + geom_bar(aes(x = Division.Name), fill = 'gold')
b5
ggplot(eClothing.df) + geom_bar(aes(x = Division.Name, fill = Recommended.IND))

# Department.Name as X axis
b6 <- ggplot(eClothing.df) + geom_bar(aes(x = Department.Name), fill = 'purple')
b6
ggplot(eClothing.df) + geom_bar(aes(x = Department.Name, fill = Recommended.IND))

# Class.Name as X axis
b7 <- ggplot(eClothing.df) + geom_bar(aes(x = Class.Name), fill = 'red')
b7
ggplot(eClothing.df) + geom_bar(aes(x = Class.Name, fill = Recommended.IND))

## arrage the bar tables to compare in one page
grid.arrange (b1, b2, b3, b4, b5, b6, b7, nrow = 2)

## contingency table Sample
conTab <- table(eClothing.df$Recommended.IND)
conTab

## contingency table1 -- Recommended vs. Dep
conTab1 <- table(eClothing.df$Recommended.IND, eClothing.df$Department.Name,
                 dnn = c("Recommended","Department"))
conTab1
summary(conTab1)

## mosaic plot1 -- Recommended vs. Dep
mosaic(conTab1, shade = TRUE)

## .	Is a higher rating means definitely recommend the items to others online?
## contingency table2 -- Recommended vs. Rating
conTab2 <- table(eClothing.df$Recommended.IND, eClothing.df$Rating,
                 dnn = c("Recommended","Rating"))
conTab2
summary(conTab2)

## mosaic plot2 -- Recommended vs. Rating
mosaic(conTab2, shade = TRUE)


### Data Mining Project Final Version
### model building + exploring errors with cross-validation + dealing with class imbalances in visualizations 
### December 9, 2020

# for data manipulation
library(modelr)     # provides easy pipeline modeling functions
library(broom)      # helps to tidy up model outputs
library(caret) # for model-building
library(DMwR) # for smote implementation
library(purrr) # for functional programming (map)
library(pROC) # for AUC calculations

# read the data 
eClothing.df <- read.csv("Wang-006178927.csv")
str(eClothing.df) # view data structure

# based on the project version 2 analysis above to select the variables
# make a new data frame with the independent variable(x)
# and dependent variable (y) -- Recommended.IND

eData.df <- select(eClothing.df, c(Age, Rating, Positive.Feedback.Count, Recommended.IND))
eData.df$YesorNo<-as.factor(eData.df$Recommended.IND)

# add a column with factor for Recommended.IND
levels(eData.df$YesorNo)<-c("No","Yes")

str(eData.df)
view(eData.df)

# get the standard deviations
#sapply(eData.df, sd)

# Split the data into training and test set
set.seed(123)
sample <- sample(c(TRUE, FALSE), nrow(eData.df), replace = T, prob = c(0.7,0.3))
train <- eData.df[sample, ]
test <- eData.df[!sample, ]

# make a logistic regression model using the glm (generalized linear model) function.
# mylogit1 is model 1 -- selected Age variable to predicate Recommended.IND Yes or No
mylogit1 <- glm(Recommended.IND ~ Age, data = train, family = "binomial")
summary(mylogit1)
summary(train$Age)
# make a data frame
age<-data.frame(Age=seq(18,100,4)) # seq based on Min and Max in summary(train$Age)
# plot the model 1
ggplot()+ geom_line(data=age,aes(x=Age,y=predict(mylogit1,age,type="response")))+
  geom_point(data=train,aes(x=Age,y=Recommended.IND))

# mylogit2 is model 2 -- selected Rating variable to predicate Recommended.IND Yes or No
mylogit2 <- glm(Recommended.IND ~ Rating, data = train, family = "binomial")
summary(mylogit2)
summary(train$Rating)
# make a data frame 
rating<-data.frame(Rating=seq(1, 5, 0.1)) # seq based on Min and Max in summary(train$Rating)
# plot the model 2
ggplot()+ geom_line(data=rating,aes(x=Rating,y=predict(mylogit2,rating,type="response")))+
  geom_count(data=train,aes(x=Rating,y=Recommended.IND))

# mylogit3 is model 3 -- selected Positive.Feedback.Count variable to predicate Recommended.IND Yes or No
mylogit3<- glm(Recommended.IND ~ Positive.Feedback.Count, data = train, family = "binomial")
summary(mylogit3)
summary(train$Positive.Feedback.Count)
# make a data frame -- seq based on Min and Max in summary(train$Positive.Feedback.Count)
pCou <- data.frame(Positive.Feedback.Count = seq(0, 122, 2)) 
# plot the model 3
ggplot()+ geom_line(data=pCou,aes(x=Positive.Feedback.Count,y=predict(mylogit3,pCou,type="response")))+
  geom_count(data=train,aes(x=Positive.Feedback.Count,y=Recommended.IND))

# mylogit4 is model 4 -- 
# selected Age, Ratint and Positive.Feedback.Count 3 variables to predicate Recommended.IND Yes or No
mylogit4 <- glm(Recommended.IND ~ Age + Rating + Positive.Feedback.Count, data = train, 
                family = "binomial")
summary(mylogit4)

## odd ratio
exp(coef(mylogit4))

## use the confint function to obtain confidence intervals for the coefficient estimates.
confint(mylogit4)
summary(mylogit4)


### corss validation

# Define training control for model 1
set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)

# Train the model1
model1 <- train(Recommended.IND ~ Age, data = train, 
               family = "binomial",
               method = "glm",
               trControl = train.control)
# Summarize the model1 results
print(model1)
summary(model1)

# Define training control
set.seed(123)
train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3) # repeats 3 times
# Train the model
model1 <- train(Recommended.IND ~ Age, data = train, 
               family = "binomial",
               method = "glm",
               trControl = train.control)
# Summarize the results
print(model1) # RMSE:     Rsquared:    MAE:    
summary(model1)

## exploring errors with cross-validation for the error table

predictions <- model1 %>% predict(test)
data.frame( R2 = R2(predictions, test$Recommended.IND),# 
            RMSE = RMSE(predictions, test$Recommended.IND),
            MAE = MAE(predictions, test$Recommended.IND))

# Define training control for model 2
set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)
# Train the model2
model2 <- train(Recommended.IND ~ Rating, data = train, 
                family = "binomial",
                method = "glm",
                trControl = train.control)
# Summarize the model 2 results
print(model2)
summary(model2)

# Define training control for model 2
set.seed(123)
train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3) # repeats 3 times
# Train the model2
model2 <- train(Recommended.IND ~ Rating, data = train, 
                family = "binomial",
                method = "glm",
                trControl = train.control)
# Summarize the results
print(model2) # RMSE:     Rsquared:    MAE:    
summary(model2)

## exploring errors with cross-validation for the error table
predictions <- model2 %>% predict(test)
data.frame( R2 = R2(predictions, test$Recommended.IND),
            RMSE = RMSE(predictions, test$Recommended.IND),
            MAE = MAE(predictions, test$Recommended.IND))

# Define training control for model 3
set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)
# Train the model3
model3 <- train(Recommended.IND ~ Positive.Feedback.Count, data = train, 
                family = "binomial",
                method = "glm",
                trControl = train.control)
# Summarize the model3 results
print(model3)
summary(model3)

# Define training control
set.seed(123)
train.control <- trainControl(method = "repeatedcv", 
                              number = 10, repeats = 3) # repeats 3 times
# Train the model
model3 <- train(Recommended.IND ~ Positive.Feedback.Count, data = train, 
                family = "binomial",
                method = "glm",
                trControl = train.control)
# Summarize the results
print(model3) # RMSE:     Rsquared:    MAE:    
summary(model3)

## exploring errors with cross-validation for the error table
predictions <- model3 %>% predict(test)
data.frame( R2 = R2(predictions, test$Recommended.IND),
            RMSE = RMSE(predictions, test$Recommended.IND),
            MAE = MAE(predictions, test$Recommended.IND))


# Define training control for model 4
set.seed(123) 
train.control <- trainControl(method = "cv", number = 10)
# Train the model 4
model4 <- train(Recommended.IND ~ Age + Rating + Positive.Feedback.Count, 
               data = train, 
               family = "binomial",
               method = "glm",
               trControl = train.control)
# Summarize the results
print(model4)
summary(model4)

## exploring errors with cross-validation for the error table
predictions <- model4 %>% predict(test)
data.frame( R2 = R2(predictions, test$Recommended.IND),
            RMSE = RMSE(predictions, test$Recommended.IND),
            MAE = MAE(predictions, test$Recommended.IND))


## deal with class imblance
# class imbalance table
prop.table(table(train$YesorNo))
view(train)

# Set up control function for training
ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 5,
                     summaryFunction = twoClassSummary,
                     classProbs = TRUE)

# Build a standard classifier using a gradient boosted machine
set.seed(5627)
orig_fit <- train(YesorNo ~ Age + Rating + Positive.Feedback.Count, data = train, 
                  family = "binomial",
                  method = "glm",
                  trControl = ctrl)

# Create model weights (they sum to one)
model_weights <- ifelse(train$YesorNo == "Not",
                        (1/table(train$YesorNo)[1]) * 0.5,
                        (1/table(train$YesorNo)[2]) * 0.5)

# Use the same seed to ensure same cross-validation splits
ctrl$seeds <- orig_fit$control$seeds

## make a predication by model4

# Define training control for model 4
# Train the model 41 with YesorNO the same as model4
model41 <- train(YesorNo ~ Age + Rating + Positive.Feedback.Count, 
                 data = train, 
                 family = "binomial",
                 method = "glm",
                 trControl = train.control)

# Summarize the results
validMod41=predict(model41, test, type = "prob")
rocMod41=roc(test$YesorNo,factor(validMod41$`Yes`,ordered=T))
plot(rocMod41,col="black")
rocMod41$auc

# Build weighted model
weighted_fit <- train(YesorNo ~ Age + Rating + Positive.Feedback.Count, 
                      data = train, 
                      family = "binomial",
                      method = "glm",
                      weights = model_weights,
                      metric = "ROC",
                      trControl = ctrl)

validWeig=predict(weighted_fit, test, type = "prob")
rocWeight=roc(test$YesorNo,factor(validWeig$`Yes`,ordered=T)) 
plot(rocWeight, add=T, col="green", lty = 2) # dashed line lty= 2
rocWeight$auc

# Build down-sampled model
ctrl$sampling <- "down"

down_fit <- train(YesorNo ~ Age + Rating + Positive.Feedback.Count, 
                  data = train, 
                  family = "binomial",
                  method = "glm",
                  metric = "ROC",
                  trControl = ctrl)

validDown=predict(down_fit, test, type = "prob")
rocDown=roc(test$YesorNo,factor(validDown$`Yes`,ordered=T))
plot(rocDown,add=T, col="red", lty = 3) # dotted line lty = 3
rocDown$auc

# Build up-sampled model

ctrl$sampling <- "up"

up_fit <- train(YesorNo ~ Age + Rating + Positive.Feedback.Count, 
                data = train, 
                family = "binomial",
                method = "glm",
                metric = "ROC",
                trControl = ctrl)

validUp=predict(up_fit, test, type = "prob")
rocUp=roc(test$YesorNo,factor(validUp$`Yes`,ordered=T))
plot(rocUp,add=T, col="blue", lty = 4)# dotdash line lty = 4
rocUp$auc

# Build smote model
ctrl$sampling <- "smote"

smote_fit <- train(YesorNo ~ Age + Rating + Positive.Feedback.Count, 
                   data = train, 
                   family = "binomial",
                   method = "glm",
                   metric = "ROC",
                   trControl = ctrl)

validSmote=predict(smote_fit, test, type = "prob")
rocSmote=roc(test$YesorNo,factor(validSmote$`Yes`,ordered=T))
plot(rocSmote,add=T, col="gold", lty = 6) # twodash line lty = 6
rocSmote$auc

