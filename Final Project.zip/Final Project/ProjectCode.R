library(readxl)
library(pscl)
library(caret)
library(tidyverse)
library(modelr)
library(broom)
library(ROCR)
library(ROSE)

# Link the Data into R
    mydata = 
      read_excel("C:\\Users\\willg\\Documents\\MU\\MU Junior S1\\COSC 4610 - Data Mining\\Project\\gangdata5.xlsx")
    head(mydata)

# Split into Training and Testing Sets
    set.seed(123)
    trainIndex <- createDataPartition(mydata$Race, p = 0.8, list = FALSE)
    traind  <- mydata[trainIndex, ]
    testd <- mydata[-trainIndex, ]
    View(train)
    View(test)
  
# Model Fits
  # Model 1
    model1 <- glm(Race ~ Armed + Colors + Tattoos + Age + Height + Weight + Eye_Color + Hair_Color,
                  family = "binomial", data = traind)
    summary(model1)
  
  # Model 2 
    model2 <- glm(Race ~ Armed + Colors + Tattoos + Age + Hair_Color,
                  family = "binomial", data = traind)
    summary(model2)
    
  # Model 3
    model3 <- glm(Race ~ Armed + Colors + Tattoos + Hair_Color,
                  family = "binomial", data = traind)
    summary(model3)

# Confusion Matrices
  # Probabilities
      test.predicted.m1 <- predict(model1, newdata = testd, type = "response") #model1
      test.predicted.m2 <- predict(model2, newdata = testd, type = "response") #model2
      test.predicted.m3 <- predict(model3, newdata = testd, type = "response") #model3
  
  # Predictions on Test
      table(test.predicted.m1 > 0.5, testd$Race) #model1
      table(test.predicted.m2 > 0.5, testd$Race) #model2
      table(test.predicted.m3 > 0.5, testd$Race) #model3

# AUC Values
  # Model 1
    prediction(test.predicted.m1, testd$Race) %>%
      performance(measure = "auc") %>%
      .@y.values
    
  # Model 2
    prediction(test.predicted.m2, testd$Race) %>%
      performance(measure = "auc") %>%
      .@y.values
  
  # Model 3
    prediction(test.predicted.m3, testd$Race) %>%
      performance(measure = "auc") %>%
      .@y.values

# Plotting ROC
    ROCRpred = prediction(test.predicted.m1, testd$Race)
    ROCRperf = performance(ROCRpred, "tpr", "fpr")
    plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))

# R2, RMSE, and MAE
  # Model 1
    predictions <- model1 %>% predict(testd)
    data.frame(R2 = R2(predictions, testd$Race),
                    RMSE = RMSE(predictions, testd$Race),
                    MAE = MAE(predictions, testd$Race))
  # Model 2
    predictions <- model2 %>% predict(testd)
    data.frame(R2 = R2(predictions, testd$Race),
               RMSE = RMSE(predictions, testd$Race),
               MAE = MAE(predictions, testd$Race))
  # Model 3
    predictions <- model3 %>% predict(testd)
    data.frame(R2 = R2(predictions, testd$Race),
               RMSE = RMSE(predictions, testd$Race),
               MAE = MAE(predictions, testd$Race))

# Data Imbalance
  # Initial Values
      table(traind$Race)

  # Oversampling 
      data_over <- ovun.sample(Race ~ ., data = traind, method = "over", N = 9134)$data
      table(data_over$Race)
    # Model Trained
        model_over <- glm(Race ~., family = "binomial", data = data_over)
    # Test Model
        test.over <- predict(model_over, newdata = testd, type = "response")
        
        prediction(test.over, testd$Race) %>%
          performance(measure = "auc") %>%
          .@y.values
    # ROC 
        ROCRpred = prediction(test.over, testd$Race)
        ROCRperf = performance(ROCRpred, "tpr", "fpr")
        plot(ROCRperf, colorize = TRUE, print.cutoffs.at = seq(0,1,by = 0.1), text.adj = c(-0.2,1.7))
      
  # Undersampling
      data_under <- ovun.sample(Race ~., data = traind, method = "under", N = 8966, seed = 1)$data
      table(data_under$Race)
    # Test Model
        model_under <- glm(Race ~., family = "binomial", data = data_under)
        test.under <- predict(model_under, newdata = testd, type = "response")
        
        prediction(test.under, testd$Race) %>%
          performance(measure = "auc") %>%
          .@y.values
    # ROC 
        ROCRpred = prediction(test.under, testd$Race)
        ROCRperf = performance(ROCRpred, "tpr", "fpr")
        plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))
  
  # Over & Under sampling
      data_both <- ovun.sample(Race ~., data = traind, method = "both", p=0.5, N=9050, seed = 1)$data
      table(data_both$Race)
    # Test Model
        model_both <- glm(Race ~., family = "binomial", data = data_both)
        test.both <- predict(model_both, newdata = testd, type = "response")
        
        prediction(test.both, testd$Race) %>%
          performance(measure = "auc") %>%
          .@y.values
    # ROC
        ROCRpred = prediction(test.both, testd$Race)
        ROCRperf = performance(ROCRpred, "tpr", "fpr")
        plot(ROCRperf, colorize=TRUE, print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))